package com.flurry.android;

import android.os.Handler;

final class a {
    String a;
    long b;
    long c;
    long d;
    String e;
    String f;
    Handler g;

    a() {
    }
}
