package com.flurry.android;

final class k implements Runnable {
    private /* synthetic */ ag a;

    k(ag agVar) {
        this.a = agVar;
    }

    public final void run() {
        this.a.a();
    }
}
