package com.flurry.android;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import org.acra.ACRAConstants;
import org.apache.commons.lang.StringUtils;

final class u implements OnClickListener {
    static String a;
    static String b;
    private static volatile String c;
    private static volatile String d;
    private static volatile String e;
    private static String f;
    private static int g;
    private static volatile long z;
    private String h;
    private String i;
    private String j;
    private long k;
    private long l;
    private long m;
    private z n;
    private boolean o;
    private volatile boolean p;
    private String q;
    private Map r;
    private Handler s;
    private boolean t;
    private transient Map u;
    private ag v;
    private List w;
    private Map x;
    private AppCircleCallback y;

    static /* synthetic */ void a(u uVar, Context context, String str) {
        String str2 = "android.intent.action.VIEW";
        if (str.startsWith(d)) {
            String substring = str.substring(d.length());
            if (uVar.o) {
                try {
                    ah.a(a, "Launching Android Market for app " + substring);
                    context.startActivity(new Intent("android.intent.action.VIEW").setData(Uri.parse(str)));
                    return;
                } catch (Throwable e) {
                    ah.c(a, "Cannot launch Marketplace url " + str, e);
                    return;
                }
            }
            ah.a(a, "Launching Android Market website for app " + substring);
            String str3 = "android.intent.action.VIEW";
            context.startActivity(new Intent(str2).setData(Uri.parse(e + substring)));
            return;
        }
        ah.d(a, "Unexpected android market url scheme: " + str);
    }

    static {
        c = "market://";
        d = "market://details?id=";
        e = "https://market.android.com/details?id=";
        f = "com.flurry.android.ACTION_CATALOG";
        a = "FlurryAgent";
        Random random = new Random(System.currentTimeMillis());
        g = ACRAConstants.DEFAULT_SOCKET_TIMEOUT;
        b = StringUtils.EMPTY;
        z = 0;
    }

    public u() {
        this.o = true;
        this.r = new HashMap();
        this.u = new HashMap();
        this.w = new ArrayList();
        this.x = new HashMap();
        this.n = new z();
    }

    final synchronized void a(Context context, a aVar) {
        if (!this.p) {
            this.h = aVar.e;
            this.i = aVar.f;
            this.j = aVar.a;
            this.k = aVar.b;
            this.l = aVar.c;
            this.m = aVar.d;
            this.s = aVar.g;
            this.v = new ag(this.s, g);
            context.getResources().getDisplayMetrics();
            this.x.clear();
            this.u.clear();
            this.n.a(context, this, aVar);
            this.r.clear();
            PackageManager packageManager = context.getPackageManager();
            String str = d + context.getPackageName();
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse(str));
            this.o = packageManager.queryIntentActivities(intent, 65536).size() > 0;
            a();
            this.p = true;
        }
    }

    final synchronized void a() {
        this.w.clear();
    }

    final boolean b() {
        return this.p;
    }

    final void a(String str) {
        this.q = str;
    }

    final synchronized void c() {
        if (q()) {
            this.n.d();
        }
    }

    final synchronized void d() {
        if (q()) {
            this.n.e();
        }
    }

    final synchronized void a(Map map, Map map2, Map map3, Map map4, Map map5, Map map6) {
        if (q()) {
            this.n.a(map, map2, map3, map4, map5, map6);
            Log.i("FlurryAgent", this.n.toString());
        }
    }

    final synchronized long e() {
        long c;
        if (q()) {
            c = this.n.c();
        } else {
            c = 0;
        }
        return c;
    }

    final synchronized Set f() {
        Set a;
        if (q()) {
            a = this.n.a();
        } else {
            a = Collections.emptySet();
        }
        return a;
    }

    final synchronized AdImage a(long j) {
        AdImage b;
        if (q()) {
            b = this.n.b(j);
        } else {
            b = null;
        }
        return b;
    }

    private synchronized AdImage o() {
        AdImage a;
        if (q()) {
            a = this.n.a((short) 1);
        } else {
            a = null;
        }
        return a;
    }

    final synchronized List g() {
        return this.w;
    }

    final synchronized p b(long j) {
        return (p) this.u.get(Long.valueOf(j));
    }

    final synchronized void h() {
        this.u.clear();
    }

    final synchronized void a(Context context, String str) {
        if (q()) {
            try {
                List a = a(Arrays.asList(new String[]{str}), null);
                if (a == null || a.isEmpty()) {
                    Intent intent = new Intent(p());
                    intent.addCategory("android.intent.category.DEFAULT");
                    context.startActivity(intent);
                } else {
                    p pVar = new p(str, (byte) 2, SystemClock.elapsedRealtime() - this.m);
                    pVar.b = (v) a.get(0);
                    a(pVar);
                    b(context, pVar, this.h + a(pVar, Long.valueOf(System.currentTimeMillis())));
                }
            } catch (Throwable e) {
                ah.d(a, "Failed to launch promotional canvas for hook: " + str, e);
            }
        }
    }

    final void a(AppCircleCallback appCircleCallback) {
        this.y = appCircleCallback;
    }

    final void a(boolean z) {
        this.t = z;
    }

    final boolean i() {
        return this.t;
    }

    final String j() {
        return this.h;
    }

    final synchronized void a(Context context, p pVar, String str) {
        if (q()) {
            this.s.post(new ak(this, str, context, pVar));
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private java.lang.String d(java.lang.String r8) {
        /*
        r7 = this;
        r5 = 0;
        r4 = "Unknown host: ";
        r0 = c;	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r0 = r8.startsWith(r0);	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        if (r0 != 0) goto L_0x0068;
    L_0x000b:
        r0 = new org.apache.http.client.methods.HttpGet;	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r0.<init>(r8);	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r1 = new org.apache.http.impl.client.DefaultHttpClient;	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r1.<init>();	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r0 = r1.execute(r0);	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r1 = r0.getStatusLine();	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r1 = r1.getStatusCode();	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r2 = 200; // 0xc8 float:2.8E-43 double:9.9E-322;
        if (r1 != r2) goto L_0x003a;
    L_0x0025:
        r0 = r0.getEntity();	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r0 = org.apache.http.util.EntityUtils.toString(r0);	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r1 = c;	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00c4 }
        r1 = r0.startsWith(r1);	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00c4 }
        if (r1 != 0) goto L_0x0039;
    L_0x0035:
        r0 = r7.d(r0);	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00c4 }
    L_0x0039:
        return r0;
    L_0x003a:
        r0 = a;	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r2 = new java.lang.StringBuilder;	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r2.<init>();	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r3 = "Cannot process with responseCode ";
        r2 = r2.append(r3);	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r2 = r2.append(r1);	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r2 = r2.toString();	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        com.flurry.android.ah.c(r0, r2);	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r0 = new java.lang.StringBuilder;	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r0.<init>();	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r2 = "Error when fetching application's android market ID, responseCode ";
        r0 = r0.append(r2);	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r0 = r0.append(r1);	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r0 = r0.toString();	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
        r7.e(r0);	 Catch:{ UnknownHostException -> 0x006a, Exception -> 0x00a7 }
    L_0x0068:
        r0 = r8;
        goto L_0x0039;
    L_0x006a:
        r0 = move-exception;
        r1 = a;
        r2 = new java.lang.StringBuilder;
        r2.<init>();
        r3 = "Unknown host: ";
        r2 = r2.append(r4);
        r3 = r0.getMessage();
        r2 = r2.append(r3);
        r2 = r2.toString();
        com.flurry.android.ah.c(r1, r2);
        r1 = r7.y;
        if (r1 == 0) goto L_0x00a5;
    L_0x008b:
        r1 = new java.lang.StringBuilder;
        r1.<init>();
        r2 = "Unknown host: ";
        r1 = r1.append(r4);
        r0 = r0.getMessage();
        r0 = r1.append(r0);
        r0 = r0.toString();
        r7.e(r0);
    L_0x00a5:
        r0 = r5;
        goto L_0x0039;
    L_0x00a7:
        r0 = move-exception;
        r1 = r8;
    L_0x00a9:
        r2 = a;
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r4 = "Failed on url: ";
        r3 = r3.append(r4);
        r1 = r3.append(r1);
        r1 = r1.toString();
        com.flurry.android.ah.c(r2, r1, r0);
        r0 = r5;
        goto L_0x0039;
    L_0x00c4:
        r1 = move-exception;
        r6 = r1;
        r1 = r0;
        r0 = r6;
        goto L_0x00a9;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.flurry.android.u.d(java.lang.String):java.lang.String");
    }

    private void e(String str) {
        a(new ae(this, str));
    }

    final synchronized Offer b(String str) {
        Offer offer;
        if (q()) {
            List a = a(Arrays.asList(new String[]{str}), null);
            if (a == null || a.isEmpty()) {
                offer = null;
            } else {
                offer = a(str, (v) a.get(0));
                ah.a(a, "Impression for offer with ID " + offer.getId());
            }
        } else {
            offer = null;
        }
        return offer;
    }

    final synchronized void a(Context context, long j) {
        if (q()) {
            OfferInSdk offerInSdk = (OfferInSdk) this.x.get(Long.valueOf(j));
            if (offerInSdk == null) {
                ah.b(a, "Cannot find offer " + j);
            } else {
                p pVar = offerInSdk.b;
                pVar.a(new f((byte) 4, k()));
                String str = FlurryAgent.c() + a(pVar, Long.valueOf(pVar.a()));
                ah.a(a, "Offer " + offerInSdk.a + " accepted. Sent with cookies: " + this.r);
                a(context, pVar, str);
            }
        }
    }

    final synchronized List c(String str) {
        List emptyList;
        if (!q()) {
            emptyList = Collections.emptyList();
        } else if (this.n.b()) {
            v[] a = this.n.a(str);
            List arrayList = new ArrayList();
            if (a != null && a.length > 0) {
                for (v a2 : a) {
                    arrayList.add(a(str, a2));
                }
            }
            ah.a(a, "Impressions for " + arrayList.size() + " offers.");
            emptyList = arrayList;
        } else {
            emptyList = Collections.emptyList();
        }
        return emptyList;
    }

    final synchronized void a(List list) {
        if (q()) {
            for (Long remove : list) {
                this.x.remove(remove);
            }
        }
    }

    private Offer a(String str, v vVar) {
        p pVar = new p(str, (byte) 3, k());
        a(pVar);
        pVar.a(new f((byte) 2, k()));
        pVar.b = vVar;
        al a = this.n.a(vVar.a);
        String str2 = a == null ? StringUtils.EMPTY : a.a;
        int i = a == null ? 0 : a.c;
        long j = z + 1;
        z = j;
        OfferInSdk offerInSdk = new OfferInSdk(j, pVar, vVar.h, vVar.d, str2, i);
        this.x.put(Long.valueOf(offerInSdk.a), offerInSdk);
        return new Offer(offerInSdk.a, offerInSdk.f, offerInSdk.c, offerInSdk.d, offerInSdk.e);
    }

    final synchronized List a(Context context, List list, Long l, int i, boolean z) {
        List emptyList;
        if (!q()) {
            emptyList = Collections.emptyList();
        } else if (!this.n.b() || list == null) {
            emptyList = Collections.emptyList();
        } else {
            List a = a(list, l);
            int min = Math.min(list.size(), a.size());
            List arrayList = new ArrayList();
            for (int i2 = 0; i2 < min; i2++) {
                String str = (String) list.get(i2);
                e b = this.n.b(str);
                if (b != null) {
                    p pVar = new p((String) list.get(i2), (byte) 1, k());
                    a(pVar);
                    if (i2 < a.size()) {
                        pVar.b = (v) a.get(i2);
                        pVar.a(new f((byte) 2, k()));
                        y yVar = new y(context, this, pVar, b, i, z);
                        yVar.a(a(pVar, null));
                        arrayList.add(yVar);
                    }
                } else {
                    ah.d(a, "Cannot find hook: " + str);
                }
            }
            emptyList = arrayList;
        }
        return emptyList;
    }

    final synchronized View a(Context context, String str, int i) {
        View view;
        if (q()) {
            o oVar = new o(this, context, str, i);
            this.v.a(oVar);
        } else {
            view = null;
        }
        return view;
    }

    private void a(p pVar) {
        if (this.w.size() < 32767) {
            this.w.add(pVar);
            this.u.put(Long.valueOf(pVar.a()), pVar);
        }
    }

    private List a(List list, Long l) {
        if (list == null || list.isEmpty() || !this.n.b()) {
            return Collections.emptyList();
        }
        v[] a = this.n.a((String) list.get(0));
        if (a == null || a.length <= 0) {
            return Collections.emptyList();
        }
        List arrayList = new ArrayList(Arrays.asList(a));
        Collections.shuffle(arrayList);
        if (l != null) {
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                if (((v) it.next()).a == l.longValue()) {
                    it.remove();
                    break;
                }
            }
        }
        return arrayList.subList(0, Math.min(arrayList.size(), list.size()));
    }

    final long k() {
        return SystemClock.elapsedRealtime() - this.m;
    }

    public final synchronized void onClick(View view) {
        y yVar = (y) view;
        p a = yVar.a();
        a.a(new f((byte) 4, k()));
        if (this.t) {
            b(view.getContext(), a, yVar.b(this.h));
        } else {
            a(view.getContext(), a, yVar.b(this.i));
        }
    }

    final synchronized void a(String str, String str2) {
        this.r.put(str, str2);
    }

    final synchronized void l() {
        this.r.clear();
    }

    private void b(Context context, p pVar, String str) {
        Intent intent = new Intent(p());
        intent.addCategory("android.intent.category.DEFAULT");
        intent.putExtra("u", str);
        if (pVar != null) {
            intent.putExtra("o", pVar.a());
        }
        context.startActivity(intent);
    }

    private static String p() {
        return FlurryAgent.a != null ? FlurryAgent.a : f;
    }

    private String a(p pVar, Long l) {
        v vVar = pVar.b;
        StringBuilder append = new StringBuilder().append("?apik=").append(this.j).append("&cid=").append(vVar.e).append("&adid=").append(vVar.a).append("&pid=").append(this.q).append("&iid=").append(this.k).append("&sid=").append(this.l).append("&its=").append(pVar.a()).append("&hid=").append(r.a(pVar.a)).append("&ac=").append(a(vVar.g));
        if (!(this.r == null || this.r.isEmpty())) {
            for (Entry entry : this.r.entrySet()) {
                String str = "c_" + r.a((String) entry.getKey());
                append.append("&").append(str).append("=").append(r.a((String) entry.getValue()));
            }
        }
        append.append("&ats=");
        if (l != null) {
            append.append(l);
        }
        return append.toString();
    }

    private static String a(byte[] bArr) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < bArr.length; i++) {
            int i2 = (bArr[i] >> 4) & 15;
            if (i2 < 10) {
                stringBuilder.append((char) (i2 + 48));
            } else {
                stringBuilder.append((char) ((i2 + 65) - 10));
            }
            i2 = bArr[i] & 15;
            if (i2 < 10) {
                stringBuilder.append((char) (i2 + 48));
            } else {
                stringBuilder.append((char) ((i2 + 65) - 10));
            }
        }
        return stringBuilder.toString();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("[adLogs=").append(this.w).append("]");
        return stringBuilder.toString();
    }

    final synchronized AdImage m() {
        AdImage o;
        if (q()) {
            o = o();
        } else {
            o = null;
        }
        return o;
    }

    private static void a(Runnable runnable) {
        new Handler().post(runnable);
    }

    final synchronized void a(int i) {
        if (this.y != null) {
            a(new ad(this, i));
        }
    }

    final synchronized boolean n() {
        boolean b;
        if (q()) {
            b = this.n.b();
        } else {
            b = false;
        }
        return b;
    }

    private boolean q() {
        if (!this.p) {
            ah.d(a, "AppCircle is not initialized");
        }
        if (this.q == null) {
            ah.d(a, "Cannot identify UDID.");
        }
        return this.p;
    }
}
