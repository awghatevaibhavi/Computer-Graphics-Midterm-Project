package com.flurry.android;

import java.util.List;

final class x {
    p a;
    String b;
    List c;

    x() {
    }
}
