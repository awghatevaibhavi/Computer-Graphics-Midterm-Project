package com.flurry.android;

final class al extends aj {
    String a;
    String b;
    int c;

    al() {
    }
}
