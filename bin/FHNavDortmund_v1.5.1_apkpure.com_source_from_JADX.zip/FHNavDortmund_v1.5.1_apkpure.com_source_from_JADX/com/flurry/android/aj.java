package com.flurry.android;

abstract class aj {
    aj() {
    }
}
