package com.flurry.android;

final class aa {
    long a;
    String b;
    String c;
    String d;

    /* synthetic */ aa() {
        this((byte) 0);
    }

    private aa(byte b) {
    }
}
