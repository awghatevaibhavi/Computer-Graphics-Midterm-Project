package com.flurry.android;

final class f {
    final byte a;
    final long b;

    f(byte b, long j) {
        this.a = b;
        this.b = j;
    }

    public final String toString() {
        return "[" + this.b + "] " + this.a;
    }
}
