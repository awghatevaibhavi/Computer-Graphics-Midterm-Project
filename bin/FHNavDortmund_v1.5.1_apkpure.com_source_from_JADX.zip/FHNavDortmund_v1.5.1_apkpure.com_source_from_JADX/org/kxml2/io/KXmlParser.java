package org.kxml2.io;

import java.io.IOException;
import java.io.Reader;
import java.util.Hashtable;
import org.acra.ACRAConstants;
import org.apache.commons.lang.StringUtils;
import org.ksoap2.SoapEnvelope;
import org.kxml2.kdom.Node;
import org.kxml2.wap.Wbxml;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class KXmlParser implements XmlPullParser {
    private static final String ILLEGAL_TYPE = "Wrong event type";
    private static final int LEGACY = 999;
    private static final String UNEXPECTED_EOF = "Unexpected EOF";
    private static final int XML_DECL = 998;
    private int attributeCount;
    private String[] attributes;
    private int column;
    private boolean degenerated;
    private int depth;
    private String[] elementStack;
    private String encoding;
    private Hashtable entityMap;
    private String error;
    private boolean isWhitespace;
    private int line;
    private Object location;
    private String name;
    private String namespace;
    private int[] nspCounts;
    private String[] nspStack;
    private int[] peek;
    private int peekCount;
    private String prefix;
    private boolean processNsp;
    private Reader reader;
    private boolean relaxed;
    private char[] srcBuf;
    private int srcCount;
    private int srcPos;
    private Boolean standalone;
    private boolean token;
    private char[] txtBuf;
    private int txtPos;
    private int type;
    private boolean unresolved;
    private String version;
    private boolean wasCR;

    public KXmlParser() {
        int i;
        this.elementStack = new String[16];
        this.nspStack = new String[8];
        this.nspCounts = new int[4];
        this.txtBuf = new char[Wbxml.EXT_T_0];
        this.attributes = new String[16];
        this.peek = new int[2];
        if (Runtime.getRuntime().freeMemory() >= 1048576) {
            i = ACRAConstants.DEFAULT_BUFFER_SIZE_IN_BYTES;
        } else {
            i = Wbxml.EXT_T_0;
        }
        this.srcBuf = new char[i];
    }

    private final boolean isProp(String n1, boolean prop, String n2) {
        if (!n1.startsWith("http://xmlpull.org/v1/doc/")) {
            return false;
        }
        if (prop) {
            return n1.substring(42).equals(n2);
        }
        return n1.substring(40).equals(n2);
    }

    private final boolean adjustNsp() throws XmlPullParserException {
        int cut;
        boolean any = false;
        int i = 0;
        while (i < (this.attributeCount << 2)) {
            String prefix;
            String attrName = this.attributes[i + 2];
            cut = attrName.indexOf(58);
            if (cut != -1) {
                prefix = attrName.substring(0, cut);
                attrName = attrName.substring(cut + 1);
            } else if (attrName.equals("xmlns")) {
                prefix = attrName;
                attrName = null;
            } else {
                i += 4;
            }
            if (prefix.equals("xmlns")) {
                int[] iArr = this.nspCounts;
                int i2 = this.depth;
                int i3 = iArr[i2];
                iArr[i2] = i3 + 1;
                int j = i3 << 1;
                this.nspStack = ensureCapacity(this.nspStack, j + 2);
                this.nspStack[j] = attrName;
                this.nspStack[j + 1] = this.attributes[i + 3];
                if (attrName != null && this.attributes[i + 3].equals(StringUtils.EMPTY)) {
                    error("illegal empty namespace");
                }
                Object obj = this.attributes;
                i2 = i + 4;
                Object obj2 = this.attributes;
                int i4 = this.attributeCount - 1;
                this.attributeCount = i4;
                System.arraycopy(obj, i2, obj2, i, (i4 << 2) - i);
                i -= 4;
            } else {
                any = true;
            }
            i += 4;
        }
        if (any) {
            i = (this.attributeCount << 2) - 4;
            while (i >= 0) {
                attrName = this.attributes[i + 2];
                cut = attrName.indexOf(58);
                if (cut != 0 || this.relaxed) {
                    if (cut != -1) {
                        String attrPrefix = attrName.substring(0, cut);
                        attrName = attrName.substring(cut + 1);
                        String attrNs = getNamespace(attrPrefix);
                        if (attrNs != null || this.relaxed) {
                            this.attributes[i] = attrNs;
                            this.attributes[i + 1] = attrPrefix;
                            this.attributes[i + 2] = attrName;
                        } else {
                            throw new RuntimeException("Undefined Prefix: " + attrPrefix + " in " + this);
                        }
                    }
                    i -= 4;
                } else {
                    throw new RuntimeException("illegal attribute name: " + attrName + " at " + this);
                }
            }
        }
        cut = this.name.indexOf(58);
        if (cut == 0) {
            error("illegal tag name: " + this.name);
        }
        if (cut != -1) {
            this.prefix = this.name.substring(0, cut);
            this.name = this.name.substring(cut + 1);
        }
        this.namespace = getNamespace(this.prefix);
        if (this.namespace == null) {
            if (this.prefix != null) {
                error("undefined prefix: " + this.prefix);
            }
            this.namespace = StringUtils.EMPTY;
        }
        return any;
    }

    private final String[] ensureCapacity(String[] arr, int required) {
        if (arr.length >= required) {
            return arr;
        }
        String[] bigger = new String[(required + 16)];
        System.arraycopy(arr, 0, bigger, 0, arr.length);
        return bigger;
    }

    private final void error(String desc) throws XmlPullParserException {
        if (!this.relaxed) {
            exception(desc);
        } else if (this.error == null) {
            this.error = "ERR: " + desc;
        }
    }

    private final void exception(String desc) throws XmlPullParserException {
        throw new XmlPullParserException(desc.length() < 100 ? desc : desc.substring(0, 100) + "\n", this, null);
    }

    private final void nextImpl() throws IOException, XmlPullParserException {
        if (this.reader == null) {
            exception("No Input specified");
        }
        if (this.type == 3) {
            this.depth--;
        }
        do {
            this.attributeCount = -1;
            if (!this.degenerated) {
                if (this.error == null) {
                    this.prefix = null;
                    this.name = null;
                    this.namespace = null;
                    this.type = peekType();
                    switch (this.type) {
                        case Wbxml.END /*1*/:
                            return;
                        case Wbxml.ENTITY /*2*/:
                            parseStartTag(false);
                            return;
                        case Wbxml.STR_I /*3*/:
                            parseEndTag();
                            return;
                        case Wbxml.LITERAL /*4*/:
                            boolean z;
                            if (this.token) {
                                z = false;
                            } else {
                                z = true;
                            }
                            pushText(60, z);
                            if (this.depth == 0 && this.isWhitespace) {
                                this.type = 7;
                                return;
                            }
                            return;
                        case Node.ENTITY_REF /*6*/:
                            pushEntity();
                            return;
                        default:
                            this.type = parseLegacy(this.token);
                            break;
                    }
                }
                for (int i = 0; i < this.error.length(); i++) {
                    push(this.error.charAt(i));
                }
                this.error = null;
                this.type = 9;
                return;
            }
            this.degenerated = false;
            this.type = 3;
            return;
        } while (this.type == XML_DECL);
    }

    private final int parseLegacy(boolean push) throws IOException, XmlPullParserException {
        int term;
        int result;
        String req = StringUtils.EMPTY;
        int prev = 0;
        read();
        int c = read();
        if (c == 63) {
            if ((peek(0) == SoapEnvelope.VER12 || peek(0) == 88) && (peek(1) == 109 || peek(1) == 77)) {
                if (push) {
                    push(peek(0));
                    push(peek(1));
                }
                read();
                read();
                if ((peek(0) == 108 || peek(0) == 76) && peek(1) <= 32) {
                    if (this.line != 1 || this.column > 4) {
                        error("PI must not start with xml");
                    }
                    parseStartTag(true);
                    if (this.attributeCount < 1 || !"version".equals(this.attributes[2])) {
                        error("version expected");
                    }
                    this.version = this.attributes[3];
                    int pos = 1;
                    if (1 < this.attributeCount && "encoding".equals(this.attributes[6])) {
                        this.encoding = this.attributes[7];
                        pos = 1 + 1;
                    }
                    if (pos < this.attributeCount && "standalone".equals(this.attributes[(pos * 4) + 2])) {
                        String st = this.attributes[(pos * 4) + 3];
                        if ("yes".equals(st)) {
                            this.standalone = new Boolean(true);
                        } else if ("no".equals(st)) {
                            this.standalone = new Boolean(false);
                        } else {
                            error("illegal standalone value: " + st);
                        }
                        pos++;
                    }
                    if (pos != this.attributeCount) {
                        error("illegal xmldecl");
                    }
                    this.isWhitespace = true;
                    this.txtPos = 0;
                    return XML_DECL;
                }
            }
            term = 63;
            result = 8;
        } else if (c != 33) {
            error("illegal: <" + c);
            return 9;
        } else if (peek(0) == 45) {
            result = 9;
            req = "--";
            term = 45;
        } else if (peek(0) == 91) {
            result = 5;
            req = "[CDATA[";
            term = 93;
            push = true;
        } else {
            result = 10;
            req = "DOCTYPE";
            term = -1;
        }
        for (int i = 0; i < req.length(); i++) {
            read(req.charAt(i));
        }
        if (result == 10) {
            parseDoctype(push);
        } else {
            while (true) {
                c = read();
                if (c == -1) {
                    error(UNEXPECTED_EOF);
                    return 9;
                }
                if (push) {
                    push(c);
                }
                if ((term == 63 || c == term) && peek(0) == term && peek(1) == 62) {
                    break;
                }
                prev = c;
            }
            if (term == 45 && prev == 45 && !this.relaxed) {
                error("illegal comment delimiter: --->");
            }
            read();
            read();
            if (push && term != 63) {
                this.txtPos--;
            }
        }
        return result;
    }

    private final void parseDoctype(boolean push) throws IOException, XmlPullParserException {
        int nesting = 1;
        boolean quoted = false;
        while (true) {
            int i = read();
            switch (i) {
                case StringUtils.INDEX_NOT_FOUND /*-1*/:
                    error(UNEXPECTED_EOF);
                    return;
                case 39:
                    quoted = !quoted;
                    break;
                case 60:
                    if (!quoted) {
                        nesting++;
                        break;
                    }
                    break;
                case 62:
                    if (!quoted) {
                        nesting--;
                        if (nesting == 0) {
                            return;
                        }
                    }
                    break;
            }
            if (push) {
                push(i);
            }
        }
    }

    private final void parseEndTag() throws IOException, XmlPullParserException {
        read();
        read();
        this.name = readName();
        skip();
        read('>');
        int sp = (this.depth - 1) << 2;
        if (this.depth == 0) {
            error("element stack empty");
            this.type = 9;
        } else if (!this.relaxed) {
            if (!this.name.equals(this.elementStack[sp + 3])) {
                error("expected: /" + this.elementStack[sp + 3] + " read: " + this.name);
            }
            this.namespace = this.elementStack[sp];
            this.prefix = this.elementStack[sp + 1];
            this.name = this.elementStack[sp + 2];
        }
    }

    private final int peekType() throws IOException {
        switch (peek(0)) {
            case StringUtils.INDEX_NOT_FOUND /*-1*/:
                return 1;
            case 38:
                return 6;
            case 60:
                switch (peek(1)) {
                    case 33:
                    case 63:
                        return LEGACY;
                    case 47:
                        return 3;
                    default:
                        return 2;
                }
            default:
                return 4;
        }
    }

    private final String get(int pos) {
        return new String(this.txtBuf, pos, this.txtPos - pos);
    }

    private final void push(int c) {
        this.isWhitespace &= c <= 32 ? 1 : 0;
        if (this.txtPos == this.txtBuf.length) {
            char[] bigger = new char[(((this.txtPos * 4) / 3) + 4)];
            System.arraycopy(this.txtBuf, 0, bigger, 0, this.txtPos);
            this.txtBuf = bigger;
        }
        char[] cArr = this.txtBuf;
        int i = this.txtPos;
        this.txtPos = i + 1;
        cArr[i] = (char) c;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final void parseStartTag(boolean r14) throws java.io.IOException, org.xmlpull.v1.XmlPullParserException {
        /*
        r13 = this;
        if (r14 != 0) goto L_0x0005;
    L_0x0002:
        r13.read();
    L_0x0005:
        r8 = r13.readName();
        r13.name = r8;
        r8 = 0;
        r13.attributeCount = r8;
    L_0x000e:
        r13.skip();
        r8 = 0;
        r2 = r13.peek(r8);
        if (r14 == 0) goto L_0x0025;
    L_0x0018:
        r8 = 63;
        if (r2 != r8) goto L_0x00a0;
    L_0x001c:
        r13.read();
        r8 = 62;
        r13.read(r8);
    L_0x0024:
        return;
    L_0x0025:
        r8 = 47;
        if (r2 != r8) goto L_0x0096;
    L_0x0029:
        r8 = 1;
        r13.degenerated = r8;
        r13.read();
        r13.skip();
        r8 = 62;
        r13.read(r8);
    L_0x0037:
        r8 = r13.depth;
        r9 = r8 + 1;
        r13.depth = r9;
        r7 = r8 << 2;
        r8 = r13.elementStack;
        r9 = r7 + 4;
        r8 = r13.ensureCapacity(r8, r9);
        r13.elementStack = r8;
        r8 = r13.elementStack;
        r9 = r7 + 3;
        r10 = r13.name;
        r8[r9] = r10;
        r8 = r13.depth;
        r9 = r13.nspCounts;
        r9 = r9.length;
        if (r8 < r9) goto L_0x006a;
    L_0x0058:
        r8 = r13.depth;
        r8 = r8 + 4;
        r1 = new int[r8];
        r8 = r13.nspCounts;
        r9 = 0;
        r10 = 0;
        r11 = r13.nspCounts;
        r11 = r11.length;
        java.lang.System.arraycopy(r8, r9, r1, r10, r11);
        r13.nspCounts = r1;
    L_0x006a:
        r8 = r13.nspCounts;
        r9 = r13.depth;
        r10 = r13.nspCounts;
        r11 = r13.depth;
        r12 = 1;
        r11 = r11 - r12;
        r10 = r10[r11];
        r8[r9] = r10;
        r8 = r13.processNsp;
        if (r8 == 0) goto L_0x014b;
    L_0x007c:
        r13.adjustNsp();
    L_0x007f:
        r8 = r13.elementStack;
        r9 = r13.namespace;
        r8[r7] = r9;
        r8 = r13.elementStack;
        r9 = r7 + 1;
        r10 = r13.prefix;
        r8[r9] = r10;
        r8 = r13.elementStack;
        r9 = r7 + 2;
        r10 = r13.name;
        r8[r9] = r10;
        goto L_0x0024;
    L_0x0096:
        r8 = 62;
        if (r2 != r8) goto L_0x00a0;
    L_0x009a:
        if (r14 != 0) goto L_0x00a0;
    L_0x009c:
        r13.read();
        goto L_0x0037;
    L_0x00a0:
        r8 = -1;
        if (r2 != r8) goto L_0x00aa;
    L_0x00a3:
        r8 = "Unexpected EOF";
        r13.error(r8);
        goto L_0x0024;
    L_0x00aa:
        r0 = r13.readName();
        r8 = r0.length();
        if (r8 != 0) goto L_0x00bb;
    L_0x00b4:
        r8 = "attr name expected";
        r13.error(r8);
        goto L_0x0037;
    L_0x00bb:
        r8 = r13.attributeCount;
        r9 = r8 + 1;
        r13.attributeCount = r9;
        r4 = r8 << 2;
        r8 = r13.attributes;
        r9 = r4 + 4;
        r8 = r13.ensureCapacity(r8, r9);
        r13.attributes = r8;
        r8 = r13.attributes;
        r5 = r4 + 1;
        r9 = "";
        r8[r4] = r9;
        r8 = r13.attributes;
        r4 = r5 + 1;
        r9 = 0;
        r8[r5] = r9;
        r8 = r13.attributes;
        r5 = r4 + 1;
        r8[r4] = r0;
        r13.skip();
        r8 = 0;
        r8 = r13.peek(r8);
        r9 = 61;
        if (r8 == r9) goto L_0x010e;
    L_0x00ee:
        r8 = r13.relaxed;
        if (r8 != 0) goto L_0x0108;
    L_0x00f2:
        r8 = new java.lang.StringBuilder;
        r8.<init>();
        r9 = "Attr.value missing f. ";
        r8 = r8.append(r9);
        r8 = r8.append(r0);
        r8 = r8.toString();
        r13.error(r8);
    L_0x0108:
        r8 = r13.attributes;
        r8[r5] = r0;
        goto L_0x000e;
    L_0x010e:
        r8 = 61;
        r13.read(r8);
        r13.skip();
        r8 = 0;
        r3 = r13.peek(r8);
        r8 = 39;
        if (r3 == r8) goto L_0x0147;
    L_0x011f:
        r8 = 34;
        if (r3 == r8) goto L_0x0147;
    L_0x0123:
        r8 = r13.relaxed;
        if (r8 != 0) goto L_0x012c;
    L_0x0127:
        r8 = "attr value delimiter missing!";
        r13.error(r8);
    L_0x012c:
        r3 = 32;
    L_0x012e:
        r6 = r13.txtPos;
        r8 = 1;
        r13.pushText(r3, r8);
        r8 = r13.attributes;
        r9 = r13.get(r6);
        r8[r5] = r9;
        r13.txtPos = r6;
        r8 = 32;
        if (r3 == r8) goto L_0x000e;
    L_0x0142:
        r13.read();
        goto L_0x000e;
    L_0x0147:
        r13.read();
        goto L_0x012e;
    L_0x014b:
        r8 = "";
        r13.namespace = r8;
        goto L_0x007f;
        */
        throw new UnsupportedOperationException("Method not decompiled: org.kxml2.io.KXmlParser.parseStartTag(boolean):void");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final void pushEntity() throws java.io.IOException, org.xmlpull.v1.XmlPullParserException {
        /*
        r10 = this;
        r9 = 35;
        r7 = 0;
        r8 = 1;
        r5 = r10.read();
        r10.push(r5);
        r3 = r10.txtPos;
    L_0x000d:
        r0 = r10.peek(r7);
        r5 = 59;
        if (r0 != r5) goto L_0x0049;
    L_0x0015:
        r10.read();
        r1 = r10.get(r3);
        r5 = r3 - r8;
        r10.txtPos = r5;
        r5 = r10.token;
        if (r5 == 0) goto L_0x002b;
    L_0x0024:
        r5 = r10.type;
        r6 = 6;
        if (r5 != r6) goto L_0x002b;
    L_0x0029:
        r10.name = r1;
    L_0x002b:
        r5 = r1.charAt(r7);
        if (r5 != r9) goto L_0x00aa;
    L_0x0031:
        r5 = r1.charAt(r8);
        r6 = 120; // 0x78 float:1.68E-43 double:5.93E-322;
        if (r5 != r6) goto L_0x00a0;
    L_0x0039:
        r5 = 2;
        r5 = r1.substring(r5);
        r6 = 16;
        r5 = java.lang.Integer.parseInt(r5, r6);
        r0 = r5;
    L_0x0045:
        r10.push(r0);
    L_0x0048:
        return;
    L_0x0049:
        r5 = 128; // 0x80 float:1.794E-43 double:6.32E-322;
        if (r0 >= r5) goto L_0x0097;
    L_0x004d:
        r5 = 48;
        if (r0 < r5) goto L_0x0055;
    L_0x0051:
        r5 = 57;
        if (r0 <= r5) goto L_0x0097;
    L_0x0055:
        r5 = 97;
        if (r0 < r5) goto L_0x005d;
    L_0x0059:
        r5 = 122; // 0x7a float:1.71E-43 double:6.03E-322;
        if (r0 <= r5) goto L_0x0097;
    L_0x005d:
        r5 = 65;
        if (r0 < r5) goto L_0x0065;
    L_0x0061:
        r5 = 90;
        if (r0 <= r5) goto L_0x0097;
    L_0x0065:
        r5 = 95;
        if (r0 == r5) goto L_0x0097;
    L_0x0069:
        r5 = 45;
        if (r0 == r5) goto L_0x0097;
    L_0x006d:
        if (r0 == r9) goto L_0x0097;
    L_0x006f:
        r5 = r10.relaxed;
        if (r5 != 0) goto L_0x0078;
    L_0x0073:
        r5 = "unterminated entity ref";
        r10.error(r5);
    L_0x0078:
        r5 = java.lang.System.out;
        r6 = new java.lang.StringBuilder;
        r6.<init>();
        r7 = "broken entitiy: ";
        r6 = r6.append(r7);
        r7 = r3 - r8;
        r7 = r10.get(r7);
        r6 = r6.append(r7);
        r6 = r6.toString();
        r5.println(r6);
        goto L_0x0048;
    L_0x0097:
        r5 = r10.read();
        r10.push(r5);
        goto L_0x000d;
    L_0x00a0:
        r5 = r1.substring(r8);
        r5 = java.lang.Integer.parseInt(r5);
        r0 = r5;
        goto L_0x0045;
    L_0x00aa:
        r5 = r10.entityMap;
        r4 = r5.get(r1);
        r4 = (java.lang.String) r4;
        if (r4 != 0) goto L_0x00dd;
    L_0x00b4:
        r5 = r8;
    L_0x00b5:
        r10.unresolved = r5;
        r5 = r10.unresolved;
        if (r5 == 0) goto L_0x00df;
    L_0x00bb:
        r5 = r10.token;
        if (r5 != 0) goto L_0x0048;
    L_0x00bf:
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r6 = "unresolved: &";
        r5 = r5.append(r6);
        r5 = r5.append(r1);
        r6 = ";";
        r5 = r5.append(r6);
        r5 = r5.toString();
        r10.error(r5);
        goto L_0x0048;
    L_0x00dd:
        r5 = r7;
        goto L_0x00b5;
    L_0x00df:
        r2 = 0;
    L_0x00e0:
        r5 = r4.length();
        if (r2 >= r5) goto L_0x0048;
    L_0x00e6:
        r5 = r4.charAt(r2);
        r10.push(r5);
        r2 = r2 + 1;
        goto L_0x00e0;
        */
        throw new UnsupportedOperationException("Method not decompiled: org.kxml2.io.KXmlParser.pushEntity():void");
    }

    private final void pushText(int delimiter, boolean resolveEntities) throws IOException, XmlPullParserException {
        int next = peek(0);
        int cbrCount = 0;
        while (next != -1 && next != delimiter) {
            if (delimiter != 32 || (next > 32 && next != 62)) {
                if (next == 38) {
                    if (resolveEntities) {
                        pushEntity();
                    } else {
                        return;
                    }
                } else if (next == 10 && this.type == 2) {
                    read();
                    push(32);
                } else {
                    push(read());
                }
                if (next == 62 && cbrCount >= 2 && delimiter != 93) {
                    error("Illegal: ]]>");
                }
                if (next == 93) {
                    cbrCount++;
                } else {
                    cbrCount = 0;
                }
                next = peek(0);
            } else {
                return;
            }
        }
    }

    private final void read(char c) throws IOException, XmlPullParserException {
        char a = read();
        if (a != c) {
            error("expected: '" + c + "' actual: '" + ((char) a) + "'");
        }
    }

    private final int read() throws IOException {
        int result;
        if (this.peekCount == 0) {
            result = peek(0);
        } else {
            result = this.peek[0];
            this.peek[0] = this.peek[1];
        }
        this.peekCount--;
        this.column++;
        if (result == 10) {
            this.line++;
            this.column = 1;
        }
        return result;
    }

    private final int peek(int pos) throws IOException {
        while (pos >= this.peekCount) {
            int nw;
            if (this.srcBuf.length <= 1) {
                nw = this.reader.read();
            } else if (this.srcPos < this.srcCount) {
                char[] cArr = this.srcBuf;
                int i = this.srcPos;
                this.srcPos = i + 1;
                nw = cArr[i];
            } else {
                this.srcCount = this.reader.read(this.srcBuf, 0, this.srcBuf.length);
                if (this.srcCount <= 0) {
                    nw = -1;
                } else {
                    nw = this.srcBuf[0];
                }
                this.srcPos = 1;
            }
            int[] iArr;
            if (nw == 13) {
                this.wasCR = true;
                iArr = this.peek;
                i = this.peekCount;
                this.peekCount = i + 1;
                iArr[i] = 10;
            } else {
                if (nw != 10) {
                    iArr = this.peek;
                    i = this.peekCount;
                    this.peekCount = i + 1;
                    iArr[i] = nw;
                } else if (!this.wasCR) {
                    iArr = this.peek;
                    i = this.peekCount;
                    this.peekCount = i + 1;
                    iArr[i] = 10;
                }
                this.wasCR = false;
            }
        }
        return this.peek[pos];
    }

    private final String readName() throws IOException, XmlPullParserException {
        int pos = this.txtPos;
        int c = peek(0);
        if ((c < 97 || c > 122) && !((c >= 65 && c <= 90) || c == 95 || c == 58 || c >= Wbxml.EXT_0 || this.relaxed)) {
            error("name expected");
        }
        while (true) {
            push(read());
            c = peek(0);
            if ((c < 97 || c > 122) && ((c < 65 || c > 90) && !((c >= 48 && c <= 57) || c == 95 || c == 45 || c == 58 || c == 46 || c >= 183))) {
                String result = get(pos);
                this.txtPos = pos;
                return result;
            }
        }
    }

    private final void skip() throws IOException {
        while (true) {
            int c = peek(0);
            if (c <= 32 && c != -1) {
                read();
            } else {
                return;
            }
        }
    }

    public void setInput(Reader reader) throws XmlPullParserException {
        this.reader = reader;
        this.line = 1;
        this.column = 0;
        this.type = 0;
        this.name = null;
        this.namespace = null;
        this.degenerated = false;
        this.attributeCount = -1;
        this.encoding = null;
        this.version = null;
        this.standalone = null;
        if (reader != null) {
            this.srcPos = 0;
            this.srcCount = 0;
            this.peekCount = 0;
            this.depth = 0;
            this.entityMap = new Hashtable();
            this.entityMap.put("amp", "&");
            this.entityMap.put("apos", "'");
            this.entityMap.put("gt", ">");
            this.entityMap.put("lt", "<");
            this.entityMap.put("quot", "\"");
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void setInput(java.io.InputStream r20, java.lang.String r21) throws org.xmlpull.v1.XmlPullParserException {
        /*
        r19 = this;
        r14 = 0;
        r0 = r14;
        r1 = r19;
        r1.srcPos = r0;
        r14 = 0;
        r0 = r14;
        r1 = r19;
        r1.srcCount = r0;
        r7 = r21;
        if (r20 != 0) goto L_0x0016;
    L_0x0010:
        r14 = new java.lang.IllegalArgumentException;
        r14.<init>();
        throw r14;
    L_0x0016:
        if (r7 != 0) goto L_0x0067;
    L_0x0018:
        r4 = 0;
    L_0x0019:
        r0 = r19;
        r0 = r0.srcCount;	 Catch:{ Exception -> 0x00a9 }
        r14 = r0;
        r15 = 4;
        if (r14 >= r15) goto L_0x0028;
    L_0x0021:
        r8 = r20.read();	 Catch:{ Exception -> 0x00a9 }
        r14 = -1;
        if (r8 != r14) goto L_0x008b;
    L_0x0028:
        r0 = r19;
        r0 = r0.srcCount;	 Catch:{ Exception -> 0x00a9 }
        r14 = r0;
        r15 = 4;
        if (r14 != r15) goto L_0x0067;
    L_0x0030:
        switch(r4) {
            case -131072: goto L_0x00d6;
            case 60: goto L_0x00df;
            case 65279: goto L_0x00cd;
            case 3932223: goto L_0x0107;
            case 1006632960: goto L_0x00f3;
            case 1006649088: goto L_0x0125;
            case 1010792557: goto L_0x0143;
            default: goto L_0x0033;
        };	 Catch:{ Exception -> 0x00a9 }
    L_0x0033:
        r14 = -65536; // 0xffffffffffff0000 float:NaN double:NaN;
        r14 = r14 & r4;
        r15 = -16842752; // 0xfffffffffeff0000 float:-1.6947657E38 double:NaN;
        if (r14 != r15) goto L_0x01aa;
    L_0x003a:
        r7 = "UTF-16BE";
        r0 = r19;
        r0 = r0.srcBuf;	 Catch:{ Exception -> 0x00a9 }
        r14 = r0;
        r15 = 0;
        r0 = r19;
        r0 = r0.srcBuf;	 Catch:{ Exception -> 0x00a9 }
        r16 = r0;
        r17 = 2;
        r16 = r16[r17];	 Catch:{ Exception -> 0x00a9 }
        r16 = r16 << 8;
        r0 = r19;
        r0 = r0.srcBuf;	 Catch:{ Exception -> 0x00a9 }
        r17 = r0;
        r18 = 3;
        r17 = r17[r18];	 Catch:{ Exception -> 0x00a9 }
        r16 = r16 | r17;
        r0 = r16;
        r0 = (char) r0;	 Catch:{ Exception -> 0x00a9 }
        r16 = r0;
        r14[r15] = r16;	 Catch:{ Exception -> 0x00a9 }
        r14 = 1;
        r0 = r14;
        r1 = r19;
        r1.srcCount = r0;	 Catch:{ Exception -> 0x00a9 }
    L_0x0067:
        if (r7 != 0) goto L_0x006b;
    L_0x0069:
        r7 = "UTF-8";
    L_0x006b:
        r0 = r19;
        r0 = r0.srcCount;	 Catch:{ Exception -> 0x00a9 }
        r13 = r0;
        r14 = new java.io.InputStreamReader;	 Catch:{ Exception -> 0x00a9 }
        r0 = r14;
        r1 = r20;
        r2 = r7;
        r0.<init>(r1, r2);	 Catch:{ Exception -> 0x00a9 }
        r0 = r19;
        r1 = r14;
        r0.setInput(r1);	 Catch:{ Exception -> 0x00a9 }
        r0 = r21;
        r1 = r19;
        r1.encoding = r0;	 Catch:{ Exception -> 0x00a9 }
        r0 = r13;
        r1 = r19;
        r1.srcCount = r0;	 Catch:{ Exception -> 0x00a9 }
        return;
    L_0x008b:
        r14 = r4 << 8;
        r4 = r14 | r8;
        r0 = r19;
        r0 = r0.srcBuf;	 Catch:{ Exception -> 0x00a9 }
        r14 = r0;
        r0 = r19;
        r0 = r0.srcCount;	 Catch:{ Exception -> 0x00a9 }
        r15 = r0;
        r16 = r15 + 1;
        r0 = r16;
        r1 = r19;
        r1.srcCount = r0;	 Catch:{ Exception -> 0x00a9 }
        r0 = r8;
        r0 = (char) r0;	 Catch:{ Exception -> 0x00a9 }
        r16 = r0;
        r14[r15] = r16;	 Catch:{ Exception -> 0x00a9 }
        goto L_0x0019;
    L_0x00a9:
        r14 = move-exception;
        r6 = r14;
        r14 = new org.xmlpull.v1.XmlPullParserException;
        r15 = new java.lang.StringBuilder;
        r15.<init>();
        r16 = "Invalid stream or encoding: ";
        r15 = r15.append(r16);
        r16 = r6.toString();
        r15 = r15.append(r16);
        r15 = r15.toString();
        r0 = r14;
        r1 = r15;
        r2 = r19;
        r3 = r6;
        r0.<init>(r1, r2, r3);
        throw r14;
    L_0x00cd:
        r7 = "UTF-32BE";
        r14 = 0;
        r0 = r14;
        r1 = r19;
        r1.srcCount = r0;	 Catch:{ Exception -> 0x00a9 }
        goto L_0x0067;
    L_0x00d6:
        r7 = "UTF-32LE";
        r14 = 0;
        r0 = r14;
        r1 = r19;
        r1.srcCount = r0;	 Catch:{ Exception -> 0x00a9 }
        goto L_0x0067;
    L_0x00df:
        r7 = "UTF-32BE";
        r0 = r19;
        r0 = r0.srcBuf;	 Catch:{ Exception -> 0x00a9 }
        r14 = r0;
        r15 = 0;
        r16 = 60;
        r14[r15] = r16;	 Catch:{ Exception -> 0x00a9 }
        r14 = 1;
        r0 = r14;
        r1 = r19;
        r1.srcCount = r0;	 Catch:{ Exception -> 0x00a9 }
        goto L_0x0067;
    L_0x00f3:
        r7 = "UTF-32LE";
        r0 = r19;
        r0 = r0.srcBuf;	 Catch:{ Exception -> 0x00a9 }
        r14 = r0;
        r15 = 0;
        r16 = 60;
        r14[r15] = r16;	 Catch:{ Exception -> 0x00a9 }
        r14 = 1;
        r0 = r14;
        r1 = r19;
        r1.srcCount = r0;	 Catch:{ Exception -> 0x00a9 }
        goto L_0x0067;
    L_0x0107:
        r7 = "UTF-16BE";
        r0 = r19;
        r0 = r0.srcBuf;	 Catch:{ Exception -> 0x00a9 }
        r14 = r0;
        r15 = 0;
        r16 = 60;
        r14[r15] = r16;	 Catch:{ Exception -> 0x00a9 }
        r0 = r19;
        r0 = r0.srcBuf;	 Catch:{ Exception -> 0x00a9 }
        r14 = r0;
        r15 = 1;
        r16 = 63;
        r14[r15] = r16;	 Catch:{ Exception -> 0x00a9 }
        r14 = 2;
        r0 = r14;
        r1 = r19;
        r1.srcCount = r0;	 Catch:{ Exception -> 0x00a9 }
        goto L_0x0067;
    L_0x0125:
        r7 = "UTF-16LE";
        r0 = r19;
        r0 = r0.srcBuf;	 Catch:{ Exception -> 0x00a9 }
        r14 = r0;
        r15 = 0;
        r16 = 60;
        r14[r15] = r16;	 Catch:{ Exception -> 0x00a9 }
        r0 = r19;
        r0 = r0.srcBuf;	 Catch:{ Exception -> 0x00a9 }
        r14 = r0;
        r15 = 1;
        r16 = 63;
        r14[r15] = r16;	 Catch:{ Exception -> 0x00a9 }
        r14 = 2;
        r0 = r14;
        r1 = r19;
        r1.srcCount = r0;	 Catch:{ Exception -> 0x00a9 }
        goto L_0x0067;
    L_0x0143:
        r8 = r20.read();	 Catch:{ Exception -> 0x00a9 }
        r14 = -1;
        if (r8 == r14) goto L_0x0033;
    L_0x014a:
        r0 = r19;
        r0 = r0.srcBuf;	 Catch:{ Exception -> 0x00a9 }
        r14 = r0;
        r0 = r19;
        r0 = r0.srcCount;	 Catch:{ Exception -> 0x00a9 }
        r15 = r0;
        r16 = r15 + 1;
        r0 = r16;
        r1 = r19;
        r1.srcCount = r0;	 Catch:{ Exception -> 0x00a9 }
        r0 = r8;
        r0 = (char) r0;	 Catch:{ Exception -> 0x00a9 }
        r16 = r0;
        r14[r15] = r16;	 Catch:{ Exception -> 0x00a9 }
        r14 = 62;
        if (r8 != r14) goto L_0x0143;
    L_0x0166:
        r12 = new java.lang.String;	 Catch:{ Exception -> 0x00a9 }
        r0 = r19;
        r0 = r0.srcBuf;	 Catch:{ Exception -> 0x00a9 }
        r14 = r0;
        r15 = 0;
        r0 = r19;
        r0 = r0.srcCount;	 Catch:{ Exception -> 0x00a9 }
        r16 = r0;
        r0 = r12;
        r1 = r14;
        r2 = r15;
        r3 = r16;
        r0.<init>(r1, r2, r3);	 Catch:{ Exception -> 0x00a9 }
        r14 = "encoding";
        r9 = r12.indexOf(r14);	 Catch:{ Exception -> 0x00a9 }
        r14 = -1;
        if (r9 == r14) goto L_0x0033;
    L_0x0185:
        r10 = r9;
    L_0x0186:
        r14 = r12.charAt(r10);	 Catch:{ Exception -> 0x00a9 }
        r15 = 34;
        if (r14 == r15) goto L_0x019a;
    L_0x018e:
        r14 = r12.charAt(r10);	 Catch:{ Exception -> 0x00a9 }
        r15 = 39;
        if (r14 == r15) goto L_0x019a;
    L_0x0196:
        r9 = r10 + 1;
        r10 = r9;
        goto L_0x0186;
    L_0x019a:
        r9 = r10 + 1;
        r5 = r12.charAt(r10);	 Catch:{ Exception -> 0x00a9 }
        r11 = r12.indexOf(r5, r9);	 Catch:{ Exception -> 0x00a9 }
        r7 = r12.substring(r9, r11);	 Catch:{ Exception -> 0x00a9 }
        goto L_0x0033;
    L_0x01aa:
        r14 = -65536; // 0xffffffffffff0000 float:NaN double:NaN;
        r14 = r14 & r4;
        r15 = -131072; // 0xfffffffffffe0000 float:NaN double:NaN;
        if (r14 != r15) goto L_0x01e0;
    L_0x01b1:
        r7 = "UTF-16LE";
        r0 = r19;
        r0 = r0.srcBuf;	 Catch:{ Exception -> 0x00a9 }
        r14 = r0;
        r15 = 0;
        r0 = r19;
        r0 = r0.srcBuf;	 Catch:{ Exception -> 0x00a9 }
        r16 = r0;
        r17 = 3;
        r16 = r16[r17];	 Catch:{ Exception -> 0x00a9 }
        r16 = r16 << 8;
        r0 = r19;
        r0 = r0.srcBuf;	 Catch:{ Exception -> 0x00a9 }
        r17 = r0;
        r18 = 2;
        r17 = r17[r18];	 Catch:{ Exception -> 0x00a9 }
        r16 = r16 | r17;
        r0 = r16;
        r0 = (char) r0;	 Catch:{ Exception -> 0x00a9 }
        r16 = r0;
        r14[r15] = r16;	 Catch:{ Exception -> 0x00a9 }
        r14 = 1;
        r0 = r14;
        r1 = r19;
        r1.srcCount = r0;	 Catch:{ Exception -> 0x00a9 }
        goto L_0x0067;
    L_0x01e0:
        r14 = r4 & -256;
        r15 = -272908544; // 0xffffffffefbbbf00 float:-1.162092E29 double:NaN;
        if (r14 != r15) goto L_0x0067;
    L_0x01e7:
        r7 = "UTF-8";
        r0 = r19;
        r0 = r0.srcBuf;	 Catch:{ Exception -> 0x00a9 }
        r14 = r0;
        r15 = 0;
        r0 = r19;
        r0 = r0.srcBuf;	 Catch:{ Exception -> 0x00a9 }
        r16 = r0;
        r17 = 3;
        r16 = r16[r17];	 Catch:{ Exception -> 0x00a9 }
        r14[r15] = r16;	 Catch:{ Exception -> 0x00a9 }
        r14 = 1;
        r0 = r14;
        r1 = r19;
        r1.srcCount = r0;	 Catch:{ Exception -> 0x00a9 }
        goto L_0x0067;
        */
        throw new UnsupportedOperationException("Method not decompiled: org.kxml2.io.KXmlParser.setInput(java.io.InputStream, java.lang.String):void");
    }

    public boolean getFeature(String feature) {
        if ("http://xmlpull.org/v1/doc/features.html#process-namespaces".equals(feature)) {
            return this.processNsp;
        }
        return isProp(feature, false, "relaxed") ? this.relaxed : false;
    }

    public String getInputEncoding() {
        return this.encoding;
    }

    public void defineEntityReplacementText(String entity, String value) throws XmlPullParserException {
        if (this.entityMap == null) {
            throw new RuntimeException("entity replacement text must be defined after setInput!");
        }
        this.entityMap.put(entity, value);
    }

    public Object getProperty(String property) {
        if (isProp(property, true, "xmldecl-version")) {
            return this.version;
        }
        if (isProp(property, true, "xmldecl-standalone")) {
            return this.standalone;
        }
        if (isProp(property, true, "location")) {
            return this.location != null ? this.location : this.reader.toString();
        } else {
            return null;
        }
    }

    public int getNamespaceCount(int depth) {
        if (depth <= this.depth) {
            return this.nspCounts[depth];
        }
        throw new IndexOutOfBoundsException();
    }

    public String getNamespacePrefix(int pos) {
        return this.nspStack[pos << 1];
    }

    public String getNamespaceUri(int pos) {
        return this.nspStack[(pos << 1) + 1];
    }

    public String getNamespace(String prefix) {
        if ("xml".equals(prefix)) {
            return "http://www.w3.org/XML/1998/namespace";
        }
        if ("xmlns".equals(prefix)) {
            return "http://www.w3.org/2000/xmlns/";
        }
        for (int i = (getNamespaceCount(this.depth) << 1) - 2; i >= 0; i -= 2) {
            if (prefix == null) {
                if (this.nspStack[i] == null) {
                    return this.nspStack[i + 1];
                }
            } else if (prefix.equals(this.nspStack[i])) {
                return this.nspStack[i + 1];
            }
        }
        return null;
    }

    public int getDepth() {
        return this.depth;
    }

    public String getPositionDescription() {
        String str;
        String str2 = " in ";
        String str3 = ":";
        StringBuffer buf = new StringBuffer(this.type < TYPES.length ? TYPES[this.type] : "unknown");
        buf.append(' ');
        if (this.type == 2 || this.type == 3) {
            if (this.degenerated) {
                buf.append("(empty) ");
            }
            buf.append('<');
            if (this.type == 3) {
                buf.append('/');
            }
            if (this.prefix != null) {
                str = ":";
                buf.append("{" + this.namespace + "}" + this.prefix + str3);
            }
            buf.append(this.name);
            int cnt = this.attributeCount << 2;
            for (int i = 0; i < cnt; i += 4) {
                buf.append(' ');
                if (this.attributes[i + 1] != null) {
                    str = ":";
                    buf.append("{" + this.attributes[i] + "}" + this.attributes[i + 1] + str3);
                }
                buf.append(this.attributes[i + 2] + "='" + this.attributes[i + 3] + "'");
            }
            buf.append('>');
        } else if (this.type != 7) {
            if (this.type != 4) {
                buf.append(getText());
            } else if (this.isWhitespace) {
                buf.append("(whitespace)");
            } else {
                String text = getText();
                if (text.length() > 16) {
                    text = text.substring(0, 16) + "...";
                }
                buf.append(text);
            }
        }
        str = ":";
        buf.append("@" + this.line + str3 + this.column);
        String str4;
        if (this.location != null) {
            str4 = " in ";
            buf.append(str2);
            buf.append(this.location);
        } else if (this.reader != null) {
            str4 = " in ";
            buf.append(str2);
            buf.append(this.reader.toString());
        }
        return buf.toString();
    }

    public int getLineNumber() {
        return this.line;
    }

    public int getColumnNumber() {
        return this.column;
    }

    public boolean isWhitespace() throws XmlPullParserException {
        if (!(this.type == 4 || this.type == 7 || this.type == 5)) {
            exception(ILLEGAL_TYPE);
        }
        return this.isWhitespace;
    }

    public String getText() {
        return (this.type < 4 || (this.type == 6 && this.unresolved)) ? null : get(0);
    }

    public char[] getTextCharacters(int[] poslen) {
        if (this.type < 4) {
            poslen[0] = -1;
            poslen[1] = -1;
            return null;
        } else if (this.type == 6) {
            poslen[0] = 0;
            poslen[1] = this.name.length();
            return this.name.toCharArray();
        } else {
            poslen[0] = 0;
            poslen[1] = this.txtPos;
            return this.txtBuf;
        }
    }

    public String getNamespace() {
        return this.namespace;
    }

    public String getName() {
        return this.name;
    }

    public String getPrefix() {
        return this.prefix;
    }

    public boolean isEmptyElementTag() throws XmlPullParserException {
        if (this.type != 2) {
            exception(ILLEGAL_TYPE);
        }
        return this.degenerated;
    }

    public int getAttributeCount() {
        return this.attributeCount;
    }

    public String getAttributeType(int index) {
        return "CDATA";
    }

    public boolean isAttributeDefault(int index) {
        return false;
    }

    public String getAttributeNamespace(int index) {
        if (index < this.attributeCount) {
            return this.attributes[index << 2];
        }
        throw new IndexOutOfBoundsException();
    }

    public String getAttributeName(int index) {
        if (index < this.attributeCount) {
            return this.attributes[(index << 2) + 2];
        }
        throw new IndexOutOfBoundsException();
    }

    public String getAttributePrefix(int index) {
        if (index < this.attributeCount) {
            return this.attributes[(index << 2) + 1];
        }
        throw new IndexOutOfBoundsException();
    }

    public String getAttributeValue(int index) {
        if (index < this.attributeCount) {
            return this.attributes[(index << 2) + 3];
        }
        throw new IndexOutOfBoundsException();
    }

    public String getAttributeValue(String namespace, String name) {
        int i = (this.attributeCount << 2) - 4;
        while (i >= 0) {
            if (this.attributes[i + 2].equals(name) && (namespace == null || this.attributes[i].equals(namespace))) {
                return this.attributes[i + 3];
            }
            i -= 4;
        }
        return null;
    }

    public int getEventType() throws XmlPullParserException {
        return this.type;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int next() throws org.xmlpull.v1.XmlPullParserException, java.io.IOException {
        /*
        r4 = this;
        r3 = 0;
        r2 = 4;
        r4.txtPos = r3;
        r1 = 1;
        r4.isWhitespace = r1;
        r0 = 9999; // 0x270f float:1.4012E-41 double:4.94E-320;
        r4.token = r3;
    L_0x000b:
        r4.nextImpl();
        r1 = r4.type;
        if (r1 >= r0) goto L_0x0014;
    L_0x0012:
        r0 = r4.type;
    L_0x0014:
        r1 = 6;
        if (r0 > r1) goto L_0x000b;
    L_0x0017:
        if (r0 < r2) goto L_0x001f;
    L_0x0019:
        r1 = r4.peekType();
        if (r1 >= r2) goto L_0x000b;
    L_0x001f:
        r4.type = r0;
        r1 = r4.type;
        if (r1 <= r2) goto L_0x0027;
    L_0x0025:
        r4.type = r2;
    L_0x0027:
        r1 = r4.type;
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: org.kxml2.io.KXmlParser.next():int");
    }

    public int nextToken() throws XmlPullParserException, IOException {
        this.isWhitespace = true;
        this.txtPos = 0;
        this.token = true;
        nextImpl();
        return this.type;
    }

    public int nextTag() throws XmlPullParserException, IOException {
        next();
        if (this.type == 4 && this.isWhitespace) {
            next();
        }
        if (!(this.type == 3 || this.type == 2)) {
            exception("unexpected type");
        }
        return this.type;
    }

    public void require(int type, String namespace, String name) throws XmlPullParserException, IOException {
        if (type != this.type || ((namespace != null && !namespace.equals(getNamespace())) || (name != null && !name.equals(getName())))) {
            exception("expected: " + TYPES[type] + " {" + namespace + "}" + name);
        }
    }

    public String nextText() throws XmlPullParserException, IOException {
        String result;
        if (this.type != 2) {
            exception("precondition: START_TAG");
        }
        next();
        if (this.type == 4) {
            result = getText();
            next();
        } else {
            result = StringUtils.EMPTY;
        }
        if (this.type != 3) {
            exception("END_TAG expected");
        }
        return result;
    }

    public void setFeature(String feature, boolean value) throws XmlPullParserException {
        if ("http://xmlpull.org/v1/doc/features.html#process-namespaces".equals(feature)) {
            this.processNsp = value;
        } else if (isProp(feature, false, "relaxed")) {
            this.relaxed = value;
        } else {
            exception("unsupported feature: " + feature);
        }
    }

    public void setProperty(String property, Object value) throws XmlPullParserException {
        if (isProp(property, true, "location")) {
            this.location = value;
            return;
        }
        throw new XmlPullParserException("unsupported property: " + property);
    }

    public void skipSubTree() throws XmlPullParserException, IOException {
        require(2, null, null);
        int level = 1;
        while (level > 0) {
            int eventType = next();
            if (eventType == 3) {
                level--;
            } else if (eventType == 2) {
                level++;
            }
        }
    }
}
