package org.jsoup.nodes;

import java.util.Map.Entry;
import org.apache.commons.lang.StringUtils;
import org.jsoup.helper.Validate;
import org.jsoup.nodes.Document.OutputSettings;

public class Attribute implements Entry<String, String>, Cloneable {
    private String key;
    private String value;

    public Attribute(String key, String value) {
        Validate.notEmpty(key);
        Validate.notNull(value);
        this.key = key.trim().toLowerCase();
        this.value = value;
    }

    public String getKey() {
        return this.key;
    }

    public void setKey(String key) {
        Validate.notEmpty(key);
        this.key = key.trim().toLowerCase();
    }

    public String getValue() {
        return this.value;
    }

    public String setValue(String value) {
        Validate.notNull(value);
        String old = this.value;
        this.value = value;
        return old;
    }

    public String html() {
        return this.key + "=\"" + Entities.escape(this.value, new Document(StringUtils.EMPTY).outputSettings()) + "\"";
    }

    protected void html(StringBuilder accum, OutputSettings out) {
        accum.append(this.key).append("=\"").append(Entities.escape(this.value, out)).append("\"");
    }

    public String toString() {
        return html();
    }

    public static Attribute createFromEncoded(String unencodedKey, String encodedValue) {
        return new Attribute(unencodedKey, Entities.unescape(encodedValue, true));
    }

    protected boolean isDataAttribute() {
        String str = "data-";
        String str2 = "data-";
        if (this.key.startsWith(str)) {
            str2 = "data-";
            if (this.key.length() > str.length()) {
                return true;
            }
        }
        return false;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Attribute)) {
            return false;
        }
        Attribute attribute = (Attribute) o;
        if (this.key == null ? attribute.key != null : !this.key.equals(attribute.key)) {
            return false;
        }
        return this.value == null ? attribute.value != null : !this.value.equals(attribute.value);
    }

    public int hashCode() {
        int result;
        int hashCode;
        if (this.key != null) {
            result = this.key.hashCode();
        } else {
            result = 0;
        }
        int i = result * 31;
        if (this.value != null) {
            hashCode = this.value.hashCode();
        } else {
            hashCode = 0;
        }
        return i + hashCode;
    }

    public Attribute clone() {
        try {
            return (Attribute) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
    }
}
