package org.jsoup.nodes;

import org.jsoup.helper.StringUtil;
import org.jsoup.helper.Validate;
import org.jsoup.nodes.Document.OutputSettings;

public class DocumentType extends Node {
    public DocumentType(String name, String publicId, String systemId, String baseUri) {
        super(baseUri);
        Validate.notEmpty(name);
        attr("name", name);
        attr("publicId", publicId);
        attr("systemId", systemId);
    }

    public String nodeName() {
        return "#doctype";
    }

    void outerHtmlHead(StringBuilder accum, int depth, OutputSettings out) {
        String str = "systemId";
        String str2 = "publicId";
        String str3 = "\"";
        accum.append("<!DOCTYPE ").append(attr("name"));
        String str4 = "publicId";
        if (!StringUtil.isBlank(attr(str2))) {
            String str5 = "publicId";
            str5 = "\"";
            accum.append(" PUBLIC \"").append(attr(str2)).append(str3);
        }
        str4 = "systemId";
        if (!StringUtil.isBlank(attr(str))) {
            str5 = "systemId";
            str5 = "\"";
            accum.append(" \"").append(attr(str)).append(str3);
        }
        accum.append('>');
    }

    void outerHtmlTail(StringBuilder accum, int depth, OutputSettings out) {
    }
}
