package org.jsoup.select;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import org.jsoup.helper.StringUtil;
import org.jsoup.helper.Validate;
import org.jsoup.parser.TokenQueue;
import org.jsoup.select.Evaluator.AllElements;
import org.jsoup.select.Evaluator.Attribute;
import org.jsoup.select.Evaluator.AttributeStarting;
import org.jsoup.select.Evaluator.AttributeWithValue;
import org.jsoup.select.Evaluator.AttributeWithValueContaining;
import org.jsoup.select.Evaluator.AttributeWithValueEnding;
import org.jsoup.select.Evaluator.AttributeWithValueMatching;
import org.jsoup.select.Evaluator.AttributeWithValueNot;
import org.jsoup.select.Evaluator.AttributeWithValueStarting;
import org.jsoup.select.Evaluator.Class;
import org.jsoup.select.Evaluator.ContainsOwnText;
import org.jsoup.select.Evaluator.ContainsText;
import org.jsoup.select.Evaluator.Id;
import org.jsoup.select.Evaluator.IndexEquals;
import org.jsoup.select.Evaluator.IndexGreaterThan;
import org.jsoup.select.Evaluator.IndexLessThan;
import org.jsoup.select.Evaluator.Matches;
import org.jsoup.select.Evaluator.MatchesOwn;
import org.jsoup.select.Evaluator.Tag;
import org.jsoup.select.Selector.SelectorParseException;

class QueryParser {
    private static final String[] combinators;
    private List<Evaluator> evals;
    private String query;
    private TokenQueue tq;

    static {
        combinators = new String[]{",", ">", "+", "~", " "};
    }

    private QueryParser(String query) {
        this.evals = new ArrayList();
        this.query = query;
        this.tq = new TokenQueue(query);
    }

    public static Evaluator parse(String query) {
        return new QueryParser(query).parse();
    }

    Evaluator parse() {
        String str = ",";
        this.tq.consumeWhitespace();
        if (this.tq.matchesAny(combinators)) {
            this.evals.add(new Root());
            combinator(this.tq.consume());
        } else {
            findElements();
        }
        while (!this.tq.isEmpty()) {
            boolean seenWhite = this.tq.consumeWhitespace();
            String str2 = ",";
            if (this.tq.matchChomp(str)) {
                Or or = new Or(this.evals);
                this.evals.clear();
                this.evals.add(or);
                while (!this.tq.isEmpty()) {
                    str2 = ",";
                    or.add(parse(this.tq.chompTo(str)));
                }
            } else if (this.tq.matchesAny(combinators)) {
                combinator(this.tq.consume());
            } else if (seenWhite) {
                combinator(' ');
            } else {
                findElements();
            }
        }
        if (this.evals.size() == 1) {
            return (Evaluator) this.evals.get(0);
        }
        return new And(this.evals);
    }

    private void combinator(char combinator) {
        Evaluator e;
        this.tq.consumeWhitespace();
        String subQuery = consumeSubQuery();
        if (this.evals.size() == 1) {
            e = (Evaluator) this.evals.get(0);
        } else {
            e = new And(this.evals);
        }
        this.evals.clear();
        Evaluator f = parse(subQuery);
        if (combinator == '>') {
            this.evals.add(new And(f, new ImmediateParent(e)));
        } else if (combinator == ' ') {
            this.evals.add(new And(f, new Parent(e)));
        } else if (combinator == '+') {
            this.evals.add(new And(f, new ImmediatePreviousSibling(e)));
        } else if (combinator == '~') {
            this.evals.add(new And(f, new PreviousSibling(e)));
        } else {
            throw new SelectorParseException("Unknown combinator: " + combinator, new Object[0]);
        }
    }

    private String consumeSubQuery() {
        String str = "[";
        String str2 = "(";
        StringBuilder sq = new StringBuilder();
        while (!this.tq.isEmpty()) {
            String str3 = "(";
            String str4;
            if (!this.tq.matches(str2)) {
                str3 = "[";
                if (!this.tq.matches(str)) {
                    if (this.tq.matchesAny(combinators)) {
                        break;
                    }
                    sq.append(this.tq.consume());
                } else {
                    str4 = "[";
                    sq.append(str).append(this.tq.chompBalanced('[', ']')).append("]");
                }
            } else {
                str4 = "(";
                sq.append(str2).append(this.tq.chompBalanced('(', ')')).append(")");
            }
        }
        return sq.toString();
    }

    private void findElements() {
        if (this.tq.matchChomp("#")) {
            byId();
        } else if (this.tq.matchChomp(".")) {
            byClass();
        } else if (this.tq.matchesWord()) {
            byTag();
        } else if (this.tq.matches("[")) {
            byAttribute();
        } else if (this.tq.matchChomp("*")) {
            allElements();
        } else if (this.tq.matchChomp(":lt(")) {
            indexLessThan();
        } else if (this.tq.matchChomp(":gt(")) {
            indexGreaterThan();
        } else if (this.tq.matchChomp(":eq(")) {
            indexEquals();
        } else if (this.tq.matches(":has(")) {
            has();
        } else if (this.tq.matches(":contains(")) {
            contains(false);
        } else if (this.tq.matches(":containsOwn(")) {
            contains(true);
        } else if (this.tq.matches(":matches(")) {
            matches(false);
        } else if (this.tq.matches(":matchesOwn(")) {
            matches(true);
        } else if (this.tq.matches(":not(")) {
            not();
        } else {
            throw new SelectorParseException("Could not parse query '%s': unexpected token at '%s'", this.query, this.tq.remainder());
        }
    }

    private void byId() {
        String id = this.tq.consumeCssIdentifier();
        Validate.notEmpty(id);
        this.evals.add(new Id(id));
    }

    private void byClass() {
        String className = this.tq.consumeCssIdentifier();
        Validate.notEmpty(className);
        this.evals.add(new Class(className.trim().toLowerCase()));
    }

    private void byTag() {
        CharSequence charSequence = "|";
        String tagName = this.tq.consumeElementSelector();
        Validate.notEmpty(tagName);
        String str = "|";
        if (tagName.contains(charSequence)) {
            str = "|";
            tagName = tagName.replace(charSequence, ":");
        }
        this.evals.add(new Tag(tagName.trim().toLowerCase()));
    }

    private void byAttribute() {
        String str = "$=";
        String str2 = "!=";
        TokenQueue cq = new TokenQueue(this.tq.chompBalanced('[', ']'));
        r2 = new String[6];
        String str3 = "!=";
        r2[1] = str2;
        r2[2] = "^=";
        String str4 = "$=";
        r2[3] = str;
        r2[4] = "*=";
        r2[5] = "~=";
        String key = cq.consumeToAny(r2);
        Validate.notEmpty(key);
        cq.consumeWhitespace();
        if (cq.isEmpty()) {
            if (key.startsWith("^")) {
                this.evals.add(new AttributeStarting(key.substring(1)));
            } else {
                this.evals.add(new Attribute(key));
            }
        } else if (cq.matchChomp("=")) {
            this.evals.add(new AttributeWithValue(key, cq.remainder()));
        } else {
            String str5 = "!=";
            if (cq.matchChomp(str2)) {
                this.evals.add(new AttributeWithValueNot(key, cq.remainder()));
            } else if (cq.matchChomp("^=")) {
                this.evals.add(new AttributeWithValueStarting(key, cq.remainder()));
            } else {
                str5 = "$=";
                if (cq.matchChomp(str)) {
                    this.evals.add(new AttributeWithValueEnding(key, cq.remainder()));
                } else if (cq.matchChomp("*=")) {
                    this.evals.add(new AttributeWithValueContaining(key, cq.remainder()));
                } else if (cq.matchChomp("~=")) {
                    this.evals.add(new AttributeWithValueMatching(key, Pattern.compile(cq.remainder())));
                } else {
                    throw new SelectorParseException("Could not parse attribute query '%s': unexpected token at '%s'", this.query, cq.remainder());
                }
            }
        }
    }

    private void allElements() {
        this.evals.add(new AllElements());
    }

    private void indexLessThan() {
        this.evals.add(new IndexLessThan(consumeIndex()));
    }

    private void indexGreaterThan() {
        this.evals.add(new IndexGreaterThan(consumeIndex()));
    }

    private void indexEquals() {
        this.evals.add(new IndexEquals(consumeIndex()));
    }

    private int consumeIndex() {
        String indexS = this.tq.chompTo(")").trim();
        Validate.isTrue(StringUtil.isNumeric(indexS), "Index must be numeric");
        return Integer.parseInt(indexS);
    }

    private void has() {
        this.tq.consume(":has");
        String subQuery = this.tq.chompBalanced('(', ')');
        Validate.notEmpty(subQuery, ":has(el) subselect must not be empty");
        this.evals.add(new Has(parse(subQuery)));
    }

    private void contains(boolean own) {
        this.tq.consume(own ? ":containsOwn" : ":contains");
        String searchText = TokenQueue.unescape(this.tq.chompBalanced('(', ')'));
        Validate.notEmpty(searchText, ":contains(text) query must not be empty");
        if (own) {
            this.evals.add(new ContainsOwnText(searchText));
        } else {
            this.evals.add(new ContainsText(searchText));
        }
    }

    private void matches(boolean own) {
        this.tq.consume(own ? ":matchesOwn" : ":matches");
        String regex = this.tq.chompBalanced('(', ')');
        Validate.notEmpty(regex, ":matches(regex) query must not be empty");
        if (own) {
            this.evals.add(new MatchesOwn(Pattern.compile(regex)));
        } else {
            this.evals.add(new Matches(Pattern.compile(regex)));
        }
    }

    private void not() {
        this.tq.consume(":not");
        String subQuery = this.tq.chompBalanced('(', ')');
        Validate.notEmpty(subQuery, ":not(selector) subselect must not be empty");
        this.evals.add(new Not(parse(subQuery)));
    }
}
