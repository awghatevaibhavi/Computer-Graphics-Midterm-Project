package org.jsoup.examples;

import java.io.IOException;
import java.util.Iterator;
import org.jsoup.Jsoup;
import org.jsoup.helper.Validate;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class ListLinks {
    public static void main(String[] url) throws IOException {
        Validate.isTrue(url.length == 1, "usage: supply url to fetch");
        print("Fetching %s...", url[0]);
        Elements imports = Jsoup.connect(url).get();
        Elements links = imports.select("a[href]");
        Elements media = imports.select("[src]");
        imports = imports.select("link[href]");
        print("\nMedia: (%d)", Integer.valueOf(media.size()));
        Iterator it = media.iterator();
        while (it.hasNext()) {
            if (((Element) it.next()).tagName().equals("img")) {
                print(" * %s: <%s> %sx%s (%s)", ((Element) it.next()).tagName(), ((Element) it.next()).attr("abs:src"), ((Element) it.next()).attr("width"), ((Element) it.next()).attr("height"), trim(((Element) it.next()).attr("alt"), 20));
            } else {
                print(" * %s: <%s>", ((Element) it.next()).tagName(), ((Element) it.next()).attr("abs:src"));
            }
        }
        print("\nImports: (%d)", Integer.valueOf(imports.size()));
        Iterator it2 = imports.iterator();
        while (it2.hasNext()) {
            Element link = (Element) it2.next();
            print(" * %s <%s> (%s)", link.tagName(), link.attr("abs:href"), link.attr("rel"));
        }
        print("\nLinks: (%d)", Integer.valueOf(links.size()));
        links = links.iterator();
        while (links.hasNext() != null) {
            link = (Element) links.next();
            print(" * a: <%s>  (%s)", link.attr("abs:href"), trim(link.text(), 35));
        }
    }

    private static void print(String msg, Object... args) {
        System.out.println(String.format(msg, args));
    }

    private static String trim(String s, int width) {
        if (s.length() > width) {
            return s.substring(0, width - 1) + ".";
        }
        return s;
    }
}
