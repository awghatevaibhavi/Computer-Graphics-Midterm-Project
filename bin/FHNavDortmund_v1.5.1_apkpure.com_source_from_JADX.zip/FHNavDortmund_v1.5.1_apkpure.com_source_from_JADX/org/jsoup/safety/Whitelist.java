package org.jsoup.safety;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.jsoup.helper.Validate;
import org.jsoup.nodes.Attribute;
import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.Element;

public class Whitelist {
    private Map<TagName, Set<AttributeKey>> attributes;
    private Map<TagName, Map<AttributeKey, AttributeValue>> enforcedAttributes;
    private Map<TagName, Map<AttributeKey, Set<Protocol>>> protocols;
    private Set<TagName> tagNames;

    static abstract class TypedValue {
        private String value;

        TypedValue(String value) {
            Validate.notNull(value);
            this.value = value;
        }

        public int hashCode() {
            int i = 1 * 31;
            return (this.value == null ? 0 : this.value.hashCode()) + 31;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            TypedValue other = (TypedValue) obj;
            if (this.value == null) {
                if (other.value != null) {
                    return false;
                }
            } else if (!this.value.equals(other.value)) {
                return false;
            }
            return true;
        }

        public String toString() {
            return this.value;
        }
    }

    static class AttributeKey extends TypedValue {
        AttributeKey(String value) {
            super(value);
        }

        static AttributeKey valueOf(String value) {
            return new AttributeKey(value);
        }
    }

    static class AttributeValue extends TypedValue {
        AttributeValue(String value) {
            super(value);
        }

        static AttributeValue valueOf(String value) {
            return new AttributeValue(value);
        }
    }

    static class Protocol extends TypedValue {
        Protocol(String value) {
            super(value);
        }

        static Protocol valueOf(String value) {
            return new Protocol(value);
        }
    }

    static class TagName extends TypedValue {
        TagName(String value) {
            super(value);
        }

        static TagName valueOf(String value) {
            return new TagName(value);
        }
    }

    public static Whitelist none() {
        return new Whitelist();
    }

    public static Whitelist simpleText() {
        return new Whitelist().addTags("b", "em", "i", "strong", "u");
    }

    public static Whitelist basic() {
        String str = "a";
        String str2 = "cite";
        Whitelist whitelist = new Whitelist();
        r1 = new String[23];
        String str3 = "a";
        r1[0] = str;
        r1[1] = "b";
        r1[2] = "blockquote";
        r1[3] = "br";
        String str4 = "cite";
        r1[4] = str2;
        r1[5] = "code";
        r1[6] = "dd";
        r1[7] = "dl";
        r1[8] = "dt";
        r1[9] = "em";
        r1[10] = "i";
        r1[11] = "li";
        r1[12] = "ol";
        r1[13] = "p";
        r1[14] = "pre";
        r1[15] = "q";
        r1[16] = "small";
        r1[17] = "strike";
        r1[18] = "strong";
        r1[19] = "sub";
        r1[20] = "sup";
        r1[21] = "u";
        r1[22] = "ul";
        whitelist = whitelist.addTags(r1);
        String str5 = "a";
        r1 = new String[]{"href"};
        String[] strArr = new String[1];
        str4 = "cite";
        strArr[0] = str2;
        strArr = new String[1];
        str4 = "cite";
        strArr[0] = str2;
        whitelist = whitelist.addAttributes(str, r1).addAttributes("blockquote", strArr).addAttributes("q", strArr);
        str5 = "a";
        str3 = "cite";
        strArr = new String[]{"http", "https"};
        str5 = "cite";
        str5 = "cite";
        str5 = "a";
        return whitelist.addProtocols(str, "href", "ftp", "http", "https", "mailto").addProtocols("blockquote", str2, strArr).addProtocols(str2, str2, "http", "https").addEnforcedAttribute(str, "rel", "nofollow");
    }

    public static Whitelist basicWithImages() {
        String str = "src";
        String str2 = "img";
        Whitelist basic = basic();
        String[] strArr = new String[1];
        String str3 = "img";
        strArr[0] = str2;
        basic = basic.addTags(strArr);
        String str4 = "img";
        strArr = new String[6];
        String str5 = "src";
        strArr[3] = str;
        strArr[4] = "title";
        strArr[5] = "width";
        basic = basic.addAttributes(str2, strArr);
        str4 = "img";
        str4 = "src";
        return basic.addProtocols(str2, str, "http", "https");
    }

    public static Whitelist relaxed() {
        String str = "width";
        Whitelist whitelist = new Whitelist();
        String[] strArr = new String[]{"a", "b", "blockquote", "br", "caption", "cite", "code", "col", "colgroup", "dd", "div", "dl", "dt", "em", "h1", "h2", "h3", "h4", "h5", "h6", "i", "img", "li", "ol", "p", "pre", "q", "small", "strike", "strong", "sub", "sup", "table", "tbody", "td", "tfoot", "th", "thead", "tr", "u", "ul"};
        String[] strArr2 = new String[]{"href", "title"};
        strArr2 = new String[]{"cite"};
        strArr2 = new String[2];
        strArr2[0] = "span";
        String str2 = "width";
        strArr2[1] = str;
        strArr2 = new String[2];
        strArr2[0] = "span";
        str2 = "width";
        strArr2[1] = str;
        strArr2 = new String[6];
        strArr2[0] = "align";
        strArr2[1] = "alt";
        strArr2[2] = "height";
        strArr2[3] = "src";
        strArr2[4] = "title";
        String str3 = "width";
        strArr2[5] = str;
        strArr2 = new String[]{"start", "type"};
        strArr2 = new String[]{"cite"};
        strArr2 = new String[2];
        strArr2[0] = "summary";
        str2 = "width";
        strArr2[1] = str;
        strArr2 = new String[5];
        strArr2[0] = "abbr";
        strArr2[1] = "axis";
        strArr2[2] = "colspan";
        strArr2[3] = "rowspan";
        str3 = "width";
        strArr2[4] = str;
        strArr2 = new String[6];
        strArr2[0] = "abbr";
        strArr2[1] = "axis";
        strArr2[2] = "colspan";
        strArr2[3] = "rowspan";
        strArr2[4] = "scope";
        str3 = "width";
        strArr2[5] = str;
        return whitelist.addTags(strArr).addAttributes("a", strArr2).addAttributes("blockquote", strArr2).addAttributes("col", strArr2).addAttributes("colgroup", strArr2).addAttributes("img", strArr2).addAttributes("ol", strArr2).addAttributes("q", strArr2).addAttributes("table", strArr2).addAttributes("td", strArr2).addAttributes("th", strArr2).addAttributes("ul", "type").addProtocols("a", "href", "ftp", "http", "https", "mailto").addProtocols("blockquote", "cite", "http", "https").addProtocols("img", "src", "http", "https").addProtocols("q", "cite", "http", "https");
    }

    public Whitelist() {
        this.tagNames = new HashSet();
        this.attributes = new HashMap();
        this.enforcedAttributes = new HashMap();
        this.protocols = new HashMap();
    }

    public Whitelist addTags(String... tags) {
        Validate.notNull(tags);
        for (String tagName : tags) {
            Validate.notEmpty(tagName);
            this.tagNames.add(TagName.valueOf(tagName));
        }
        return this;
    }

    public Whitelist addAttributes(String tag, String... keys) {
        Validate.notEmpty(tag);
        Validate.notNull(keys);
        TagName tagName = TagName.valueOf(tag);
        Set<AttributeKey> attributeSet = new HashSet();
        for (String key : keys) {
            Validate.notEmpty(key);
            attributeSet.add(AttributeKey.valueOf(key));
        }
        if (this.attributes.containsKey(tagName)) {
            ((Set) this.attributes.get(tagName)).addAll(attributeSet);
        } else {
            this.attributes.put(tagName, attributeSet);
        }
        return this;
    }

    public Whitelist addEnforcedAttribute(String tag, String key, String value) {
        Validate.notEmpty(tag);
        Validate.notEmpty(key);
        Validate.notEmpty(value);
        TagName tagName = TagName.valueOf(tag);
        AttributeKey attrKey = AttributeKey.valueOf(key);
        AttributeValue attrVal = AttributeValue.valueOf(value);
        if (this.enforcedAttributes.containsKey(tagName)) {
            ((Map) this.enforcedAttributes.get(tagName)).put(attrKey, attrVal);
        } else {
            Map<AttributeKey, AttributeValue> attrMap = new HashMap();
            attrMap.put(attrKey, attrVal);
            this.enforcedAttributes.put(tagName, attrMap);
        }
        return this;
    }

    public Whitelist addProtocols(String tag, String key, String... protocols) {
        Map<AttributeKey, Set<Protocol>> attrMap;
        Set<Protocol> protSet;
        Validate.notEmpty(tag);
        Validate.notEmpty(key);
        Validate.notNull(protocols);
        TagName tagName = TagName.valueOf(tag);
        AttributeKey attrKey = AttributeKey.valueOf(key);
        if (this.protocols.containsKey(tagName)) {
            attrMap = (Map) this.protocols.get(tagName);
        } else {
            attrMap = new HashMap();
            this.protocols.put(tagName, attrMap);
        }
        if (attrMap.containsKey(attrKey)) {
            protSet = (Set) attrMap.get(attrKey);
        } else {
            protSet = new HashSet();
            attrMap.put(attrKey, protSet);
        }
        for (String protocol : protocols) {
            Validate.notEmpty(protocol);
            protSet.add(Protocol.valueOf(protocol));
        }
        return this;
    }

    boolean isSafeTag(String tag) {
        return this.tagNames.contains(TagName.valueOf(tag));
    }

    boolean isSafeAttribute(String tagName, Element el, Attribute attr) {
        String str = ":all";
        TagName tag = TagName.valueOf(tagName);
        AttributeKey key = AttributeKey.valueOf(attr.getKey());
        if (!this.attributes.containsKey(tag)) {
            String str2 = ":all";
            if (!tagName.equals(str)) {
                str2 = ":all";
                if (isSafeAttribute(str, el, attr)) {
                    return true;
                }
            }
            return false;
        } else if (!((Set) this.attributes.get(tag)).contains(key)) {
            return false;
        } else {
            if (!this.protocols.containsKey(tag)) {
                return true;
            }
            Map<AttributeKey, Set<Protocol>> attrProts = (Map) this.protocols.get(tag);
            if (!attrProts.containsKey(key) || testValidProtocol(el, attr, (Set) attrProts.get(key))) {
                return true;
            }
            return false;
        }
    }

    private boolean testValidProtocol(Element el, Attribute attr, Set<Protocol> protocols) {
        String value = el.absUrl(attr.getKey());
        attr.setValue(value);
        for (Protocol protocol : protocols) {
            if (value.toLowerCase().startsWith(new StringBuilder(String.valueOf(protocol.toString())).append(":").toString())) {
                return true;
            }
        }
        return false;
    }

    Attributes getEnforcedAttributes(String tagName) {
        Attributes attrs = new Attributes();
        TagName tag = TagName.valueOf(tagName);
        if (this.enforcedAttributes.containsKey(tag)) {
            for (Entry<AttributeKey, AttributeValue> entry : ((Map) this.enforcedAttributes.get(tag)).entrySet()) {
                attrs.put(((AttributeKey) entry.getKey()).toString(), ((AttributeValue) entry.getValue()).toString());
            }
        }
        return attrs;
    }
}
