package org.jsoup.parser;

import org.apache.commons.lang.StringUtils;
import org.jsoup.helper.Validate;

class CharacterReader {
    static final char EOF = '\uffff';
    private final String input;
    private final int length;
    private int mark;
    private int pos;

    CharacterReader(String input) {
        this.pos = 0;
        this.mark = 0;
        Validate.notNull(input);
        input = input.replaceAll("\r\n?", "\n");
        this.input = input;
        this.length = input.length();
    }

    int pos() {
        return this.pos;
    }

    boolean isEmpty() {
        return this.pos >= this.length;
    }

    char current() {
        return isEmpty() ? EOF : this.input.charAt(this.pos);
    }

    char consume() {
        char val = isEmpty() ? EOF : this.input.charAt(this.pos);
        this.pos++;
        return val;
    }

    void unconsume() {
        this.pos--;
    }

    void advance() {
        this.pos++;
    }

    void mark() {
        this.mark = this.pos;
    }

    void rewindToMark() {
        this.pos = this.mark;
    }

    String consumeAsString() {
        String str = this.input;
        int i = this.pos;
        int i2 = this.pos;
        this.pos = i2 + 1;
        return str.substring(i, i2);
    }

    String consumeTo(char c) {
        int offset = this.input.indexOf(c, this.pos);
        if (offset == -1) {
            return consumeToEnd();
        }
        String consumed = this.input.substring(this.pos, offset);
        this.pos += consumed.length();
        return consumed;
    }

    String consumeTo(String seq) {
        int offset = this.input.indexOf(seq, this.pos);
        if (offset == -1) {
            return consumeToEnd();
        }
        String consumed = this.input.substring(this.pos, offset);
        this.pos += consumed.length();
        return consumed;
    }

    String consumeToAny(char... seq) {
        int start = this.pos;
        loop0:
        while (!isEmpty()) {
            char c = this.input.charAt(this.pos);
            for (char seek : seq) {
                if (seek == c) {
                    break loop0;
                }
            }
            this.pos++;
        }
        if (this.pos > start) {
            return this.input.substring(start, this.pos);
        }
        return StringUtils.EMPTY;
    }

    String consumeToEnd() {
        String data = this.input.substring(this.pos, this.input.length());
        this.pos = this.input.length();
        return data;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    java.lang.String consumeLetterSequence() {
        /*
        r4 = this;
        r1 = r4.pos;
    L_0x0002:
        r2 = r4.isEmpty();
        if (r2 == 0) goto L_0x0011;
    L_0x0008:
        r2 = r4.input;
        r3 = r4.pos;
        r2 = r2.substring(r1, r3);
        return r2;
    L_0x0011:
        r2 = r4.input;
        r3 = r4.pos;
        r0 = r2.charAt(r3);
        r2 = 65;
        if (r0 < r2) goto L_0x0021;
    L_0x001d:
        r2 = 90;
        if (r0 <= r2) goto L_0x0029;
    L_0x0021:
        r2 = 97;
        if (r0 < r2) goto L_0x0008;
    L_0x0025:
        r2 = 122; // 0x7a float:1.71E-43 double:6.03E-322;
        if (r0 > r2) goto L_0x0008;
    L_0x0029:
        r2 = r4.pos;
        r2 = r2 + 1;
        r4.pos = r2;
        goto L_0x0002;
        */
        throw new UnsupportedOperationException("Method not decompiled: org.jsoup.parser.CharacterReader.consumeLetterSequence():java.lang.String");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    java.lang.String consumeHexSequence() {
        /*
        r4 = this;
        r1 = r4.pos;
    L_0x0002:
        r2 = r4.isEmpty();
        if (r2 == 0) goto L_0x0011;
    L_0x0008:
        r2 = r4.input;
        r3 = r4.pos;
        r2 = r2.substring(r1, r3);
        return r2;
    L_0x0011:
        r2 = r4.input;
        r3 = r4.pos;
        r0 = r2.charAt(r3);
        r2 = 48;
        if (r0 < r2) goto L_0x0021;
    L_0x001d:
        r2 = 57;
        if (r0 <= r2) goto L_0x0031;
    L_0x0021:
        r2 = 65;
        if (r0 < r2) goto L_0x0029;
    L_0x0025:
        r2 = 70;
        if (r0 <= r2) goto L_0x0031;
    L_0x0029:
        r2 = 97;
        if (r0 < r2) goto L_0x0008;
    L_0x002d:
        r2 = 102; // 0x66 float:1.43E-43 double:5.04E-322;
        if (r0 > r2) goto L_0x0008;
    L_0x0031:
        r2 = r4.pos;
        r2 = r2 + 1;
        r4.pos = r2;
        goto L_0x0002;
        */
        throw new UnsupportedOperationException("Method not decompiled: org.jsoup.parser.CharacterReader.consumeHexSequence():java.lang.String");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    java.lang.String consumeDigitSequence() {
        /*
        r4 = this;
        r1 = r4.pos;
    L_0x0002:
        r2 = r4.isEmpty();
        if (r2 == 0) goto L_0x0011;
    L_0x0008:
        r2 = r4.input;
        r3 = r4.pos;
        r2 = r2.substring(r1, r3);
        return r2;
    L_0x0011:
        r2 = r4.input;
        r3 = r4.pos;
        r0 = r2.charAt(r3);
        r2 = 48;
        if (r0 < r2) goto L_0x0008;
    L_0x001d:
        r2 = 57;
        if (r0 > r2) goto L_0x0008;
    L_0x0021:
        r2 = r4.pos;
        r2 = r2 + 1;
        r4.pos = r2;
        goto L_0x0002;
        */
        throw new UnsupportedOperationException("Method not decompiled: org.jsoup.parser.CharacterReader.consumeDigitSequence():java.lang.String");
    }

    boolean matches(char c) {
        return !isEmpty() && this.input.charAt(this.pos) == c;
    }

    boolean matches(String seq) {
        return this.input.startsWith(seq, this.pos);
    }

    boolean matchesIgnoreCase(String seq) {
        return this.input.regionMatches(true, this.pos, seq, 0, seq.length());
    }

    boolean matchesAny(char... seq) {
        if (isEmpty()) {
            return false;
        }
        char c = this.input.charAt(this.pos);
        for (char seek : seq) {
            if (seek == c) {
                return true;
            }
        }
        return false;
    }

    boolean matchesLetter() {
        if (isEmpty()) {
            return false;
        }
        char c = this.input.charAt(this.pos);
        return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
    }

    boolean matchesDigit() {
        if (isEmpty()) {
            return false;
        }
        char c = this.input.charAt(this.pos);
        return c >= '0' && c <= '9';
    }

    boolean matchConsume(String seq) {
        if (!matches(seq)) {
            return false;
        }
        this.pos += seq.length();
        return true;
    }

    boolean matchConsumeIgnoreCase(String seq) {
        if (!matchesIgnoreCase(seq)) {
            return false;
        }
        this.pos += seq.length();
        return true;
    }

    boolean containsIgnoreCase(String seq) {
        return this.input.indexOf(seq.toLowerCase(), this.pos) > -1 || this.input.indexOf(seq.toUpperCase(), this.pos) > -1;
    }

    public String toString() {
        return this.input.substring(this.pos);
    }
}
