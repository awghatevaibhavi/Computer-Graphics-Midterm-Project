package org.jsoup.parser;

class ParseError {
    private char c;
    private String errorMsg;
    private int pos;
    private Token token;
    private TokeniserState tokeniserState;
    private TreeBuilderState treeBuilderState;

    ParseError(String errorMsg, char c, TokeniserState tokeniserState, int pos) {
        this.errorMsg = errorMsg;
        this.c = c;
        this.tokeniserState = tokeniserState;
        this.pos = pos;
    }

    ParseError(String errorMsg, TokeniserState tokeniserState, int pos) {
        this.errorMsg = errorMsg;
        this.tokeniserState = tokeniserState;
        this.pos = pos;
    }

    ParseError(String errorMsg, int pos) {
        this.errorMsg = errorMsg;
        this.pos = pos;
    }

    ParseError(String errorMsg, TreeBuilderState treeBuilderState, Token token, int pos) {
        this.errorMsg = errorMsg;
        this.treeBuilderState = treeBuilderState;
        this.token = token;
        this.pos = pos;
    }

    String getErrorMsg() {
        return this.errorMsg;
    }

    int getPos() {
        return this.pos;
    }
}
