package org.jsoup.parser;

import java.util.Iterator;
import java.util.LinkedList;
import org.jsoup.helper.StringUtil;
import org.jsoup.nodes.Attribute;
import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.Document.QuirksMode;
import org.jsoup.nodes.DocumentType;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.kxml2.wap.Wbxml;

enum TreeBuilderState {
    Initial {
        boolean process(Token t, TreeBuilder tb) {
            if (TreeBuilderState.isWhitespace(t)) {
                return true;
            }
            if (t.isComment()) {
                tb.insert(t.asComment());
            } else if (t.isDoctype()) {
                Doctype d = t.asDoctype();
                tb.getDocument().appendChild(new DocumentType(d.getName(), d.getPublicIdentifier(), d.getSystemIdentifier(), tb.getBaseUri()));
                if (d.isForceQuirks()) {
                    tb.getDocument().quirksMode(QuirksMode.quirks);
                }
                tb.transition(BeforeHtml);
            } else {
                tb.transition(BeforeHtml);
                return tb.process(t);
            }
            return true;
        }
    },
    BeforeHtml {
        boolean process(Token t, TreeBuilder tb) {
            String str = "html";
            if (t.isDoctype()) {
                tb.error(this);
                return false;
            }
            if (t.isComment()) {
                tb.insert(t.asComment());
            } else if (TreeBuilderState.isWhitespace(t)) {
                return true;
            } else {
                if (t.isStartTag()) {
                    String str2 = "html";
                    if (t.asStartTag().name().equals(str)) {
                        tb.insert(t.asStartTag());
                        tb.transition(BeforeHead);
                    }
                }
                if (t.isEndTag()) {
                    String name = t.asEndTag().name();
                    r1 = new String[4];
                    String str3 = "html";
                    r1[2] = str;
                    r1[3] = "br";
                    if (StringUtil.in(name, r1)) {
                        return anythingElse(t, tb);
                    }
                }
                if (!t.isEndTag()) {
                    return anythingElse(t, tb);
                }
                tb.error(this);
                return false;
            }
            return true;
        }

        private boolean anythingElse(Token t, TreeBuilder tb) {
            tb.insert("html");
            tb.transition(BeforeHead);
            return tb.process(t);
        }
    },
    BeforeHead {
        boolean process(Token t, TreeBuilder tb) {
            String str = "html";
            String str2 = "head";
            if (TreeBuilderState.isWhitespace(t)) {
                return true;
            }
            if (t.isComment()) {
                tb.insert(t.asComment());
            } else if (t.isDoctype()) {
                tb.error(this);
                return false;
            } else {
                String str3;
                if (t.isStartTag()) {
                    str3 = "html";
                    if (t.asStartTag().name().equals(str)) {
                        return InBody.process(t, tb);
                    }
                }
                if (t.isStartTag()) {
                    str3 = "head";
                    if (t.asStartTag().name().equals(str2)) {
                        tb.setHeadElement(tb.insert(t.asStartTag()));
                        tb.transition(InHead);
                    }
                }
                if (t.isEndTag()) {
                    String name = t.asEndTag().name();
                    String[] strArr = new String[4];
                    String str4 = "head";
                    strArr[0] = str2;
                    strArr[1] = "body";
                    String str5 = "html";
                    strArr[2] = str;
                    strArr[3] = "br";
                    if (StringUtil.in(name, strArr)) {
                        str3 = "head";
                        tb.process(new StartTag(str2));
                        return tb.process(t);
                    }
                }
                if (t.isEndTag()) {
                    tb.error(this);
                    return false;
                }
                str3 = "head";
                tb.process(new StartTag(str2));
                return tb.process(t);
            }
            return true;
        }
    },
    InHead {
        private static /* synthetic */ int[] $SWITCH_TABLE$org$jsoup$parser$Token$TokenType;

        static /* synthetic */ int[] $SWITCH_TABLE$org$jsoup$parser$Token$TokenType() {
            int[] iArr = $SWITCH_TABLE$org$jsoup$parser$Token$TokenType;
            if (iArr == null) {
                iArr = new int[TokenType.values().length];
                try {
                    iArr[TokenType.Character.ordinal()] = 5;
                } catch (NoSuchFieldError e) {
                }
                try {
                    iArr[TokenType.Comment.ordinal()] = 4;
                } catch (NoSuchFieldError e2) {
                }
                try {
                    iArr[TokenType.Doctype.ordinal()] = 1;
                } catch (NoSuchFieldError e3) {
                }
                try {
                    iArr[TokenType.EOF.ordinal()] = 6;
                } catch (NoSuchFieldError e4) {
                }
                try {
                    iArr[TokenType.EndTag.ordinal()] = 3;
                } catch (NoSuchFieldError e5) {
                }
                try {
                    iArr[TokenType.StartTag.ordinal()] = 2;
                } catch (NoSuchFieldError e6) {
                }
                $SWITCH_TABLE$org$jsoup$parser$Token$TokenType = iArr;
            }
            return iArr;
        }

        boolean process(Token t, TreeBuilder tb) {
            String str = "base";
            if (TreeBuilderState.isWhitespace(t)) {
                tb.insert(t.asCharacter());
                return true;
            }
            String name;
            switch ($SWITCH_TABLE$org$jsoup$parser$Token$TokenType()[t.type.ordinal()]) {
                case Wbxml.END /*1*/:
                    tb.error(this);
                    return false;
                case Wbxml.ENTITY /*2*/:
                    StartTag start = t.asStartTag();
                    name = start.name();
                    if (name.equals("html")) {
                        return InBody.process(t, tb);
                    }
                    r5 = new String[5];
                    String str2 = "base";
                    r5[0] = str;
                    r5[1] = "basefont";
                    r5[2] = "bgsound";
                    r5[3] = "command";
                    r5[4] = "link";
                    if (StringUtil.in(name, r5)) {
                        Element el = tb.insertEmpty(start);
                        String str3 = "base";
                        if (name.equals(str) && el.hasAttr("href")) {
                            tb.setBaseUri(el);
                            break;
                        }
                    } else if (name.equals("meta")) {
                        Element meta = tb.insertEmpty(start);
                        break;
                    } else if (name.equals("title")) {
                        TreeBuilderState.handleRcData(start, tb);
                        break;
                    } else {
                        if (StringUtil.in(name, "noframes", "style")) {
                            TreeBuilderState.handleRawtext(start, tb);
                            break;
                        } else if (name.equals("noscript")) {
                            tb.insert(start);
                            tb.transition(InHeadNoscript);
                            break;
                        } else if (name.equals("script")) {
                            tb.insert(start);
                            tb.tokeniser.transition(TokeniserState.ScriptData);
                            tb.markInsertionMode();
                            tb.transition(Text);
                            break;
                        } else if (!name.equals("head")) {
                            return anythingElse(t, tb);
                        } else {
                            tb.error(this);
                            return false;
                        }
                    }
                case Wbxml.STR_I /*3*/:
                    name = t.asEndTag().name();
                    if (name.equals("head")) {
                        tb.pop();
                        tb.transition(AfterHead);
                        break;
                    }
                    if (StringUtil.in(name, "body", "html", "br")) {
                        return anythingElse(t, tb);
                    }
                    tb.error(this);
                    return false;
                case Wbxml.LITERAL /*4*/:
                    tb.insert(t.asComment());
                    break;
                default:
                    return anythingElse(t, tb);
            }
            return true;
        }

        private boolean anythingElse(Token t, TreeBuilder tb) {
            tb.process(new EndTag("head"));
            return tb.process(t);
        }
    },
    InHeadNoscript {
        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        boolean process(org.jsoup.parser.Token r9, org.jsoup.parser.TreeBuilder r10) {
            /*
            r8 = this;
            r6 = 2;
            r5 = 1;
            r4 = 0;
            r7 = "noscript";
            r0 = r9.isDoctype();
            if (r0 == 0) goto L_0x0010;
        L_0x000b:
            r10.error(r8);
        L_0x000e:
            r0 = r5;
        L_0x000f:
            return r0;
        L_0x0010:
            r0 = r9.isStartTag();
            if (r0 == 0) goto L_0x002d;
        L_0x0016:
            r0 = r9.asStartTag();
            r0 = r0.name();
            r1 = "html";
            r0 = r0.equals(r1);
            if (r0 == 0) goto L_0x002d;
        L_0x0026:
            r0 = InBody;
            r0 = r10.process(r9, r0);
            goto L_0x000f;
        L_0x002d:
            r0 = r9.isEndTag();
            if (r0 == 0) goto L_0x004c;
        L_0x0033:
            r0 = r9.asEndTag();
            r0 = r0.name();
            r1 = "noscript";
            r0 = r0.equals(r7);
            if (r0 == 0) goto L_0x004c;
        L_0x0043:
            r10.pop();
            r0 = InHead;
            r10.transition(r0);
            goto L_0x000e;
        L_0x004c:
            r0 = org.jsoup.parser.TreeBuilderState.isWhitespace(r9);
            if (r0 != 0) goto L_0x008a;
        L_0x0052:
            r0 = r9.isComment();
            if (r0 != 0) goto L_0x008a;
        L_0x0058:
            r0 = r9.isStartTag();
            if (r0 == 0) goto L_0x0092;
        L_0x005e:
            r0 = r9.asStartTag();
            r0 = r0.name();
            r1 = 6;
            r1 = new java.lang.String[r1];
            r2 = "basefont";
            r1[r4] = r2;
            r2 = "bgsound";
            r1[r5] = r2;
            r2 = "link";
            r1[r6] = r2;
            r2 = 3;
            r3 = "meta";
            r1[r2] = r3;
            r2 = 4;
            r3 = "noframes";
            r1[r2] = r3;
            r2 = 5;
            r3 = "style";
            r1[r2] = r3;
            r0 = org.jsoup.helper.StringUtil.in(r0, r1);
            if (r0 == 0) goto L_0x0092;
        L_0x008a:
            r0 = InHead;
            r0 = r10.process(r9, r0);
            goto L_0x000f;
        L_0x0092:
            r0 = r9.isEndTag();
            if (r0 == 0) goto L_0x00ae;
        L_0x0098:
            r0 = r9.asEndTag();
            r0 = r0.name();
            r1 = "br";
            r0 = r0.equals(r1);
            if (r0 == 0) goto L_0x00ae;
        L_0x00a8:
            r0 = r8.anythingElse(r9, r10);
            goto L_0x000f;
        L_0x00ae:
            r0 = r9.isStartTag();
            if (r0 == 0) goto L_0x00cc;
        L_0x00b4:
            r0 = r9.asStartTag();
            r0 = r0.name();
            r1 = new java.lang.String[r6];
            r2 = "head";
            r1[r4] = r2;
            r2 = "noscript";
            r1[r5] = r7;
            r0 = org.jsoup.helper.StringUtil.in(r0, r1);
            if (r0 != 0) goto L_0x00d2;
        L_0x00cc:
            r0 = r9.isEndTag();
            if (r0 == 0) goto L_0x00d8;
        L_0x00d2:
            r10.error(r8);
            r0 = r4;
            goto L_0x000f;
        L_0x00d8:
            r0 = r8.anythingElse(r9, r10);
            goto L_0x000f;
            */
            throw new UnsupportedOperationException("Method not decompiled: org.jsoup.parser.TreeBuilderState.5.process(org.jsoup.parser.Token, org.jsoup.parser.TreeBuilder):boolean");
        }

        private boolean anythingElse(Token t, TreeBuilder tb) {
            tb.error(this);
            tb.process(new EndTag("noscript"));
            return tb.process(t);
        }
    },
    AfterHead {
        boolean process(Token t, TreeBuilder tb) {
            String str = "html";
            String str2 = "body";
            if (TreeBuilderState.isWhitespace(t)) {
                tb.insert(t.asCharacter());
            } else if (t.isComment()) {
                tb.insert(t.asComment());
            } else if (t.isDoctype()) {
                tb.error(this);
            } else if (t.isStartTag()) {
                StartTag startTag = t.asStartTag();
                String name = startTag.name();
                r3 = "html";
                if (name.equals(str)) {
                    return tb.process(t, InBody);
                }
                r3 = "body";
                if (name.equals(str2)) {
                    tb.insert(startTag);
                    tb.framesetOk(false);
                    tb.transition(InBody);
                } else if (name.equals("frameset")) {
                    tb.insert(startTag);
                    tb.transition(InFrameset);
                } else {
                    if (StringUtil.in(name, "base", "basefont", "bgsound", "link", "meta", "noframes", "script", "style", "title")) {
                        tb.error(this);
                        Element head = tb.getHeadElement();
                        tb.push(head);
                        tb.process(t, InHead);
                        tb.removeFromStack(head);
                    } else if (name.equals("head")) {
                        tb.error(this);
                        return false;
                    } else {
                        anythingElse(t, tb);
                    }
                }
            } else if (t.isEndTag()) {
                r3 = t.asEndTag().name();
                r4 = new String[2];
                String str3 = "body";
                r4[0] = str2;
                str3 = "html";
                r4[1] = str;
                if (StringUtil.in(r3, r4)) {
                    anythingElse(t, tb);
                } else {
                    tb.error(this);
                    return false;
                }
            } else {
                anythingElse(t, tb);
            }
            return true;
        }

        private boolean anythingElse(Token t, TreeBuilder tb) {
            tb.process(new StartTag("body"));
            tb.framesetOk(true);
            return tb.process(t);
        }
    },
    InBody {
        private static /* synthetic */ int[] $SWITCH_TABLE$org$jsoup$parser$Token$TokenType;

        static /* synthetic */ int[] $SWITCH_TABLE$org$jsoup$parser$Token$TokenType() {
            int[] iArr = $SWITCH_TABLE$org$jsoup$parser$Token$TokenType;
            if (iArr == null) {
                iArr = new int[TokenType.values().length];
                try {
                    iArr[TokenType.Character.ordinal()] = 5;
                } catch (NoSuchFieldError e) {
                }
                try {
                    iArr[TokenType.Comment.ordinal()] = 4;
                } catch (NoSuchFieldError e2) {
                }
                try {
                    iArr[TokenType.Doctype.ordinal()] = 1;
                } catch (NoSuchFieldError e3) {
                }
                try {
                    iArr[TokenType.EOF.ordinal()] = 6;
                } catch (NoSuchFieldError e4) {
                }
                try {
                    iArr[TokenType.EndTag.ordinal()] = 3;
                } catch (NoSuchFieldError e5) {
                }
                try {
                    iArr[TokenType.StartTag.ordinal()] = 2;
                } catch (NoSuchFieldError e6) {
                }
                $SWITCH_TABLE$org$jsoup$parser$Token$TokenType = iArr;
            }
            return iArr;
        }

        boolean process(Token t, TreeBuilder tb) {
            String name;
            LinkedList<Element> stack;
            int i;
            switch ($SWITCH_TABLE$org$jsoup$parser$Token$TokenType()[t.type.ordinal()]) {
                case Wbxml.END /*1*/:
                    tb.error(this);
                    return false;
                case Wbxml.ENTITY /*2*/:
                    Token startTag = t.asStartTag();
                    name = startTag.name();
                    Iterator it;
                    Attribute attribute;
                    if (!name.equals("html")) {
                        if (!StringUtil.in(name, "base", "basefont", "bgsound", "command", "link", "meta", "noframes", "script", "style", "title")) {
                            if (!name.equals("body")) {
                                if (!name.equals("frameset")) {
                                    if (!StringUtil.in(name, "address", "article", "aside", "blockquote", "center", "details", "dir", "div", "dl", "fieldset", "figcaption", "figure", "footer", "header", "hgroup", "menu", "nav", "ol", "p", "section", "summary", "ul")) {
                                        if (!StringUtil.in(name, "h1", "h2", "h3", "h4", "h5", "h6")) {
                                            if (!StringUtil.in(name, "pre", "listing")) {
                                                if (name.equals("form")) {
                                                    if (tb.getFormElement() == null) {
                                                        if (tb.inButtonScope("p")) {
                                                            tb.process(new EndTag("p"));
                                                        }
                                                        tb.setFormElement(tb.insert((StartTag) startTag));
                                                        break;
                                                    }
                                                    tb.error(this);
                                                    return false;
                                                }
                                                Element el;
                                                if (!name.equals("li")) {
                                                    if (!StringUtil.in(name, "dd", "dt")) {
                                                        if (!name.equals("plaintext")) {
                                                            if (!name.equals("button")) {
                                                                if (!name.equals("a")) {
                                                                    if (!StringUtil.in(name, "b", "big", "code", "em", "font", "i", "s", "small", "strike", "strong", "tt", "u")) {
                                                                        if (!name.equals("nobr")) {
                                                                            if (!StringUtil.in(name, "applet", "marquee", "object")) {
                                                                                if (!name.equals("table")) {
                                                                                    if (!StringUtil.in(name, "area", "br", "embed", "img", "keygen", "wbr")) {
                                                                                        if (!name.equals("input")) {
                                                                                            if (!StringUtil.in(name, "param", "source", "track")) {
                                                                                                if (!name.equals("hr")) {
                                                                                                    if (!name.equals("image")) {
                                                                                                        if (!name.equals("isindex")) {
                                                                                                            if (!name.equals("textarea")) {
                                                                                                                if (!name.equals("xmp")) {
                                                                                                                    if (!name.equals("iframe")) {
                                                                                                                        if (!name.equals("noembed")) {
                                                                                                                            if (!name.equals("select")) {
                                                                                                                                if (!StringUtil.in("optgroup", "option")) {
                                                                                                                                    if (!StringUtil.in("rp", "rt")) {
                                                                                                                                        if (!name.equals("math")) {
                                                                                                                                            if (!name.equals("svg")) {
                                                                                                                                                if (!StringUtil.in(name, "caption", "col", "colgroup", "frame", "head", "tbody", "td", "tfoot", "th", "thead", "tr")) {
                                                                                                                                                    tb.reconstructFormattingElements();
                                                                                                                                                    tb.insert((StartTag) startTag);
                                                                                                                                                    break;
                                                                                                                                                }
                                                                                                                                                tb.error(this);
                                                                                                                                                return false;
                                                                                                                                            }
                                                                                                                                            tb.reconstructFormattingElements();
                                                                                                                                            tb.insert((StartTag) startTag);
                                                                                                                                            tb.tokeniser.acknowledgeSelfClosingFlag();
                                                                                                                                            break;
                                                                                                                                        }
                                                                                                                                        tb.reconstructFormattingElements();
                                                                                                                                        tb.insert((StartTag) startTag);
                                                                                                                                        tb.tokeniser.acknowledgeSelfClosingFlag();
                                                                                                                                        break;
                                                                                                                                    }
                                                                                                                                    if (tb.inScope("ruby")) {
                                                                                                                                        tb.generateImpliedEndTags();
                                                                                                                                        if (!tb.currentElement().nodeName().equals("ruby")) {
                                                                                                                                            tb.error(this);
                                                                                                                                            tb.popStackToBefore("ruby");
                                                                                                                                        }
                                                                                                                                        tb.insert((StartTag) startTag);
                                                                                                                                        break;
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                if (tb.currentElement().nodeName().equals("option")) {
                                                                                                                                    tb.process(new EndTag("option"));
                                                                                                                                }
                                                                                                                                tb.reconstructFormattingElements();
                                                                                                                                tb.insert((StartTag) startTag);
                                                                                                                                break;
                                                                                                                            }
                                                                                                                            tb.reconstructFormattingElements();
                                                                                                                            tb.insert((StartTag) startTag);
                                                                                                                            tb.framesetOk(false);
                                                                                                                            TreeBuilderState state = tb.state();
                                                                                                                            if (!state.equals(InTable) && !state.equals(InCaption) && !state.equals(InTableBody) && !state.equals(InRow) && !state.equals(InCell)) {
                                                                                                                                tb.transition(InSelect);
                                                                                                                                break;
                                                                                                                            }
                                                                                                                            tb.transition(InSelectInTable);
                                                                                                                            break;
                                                                                                                        }
                                                                                                                        TreeBuilderState.handleRawtext(startTag, tb);
                                                                                                                        break;
                                                                                                                    }
                                                                                                                    tb.framesetOk(false);
                                                                                                                    TreeBuilderState.handleRawtext(startTag, tb);
                                                                                                                    break;
                                                                                                                }
                                                                                                                if (tb.inButtonScope("p")) {
                                                                                                                    tb.process(new EndTag("p"));
                                                                                                                }
                                                                                                                tb.reconstructFormattingElements();
                                                                                                                tb.framesetOk(false);
                                                                                                                TreeBuilderState.handleRawtext(startTag, tb);
                                                                                                                break;
                                                                                                            }
                                                                                                            tb.insert((StartTag) startTag);
                                                                                                            tb.tokeniser.transition(TokeniserState.Rcdata);
                                                                                                            tb.markInsertionMode();
                                                                                                            tb.framesetOk(false);
                                                                                                            tb.transition(Text);
                                                                                                            break;
                                                                                                        }
                                                                                                        tb.error(this);
                                                                                                        if (tb.getFormElement() == null) {
                                                                                                            String prompt;
                                                                                                            tb.tokeniser.acknowledgeSelfClosingFlag();
                                                                                                            tb.process(new StartTag("form"));
                                                                                                            if (startTag.attributes.hasKey("action")) {
                                                                                                                tb.getFormElement().attr("action", startTag.attributes.get("action"));
                                                                                                            }
                                                                                                            tb.process(new StartTag("hr"));
                                                                                                            tb.process(new StartTag("label"));
                                                                                                            if (startTag.attributes.hasKey("prompt")) {
                                                                                                                prompt = startTag.attributes.get("prompt");
                                                                                                            } else {
                                                                                                                prompt = "This is a searchable index. Enter search keywords: ";
                                                                                                            }
                                                                                                            tb.process(new Character(prompt));
                                                                                                            Attributes inputAttribs = new Attributes();
                                                                                                            it = startTag.attributes.iterator();
                                                                                                            while (it.hasNext()) {
                                                                                                                Attribute attr = (Attribute) it.next();
                                                                                                                if (!StringUtil.in(attr.getKey(), "name", "action", "prompt")) {
                                                                                                                    inputAttribs.put(attr);
                                                                                                                }
                                                                                                            }
                                                                                                            inputAttribs.put("name", "isindex");
                                                                                                            tb.process(new StartTag("input", inputAttribs));
                                                                                                            tb.process(new EndTag("label"));
                                                                                                            tb.process(new StartTag("hr"));
                                                                                                            tb.process(new EndTag("form"));
                                                                                                            break;
                                                                                                        }
                                                                                                        return false;
                                                                                                    }
                                                                                                    startTag.name("img");
                                                                                                    return tb.process(startTag);
                                                                                                }
                                                                                                if (tb.inButtonScope("p")) {
                                                                                                    tb.process(new EndTag("p"));
                                                                                                }
                                                                                                tb.insertEmpty(startTag);
                                                                                                tb.framesetOk(false);
                                                                                                break;
                                                                                            }
                                                                                            tb.insertEmpty(startTag);
                                                                                            break;
                                                                                        }
                                                                                        tb.reconstructFormattingElements();
                                                                                        if (!tb.insertEmpty(startTag).attr("type").equalsIgnoreCase("hidden")) {
                                                                                            tb.framesetOk(false);
                                                                                            break;
                                                                                        }
                                                                                    }
                                                                                    tb.reconstructFormattingElements();
                                                                                    tb.insertEmpty(startTag);
                                                                                    tb.framesetOk(false);
                                                                                    break;
                                                                                }
                                                                                if (tb.getDocument().quirksMode() != QuirksMode.quirks) {
                                                                                    if (tb.inButtonScope("p")) {
                                                                                        tb.process(new EndTag("p"));
                                                                                    }
                                                                                }
                                                                                tb.insert((StartTag) startTag);
                                                                                tb.framesetOk(false);
                                                                                tb.transition(InTable);
                                                                                break;
                                                                            }
                                                                            tb.reconstructFormattingElements();
                                                                            tb.insert((StartTag) startTag);
                                                                            tb.insertMarkerToFormattingElements();
                                                                            tb.framesetOk(false);
                                                                            break;
                                                                        }
                                                                        tb.reconstructFormattingElements();
                                                                        if (tb.inScope("nobr")) {
                                                                            tb.error(this);
                                                                            tb.process(new EndTag("nobr"));
                                                                            tb.reconstructFormattingElements();
                                                                        }
                                                                        tb.pushActiveFormattingElements(tb.insert((StartTag) startTag));
                                                                        break;
                                                                    }
                                                                    tb.reconstructFormattingElements();
                                                                    tb.pushActiveFormattingElements(tb.insert((StartTag) startTag));
                                                                    break;
                                                                }
                                                                if (tb.getActiveFormattingElement("a") != null) {
                                                                    tb.error(this);
                                                                    tb.process(new EndTag("a"));
                                                                    Element remainingA = tb.getFromStack("a");
                                                                    if (remainingA != null) {
                                                                        tb.removeFromActiveFormattingElements(remainingA);
                                                                        tb.removeFromStack(remainingA);
                                                                    }
                                                                }
                                                                tb.reconstructFormattingElements();
                                                                tb.pushActiveFormattingElements(tb.insert((StartTag) startTag));
                                                                break;
                                                            }
                                                            if (!tb.inButtonScope("button")) {
                                                                tb.reconstructFormattingElements();
                                                                tb.insert((StartTag) startTag);
                                                                tb.framesetOk(false);
                                                                break;
                                                            }
                                                            tb.error(this);
                                                            tb.process(new EndTag("button"));
                                                            tb.process(startTag);
                                                            break;
                                                        }
                                                        if (tb.inButtonScope("p")) {
                                                            tb.process(new EndTag("p"));
                                                        }
                                                        tb.insert((StartTag) startTag);
                                                        tb.tokeniser.transition(TokeniserState.PLAINTEXT);
                                                        break;
                                                    }
                                                    tb.framesetOk(false);
                                                    stack = tb.getStack();
                                                    i = stack.size() - 1;
                                                    while (i > 0) {
                                                        el = (Element) stack.get(i);
                                                        if (StringUtil.in(el.nodeName(), "dd", "dt")) {
                                                            tb.process(new EndTag(el.nodeName()));
                                                        } else {
                                                            if (tb.isSpecial(el)) {
                                                                if (StringUtil.in(el.nodeName(), "address", "div", "p")) {
                                                                }
                                                            }
                                                            i--;
                                                        }
                                                        if (tb.inButtonScope("p")) {
                                                            tb.process(new EndTag("p"));
                                                        }
                                                        tb.insert((StartTag) startTag);
                                                        break;
                                                    }
                                                    if (tb.inButtonScope("p")) {
                                                        tb.process(new EndTag("p"));
                                                    }
                                                    tb.insert((StartTag) startTag);
                                                } else {
                                                    tb.framesetOk(false);
                                                    stack = tb.getStack();
                                                    i = stack.size() - 1;
                                                    while (i > 0) {
                                                        el = (Element) stack.get(i);
                                                        if (el.nodeName().equals("li")) {
                                                            tb.process(new EndTag("li"));
                                                        } else {
                                                            if (tb.isSpecial(el)) {
                                                                if (StringUtil.in(el.nodeName(), "address", "div", "p")) {
                                                                }
                                                            }
                                                            i--;
                                                        }
                                                        if (tb.inButtonScope("p")) {
                                                            tb.process(new EndTag("p"));
                                                        }
                                                        tb.insert((StartTag) startTag);
                                                        break;
                                                    }
                                                    if (tb.inButtonScope("p")) {
                                                        tb.process(new EndTag("p"));
                                                    }
                                                    tb.insert((StartTag) startTag);
                                                }
                                            } else {
                                                if (tb.inButtonScope("p")) {
                                                    tb.process(new EndTag("p"));
                                                }
                                                tb.insert((StartTag) startTag);
                                                tb.framesetOk(false);
                                                break;
                                            }
                                        }
                                        if (tb.inButtonScope("p")) {
                                            tb.process(new EndTag("p"));
                                        }
                                        if (StringUtil.in(tb.currentElement().nodeName(), "h1", "h2", "h3", "h4", "h5", "h6")) {
                                            tb.error(this);
                                            tb.pop();
                                        }
                                        tb.insert((StartTag) startTag);
                                        break;
                                    }
                                    if (tb.inButtonScope("p")) {
                                        tb.process(new EndTag("p"));
                                    }
                                    tb.insert((StartTag) startTag);
                                    break;
                                }
                                tb.error(this);
                                stack = tb.getStack();
                                if (stack.size() != 1 && (stack.size() <= 2 || ((Element) stack.get(1)).nodeName().equals("body"))) {
                                    if (tb.framesetOk()) {
                                        Element second = (Element) stack.get(1);
                                        if (second.parent() != null) {
                                            second.remove();
                                        }
                                        while (stack.size() > 1) {
                                            stack.removeLast();
                                        }
                                        tb.insert((StartTag) startTag);
                                        tb.transition(InFrameset);
                                        break;
                                    }
                                    return false;
                                }
                                return false;
                            }
                            tb.error(this);
                            stack = tb.getStack();
                            if (stack.size() != 1 && (stack.size() <= 2 || ((Element) stack.get(1)).nodeName().equals("body"))) {
                                tb.framesetOk(false);
                                Element body = (Element) stack.get(1);
                                it = startTag.getAttributes().iterator();
                                while (it.hasNext()) {
                                    attribute = (Attribute) it.next();
                                    if (!body.hasAttr(attribute.getKey())) {
                                        body.attributes().put(attribute);
                                    }
                                }
                                break;
                            }
                            return false;
                        }
                        return tb.process(t, InHead);
                    }
                    tb.error(this);
                    Element html = (Element) tb.getStack().getFirst();
                    it = startTag.getAttributes().iterator();
                    while (it.hasNext()) {
                        attribute = (Attribute) it.next();
                        if (!html.hasAttr(attribute.getKey())) {
                            html.attributes().put(attribute);
                        }
                    }
                    break;
                    break;
                case Wbxml.STR_I /*3*/:
                    Token endTag = t.asEndTag();
                    name = endTag.name();
                    if (name.equals("body")) {
                        if (tb.inScope("body")) {
                            tb.transition(AfterBody);
                            break;
                        }
                        tb.error(this);
                        return false;
                    }
                    if (name.equals("html")) {
                        if (tb.process(new EndTag("body"))) {
                            return tb.process(endTag);
                        }
                    }
                    if (StringUtil.in(name, "address", "article", "aside", "blockquote", "button", "center", "details", "dir", "div", "dl", "fieldset", "figcaption", "figure", "footer", "header", "hgroup", "listing", "menu", "nav", "ol", "pre", "section", "summary", "ul")) {
                        if (tb.inScope(name)) {
                            tb.generateImpliedEndTags();
                            if (!tb.currentElement().nodeName().equals(name)) {
                                tb.error(this);
                            }
                            tb.popStackToClose(name);
                            break;
                        }
                        tb.error(this);
                        return false;
                    }
                    if (name.equals("form")) {
                        Element currentForm = tb.getFormElement();
                        tb.setFormElement(null);
                        if (currentForm != null && tb.inScope(name)) {
                            tb.generateImpliedEndTags();
                            if (!tb.currentElement().nodeName().equals(name)) {
                                tb.error(this);
                            }
                            tb.removeFromStack(currentForm);
                            break;
                        }
                        tb.error(this);
                        return false;
                    }
                    if (name.equals("p")) {
                        if (tb.inButtonScope(name)) {
                            tb.generateImpliedEndTags(name);
                            if (!tb.currentElement().nodeName().equals(name)) {
                                tb.error(this);
                            }
                            tb.popStackToClose(name);
                            break;
                        }
                        tb.error(this);
                        tb.process(new StartTag(name));
                        return tb.process(endTag);
                    }
                    if (name.equals("li")) {
                        if (tb.inListItemScope(name)) {
                            tb.generateImpliedEndTags(name);
                            if (!tb.currentElement().nodeName().equals(name)) {
                                tb.error(this);
                            }
                            tb.popStackToClose(name);
                            break;
                        }
                        tb.error(this);
                        return false;
                    }
                    if (StringUtil.in(name, "dd", "dt")) {
                        if (tb.inScope(name)) {
                            tb.generateImpliedEndTags(name);
                            if (!tb.currentElement().nodeName().equals(name)) {
                                tb.error(this);
                            }
                            tb.popStackToClose(name);
                            break;
                        }
                        tb.error(this);
                        return false;
                    }
                    if (StringUtil.in(name, "h1", "h2", "h3", "h4", "h5", "h6")) {
                        if (tb.inScope(new String[]{"h1", "h2", "h3", "h4", "h5", "h6"})) {
                            tb.generateImpliedEndTags(name);
                            if (!tb.currentElement().nodeName().equals(name)) {
                                tb.error(this);
                            }
                            tb.popStackToClose("h1", "h2", "h3", "h4", "h5", "h6");
                            break;
                        }
                        tb.error(this);
                        return false;
                    }
                    if (name.equals("sarcasm")) {
                        return anyOtherEndTag(t, tb);
                    }
                    if (StringUtil.in(name, "a", "b", "big", "code", "em", "font", "i", "nobr", "s", "small", "strike", "strong", "tt", "u")) {
                        i = 0;
                        while (i < 8) {
                            Element formatEl = tb.getActiveFormattingElement(name);
                            if (formatEl == null) {
                                return anyOtherEndTag(t, tb);
                            }
                            if (tb.onStack(formatEl)) {
                                if (tb.inScope(formatEl.nodeName())) {
                                    Element node;
                                    Node lastNode;
                                    int j;
                                    Element element;
                                    Node node2;
                                    Node element2;
                                    if (tb.currentElement() != formatEl) {
                                        tb.error(this);
                                    }
                                    Node furthestBlock = null;
                                    Element commonAncestor = null;
                                    boolean seenFormattingElement = false;
                                    stack = tb.getStack();
                                    for (int si = 0; si < stack.size(); si++) {
                                        Node el2 = (Element) stack.get(si);
                                        if (el2 == formatEl) {
                                            commonAncestor = (Element) stack.get(si - 1);
                                            seenFormattingElement = true;
                                        } else if (seenFormattingElement && tb.isSpecial(el2)) {
                                            furthestBlock = el2;
                                            if (furthestBlock != null) {
                                                tb.popStackToClose(formatEl.nodeName());
                                                tb.removeFromActiveFormattingElements(formatEl);
                                                return true;
                                            }
                                            node = furthestBlock;
                                            lastNode = furthestBlock;
                                            for (j = 0; j < 3; j++) {
                                                if (tb.onStack(node)) {
                                                    node = tb.aboveOnStack(node);
                                                }
                                                if (!tb.isInActiveFormattingElements(node)) {
                                                    tb.removeFromStack(node);
                                                } else if (node == formatEl) {
                                                    element = new Element(Tag.valueOf(node.nodeName()), tb.getBaseUri());
                                                    tb.replaceActiveFormattingElement(node, element);
                                                    tb.replaceOnStack(node, element);
                                                    node2 = element;
                                                    if (lastNode.parent() != null) {
                                                        lastNode.remove();
                                                    }
                                                    node2.appendChild(lastNode);
                                                    lastNode = node2;
                                                } else {
                                                    if (StringUtil.in(commonAncestor.nodeName(), "table", "tbody", "tfoot", "thead", "tr")) {
                                                        if (lastNode.parent() != null) {
                                                            lastNode.remove();
                                                        }
                                                        commonAncestor.appendChild(lastNode);
                                                    } else {
                                                        if (lastNode.parent() != null) {
                                                            lastNode.remove();
                                                        }
                                                        tb.insertInFosterParent(lastNode);
                                                    }
                                                    element2 = new Element(Tag.valueOf(name), tb.getBaseUri());
                                                    for (Node childNode : (Node[]) furthestBlock.childNodes().toArray(new Node[furthestBlock.childNodes().size()])) {
                                                        element2.appendChild(childNode);
                                                    }
                                                    furthestBlock.appendChild(element2);
                                                    tb.removeFromActiveFormattingElements(formatEl);
                                                    tb.removeFromStack(formatEl);
                                                    tb.insertOnStackAfter(furthestBlock, element2);
                                                    i++;
                                                }
                                            }
                                            if (StringUtil.in(commonAncestor.nodeName(), "table", "tbody", "tfoot", "thead", "tr")) {
                                                if (lastNode.parent() != null) {
                                                    lastNode.remove();
                                                }
                                                commonAncestor.appendChild(lastNode);
                                            } else {
                                                if (lastNode.parent() != null) {
                                                    lastNode.remove();
                                                }
                                                tb.insertInFosterParent(lastNode);
                                            }
                                            element2 = new Element(Tag.valueOf(name), tb.getBaseUri());
                                            while (r36 < r35) {
                                                element2.appendChild(childNode);
                                            }
                                            furthestBlock.appendChild(element2);
                                            tb.removeFromActiveFormattingElements(formatEl);
                                            tb.removeFromStack(formatEl);
                                            tb.insertOnStackAfter(furthestBlock, element2);
                                            i++;
                                        }
                                    }
                                    if (furthestBlock != null) {
                                        node = furthestBlock;
                                        lastNode = furthestBlock;
                                        for (j = 0; j < 3; j++) {
                                            if (tb.onStack(node)) {
                                                node = tb.aboveOnStack(node);
                                            }
                                            if (!tb.isInActiveFormattingElements(node)) {
                                                tb.removeFromStack(node);
                                            } else if (node == formatEl) {
                                                if (StringUtil.in(commonAncestor.nodeName(), "table", "tbody", "tfoot", "thead", "tr")) {
                                                    if (lastNode.parent() != null) {
                                                        lastNode.remove();
                                                    }
                                                    tb.insertInFosterParent(lastNode);
                                                } else {
                                                    if (lastNode.parent() != null) {
                                                        lastNode.remove();
                                                    }
                                                    commonAncestor.appendChild(lastNode);
                                                }
                                                element2 = new Element(Tag.valueOf(name), tb.getBaseUri());
                                                while (r36 < r35) {
                                                    element2.appendChild(childNode);
                                                }
                                                furthestBlock.appendChild(element2);
                                                tb.removeFromActiveFormattingElements(formatEl);
                                                tb.removeFromStack(formatEl);
                                                tb.insertOnStackAfter(furthestBlock, element2);
                                                i++;
                                            } else {
                                                element = new Element(Tag.valueOf(node.nodeName()), tb.getBaseUri());
                                                tb.replaceActiveFormattingElement(node, element);
                                                tb.replaceOnStack(node, element);
                                                node2 = element;
                                                if (lastNode.parent() != null) {
                                                    lastNode.remove();
                                                }
                                                node2.appendChild(lastNode);
                                                lastNode = node2;
                                            }
                                        }
                                        if (StringUtil.in(commonAncestor.nodeName(), "table", "tbody", "tfoot", "thead", "tr")) {
                                            if (lastNode.parent() != null) {
                                                lastNode.remove();
                                            }
                                            commonAncestor.appendChild(lastNode);
                                        } else {
                                            if (lastNode.parent() != null) {
                                                lastNode.remove();
                                            }
                                            tb.insertInFosterParent(lastNode);
                                        }
                                        element2 = new Element(Tag.valueOf(name), tb.getBaseUri());
                                        while (r36 < r35) {
                                            element2.appendChild(childNode);
                                        }
                                        furthestBlock.appendChild(element2);
                                        tb.removeFromActiveFormattingElements(formatEl);
                                        tb.removeFromStack(formatEl);
                                        tb.insertOnStackAfter(furthestBlock, element2);
                                        i++;
                                    } else {
                                        tb.popStackToClose(formatEl.nodeName());
                                        tb.removeFromActiveFormattingElements(formatEl);
                                        return true;
                                    }
                                }
                                tb.error(this);
                                return false;
                            }
                            tb.error(this);
                            tb.removeFromActiveFormattingElements(formatEl);
                            return true;
                        }
                        break;
                    }
                    if (StringUtil.in(name, "applet", "marquee", "object")) {
                        if (!tb.inScope("name")) {
                            if (tb.inScope(name)) {
                                tb.generateImpliedEndTags();
                                if (!tb.currentElement().nodeName().equals(name)) {
                                    tb.error(this);
                                }
                                tb.popStackToClose(name);
                                tb.clearFormattingElementsToLastMarker();
                                break;
                            }
                            tb.error(this);
                            return false;
                        }
                    }
                    if (!name.equals("br")) {
                        return anyOtherEndTag(t, tb);
                    }
                    tb.error(this);
                    tb.process(new StartTag("br"));
                    return false;
                    break;
                case Wbxml.LITERAL /*4*/:
                    tb.insert(t.asComment());
                    break;
                case org.kxml2.kdom.Node.CDSECT /*5*/:
                    Character c = t.asCharacter();
                    if (!c.getData().equals(TreeBuilderState.nullString)) {
                        if (!TreeBuilderState.isWhitespace(c)) {
                            tb.reconstructFormattingElements();
                            tb.insert(c);
                            tb.framesetOk(false);
                            break;
                        }
                        tb.reconstructFormattingElements();
                        tb.insert(c);
                        break;
                    }
                    tb.error(this);
                    return false;
            }
            return true;
        }

        boolean anyOtherEndTag(Token t, TreeBuilder tb) {
            String name = t.asEndTag().name();
            Iterator<Element> it = tb.getStack().descendingIterator();
            while (it.hasNext()) {
                Element node = (Element) it.next();
                if (node.nodeName().equals(name)) {
                    tb.generateImpliedEndTags(name);
                    if (!name.equals(tb.currentElement().nodeName())) {
                        tb.error(this);
                    }
                    tb.popStackToClose(name);
                    return true;
                } else if (tb.isSpecial(node)) {
                    tb.error(this);
                    return false;
                }
            }
            return true;
        }
    },
    Text {
        boolean process(Token t, TreeBuilder tb) {
            if (t.isCharacter()) {
                tb.insert(t.asCharacter());
            } else if (t.isEOF()) {
                tb.error(this);
                tb.pop();
                tb.transition(tb.originalState());
                return tb.process(t);
            } else if (t.isEndTag()) {
                tb.pop();
                tb.transition(tb.originalState());
            }
            return true;
        }
    },
    InTable {
        boolean process(Token t, TreeBuilder tb) {
            String str = "table";
            if (t.isCharacter()) {
                tb.newPendingTableCharacters();
                tb.markInsertionMode();
                tb.transition(InTableText);
                return tb.process(t);
            }
            if (t.isComment()) {
                tb.insert(t.asComment());
            } else if (t.isDoctype()) {
                tb.error(this);
                return false;
            } else if (t.isStartTag()) {
                StartTag startTag = t.asStartTag();
                name = startTag.name();
                if (name.equals("caption")) {
                    tb.clearStackToTableContext();
                    tb.insertMarkerToFormattingElements();
                    tb.insert(startTag);
                    tb.transition(InCaption);
                } else if (name.equals("colgroup")) {
                    tb.clearStackToTableContext();
                    tb.insert(startTag);
                    tb.transition(InColumnGroup);
                } else if (name.equals("col")) {
                    tb.process(new StartTag("colgroup"));
                    return tb.process(t);
                } else {
                    if (StringUtil.in(name, "tbody", "tfoot", "thead")) {
                        tb.clearStackToTableContext();
                        tb.insert(startTag);
                        tb.transition(InTableBody);
                    } else {
                        if (StringUtil.in(name, "td", "th", "tr")) {
                            tb.process(new StartTag("tbody"));
                            return tb.process(t);
                        }
                        r5 = "table";
                        if (name.equals(str)) {
                            tb.error(this);
                            String str2 = "table";
                            if (tb.process(new EndTag(str))) {
                                return tb.process(t);
                            }
                        }
                        if (StringUtil.in(name, "style", "script")) {
                            return tb.process(t, InHead);
                        }
                        if (name.equals("input")) {
                            if (!startTag.attributes.get("type").equalsIgnoreCase("hidden")) {
                                return anythingElse(t, tb);
                            }
                            tb.insertEmpty(startTag);
                        } else if (!name.equals("form")) {
                            return anythingElse(t, tb);
                        } else {
                            tb.error(this);
                            if (tb.getFormElement() != null) {
                                return false;
                            }
                            tb.setFormElement(tb.insertEmpty(startTag));
                        }
                    }
                }
            } else if (t.isEndTag()) {
                name = t.asEndTag().name();
                r5 = "table";
                if (!name.equals(str)) {
                    if (!StringUtil.in(name, "body", "caption", "col", "colgroup", "html", "tbody", "td", "tfoot", "th", "thead", "tr")) {
                        return anythingElse(t, tb);
                    }
                    tb.error(this);
                    return false;
                } else if (tb.inTableScope(name)) {
                    r5 = "table";
                    tb.popStackToClose(str);
                    tb.resetInsertionMode();
                } else {
                    tb.error(this);
                    return false;
                }
            } else if (t.isEOF()) {
                if (tb.currentElement().nodeName().equals("html")) {
                    tb.error(this);
                }
                return true;
            }
            return anythingElse(t, tb);
        }

        boolean anythingElse(Token t, TreeBuilder tb) {
            tb.error(this);
            if (!StringUtil.in(tb.currentElement().nodeName(), "table", "tbody", "tfoot", "thead", "tr")) {
                return tb.process(t, InBody);
            }
            tb.setFosterInserts(true);
            boolean processed = tb.process(t, InBody);
            tb.setFosterInserts(false);
            return processed;
        }
    },
    InTableText {
        private static /* synthetic */ int[] $SWITCH_TABLE$org$jsoup$parser$Token$TokenType;

        static /* synthetic */ int[] $SWITCH_TABLE$org$jsoup$parser$Token$TokenType() {
            int[] iArr = $SWITCH_TABLE$org$jsoup$parser$Token$TokenType;
            if (iArr == null) {
                iArr = new int[TokenType.values().length];
                try {
                    iArr[TokenType.Character.ordinal()] = 5;
                } catch (NoSuchFieldError e) {
                }
                try {
                    iArr[TokenType.Comment.ordinal()] = 4;
                } catch (NoSuchFieldError e2) {
                }
                try {
                    iArr[TokenType.Doctype.ordinal()] = 1;
                } catch (NoSuchFieldError e3) {
                }
                try {
                    iArr[TokenType.EOF.ordinal()] = 6;
                } catch (NoSuchFieldError e4) {
                }
                try {
                    iArr[TokenType.EndTag.ordinal()] = 3;
                } catch (NoSuchFieldError e5) {
                }
                try {
                    iArr[TokenType.StartTag.ordinal()] = 2;
                } catch (NoSuchFieldError e6) {
                }
                $SWITCH_TABLE$org$jsoup$parser$Token$TokenType = iArr;
            }
            return iArr;
        }

        boolean process(Token t, TreeBuilder tb) {
            switch ($SWITCH_TABLE$org$jsoup$parser$Token$TokenType()[t.type.ordinal()]) {
                case org.kxml2.kdom.Node.CDSECT /*5*/:
                    Character c = t.asCharacter();
                    if (c.getData().equals(TreeBuilderState.nullString)) {
                        tb.error(this);
                        return false;
                    }
                    tb.getPendingTableCharacters().add(c);
                    return true;
                default:
                    if (tb.getPendingTableCharacters().size() > 0) {
                        for (Character character : tb.getPendingTableCharacters()) {
                            if (TreeBuilderState.isWhitespace(character)) {
                                tb.insert(character);
                            } else {
                                tb.error(this);
                                if (StringUtil.in(tb.currentElement().nodeName(), "table", "tbody", "tfoot", "thead", "tr")) {
                                    tb.setFosterInserts(true);
                                    tb.process(character, InBody);
                                    tb.setFosterInserts(false);
                                } else {
                                    tb.process(character, InBody);
                                }
                            }
                        }
                        tb.newPendingTableCharacters();
                    }
                    tb.transition(tb.originalState());
                    return tb.process(t);
            }
        }
    },
    InCaption {
        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        boolean process(org.jsoup.parser.Token r13, org.jsoup.parser.TreeBuilder r14) {
            /*
            r12 = this;
            r11 = 3;
            r10 = 2;
            r9 = 1;
            r8 = 0;
            r7 = "caption";
            r3 = r13.isEndTag();
            if (r3 == 0) goto L_0x0054;
        L_0x000c:
            r3 = r13.asEndTag();
            r3 = r3.name();
            r4 = "caption";
            r3 = r3.equals(r7);
            if (r3 == 0) goto L_0x0054;
        L_0x001c:
            r0 = r13.asEndTag();
            r1 = r0.name();
            r3 = r14.inTableScope(r1);
            if (r3 != 0) goto L_0x002f;
        L_0x002a:
            r14.error(r12);
            r3 = r8;
        L_0x002e:
            return r3;
        L_0x002f:
            r14.generateImpliedEndTags();
            r3 = r14.currentElement();
            r3 = r3.nodeName();
            r4 = "caption";
            r3 = r3.equals(r7);
            if (r3 != 0) goto L_0x0045;
        L_0x0042:
            r14.error(r12);
        L_0x0045:
            r3 = "caption";
            r14.popStackToClose(r7);
            r14.clearFormattingElementsToLastMarker();
            r3 = InTable;
            r14.transition(r3);
        L_0x0052:
            r3 = r9;
            goto L_0x002e;
        L_0x0054:
            r3 = r13.isStartTag();
            if (r3 == 0) goto L_0x0096;
        L_0x005a:
            r3 = r13.asStartTag();
            r3 = r3.name();
            r4 = 9;
            r4 = new java.lang.String[r4];
            r5 = "caption";
            r4[r8] = r7;
            r5 = "col";
            r4[r9] = r5;
            r5 = "colgroup";
            r4[r10] = r5;
            r5 = "tbody";
            r4[r11] = r5;
            r5 = 4;
            r6 = "td";
            r4[r5] = r6;
            r5 = 5;
            r6 = "tfoot";
            r4[r5] = r6;
            r5 = 6;
            r6 = "th";
            r4[r5] = r6;
            r5 = 7;
            r6 = "thead";
            r4[r5] = r6;
            r5 = 8;
            r6 = "tr";
            r4[r5] = r6;
            r3 = org.jsoup.helper.StringUtil.in(r3, r4);
            if (r3 != 0) goto L_0x00ac;
        L_0x0096:
            r3 = r13.isEndTag();
            if (r3 == 0) goto L_0x00c2;
        L_0x009c:
            r3 = r13.asEndTag();
            r3 = r3.name();
            r4 = "table";
            r3 = r3.equals(r4);
            if (r3 == 0) goto L_0x00c2;
        L_0x00ac:
            r14.error(r12);
            r3 = new org.jsoup.parser.Token$EndTag;
            r4 = "caption";
            r3.<init>(r7);
            r2 = r14.process(r3);
            if (r2 == 0) goto L_0x0052;
        L_0x00bc:
            r3 = r14.process(r13);
            goto L_0x002e;
        L_0x00c2:
            r3 = r13.isEndTag();
            if (r3 == 0) goto L_0x0110;
        L_0x00c8:
            r3 = r13.asEndTag();
            r3 = r3.name();
            r4 = 10;
            r4 = new java.lang.String[r4];
            r5 = "body";
            r4[r8] = r5;
            r5 = "col";
            r4[r9] = r5;
            r5 = "colgroup";
            r4[r10] = r5;
            r5 = "html";
            r4[r11] = r5;
            r5 = 4;
            r6 = "tbody";
            r4[r5] = r6;
            r5 = 5;
            r6 = "td";
            r4[r5] = r6;
            r5 = 6;
            r6 = "tfoot";
            r4[r5] = r6;
            r5 = 7;
            r6 = "th";
            r4[r5] = r6;
            r5 = 8;
            r6 = "thead";
            r4[r5] = r6;
            r5 = 9;
            r6 = "tr";
            r4[r5] = r6;
            r3 = org.jsoup.helper.StringUtil.in(r3, r4);
            if (r3 == 0) goto L_0x0110;
        L_0x010a:
            r14.error(r12);
            r3 = r8;
            goto L_0x002e;
        L_0x0110:
            r3 = InBody;
            r3 = r14.process(r13, r3);
            goto L_0x002e;
            */
            throw new UnsupportedOperationException("Method not decompiled: org.jsoup.parser.TreeBuilderState.11.process(org.jsoup.parser.Token, org.jsoup.parser.TreeBuilder):boolean");
        }
    },
    InColumnGroup {
        private static /* synthetic */ int[] $SWITCH_TABLE$org$jsoup$parser$Token$TokenType;

        static /* synthetic */ int[] $SWITCH_TABLE$org$jsoup$parser$Token$TokenType() {
            int[] iArr = $SWITCH_TABLE$org$jsoup$parser$Token$TokenType;
            if (iArr == null) {
                iArr = new int[TokenType.values().length];
                try {
                    iArr[TokenType.Character.ordinal()] = 5;
                } catch (NoSuchFieldError e) {
                }
                try {
                    iArr[TokenType.Comment.ordinal()] = 4;
                } catch (NoSuchFieldError e2) {
                }
                try {
                    iArr[TokenType.Doctype.ordinal()] = 1;
                } catch (NoSuchFieldError e3) {
                }
                try {
                    iArr[TokenType.EOF.ordinal()] = 6;
                } catch (NoSuchFieldError e4) {
                }
                try {
                    iArr[TokenType.EndTag.ordinal()] = 3;
                } catch (NoSuchFieldError e5) {
                }
                try {
                    iArr[TokenType.StartTag.ordinal()] = 2;
                } catch (NoSuchFieldError e6) {
                }
                $SWITCH_TABLE$org$jsoup$parser$Token$TokenType = iArr;
            }
            return iArr;
        }

        boolean process(Token t, TreeBuilder tb) {
            String str = "html";
            if (TreeBuilderState.isWhitespace(t)) {
                tb.insert(t.asCharacter());
                return true;
            }
            String str2;
            switch ($SWITCH_TABLE$org$jsoup$parser$Token$TokenType()[t.type.ordinal()]) {
                case Wbxml.END /*1*/:
                    tb.error(this);
                    break;
                case Wbxml.ENTITY /*2*/:
                    StartTag startTag = t.asStartTag();
                    String name = startTag.name();
                    String str3 = "html";
                    if (name.equals(str)) {
                        return tb.process(t, InBody);
                    }
                    if (name.equals("col")) {
                        tb.insertEmpty(startTag);
                        break;
                    }
                    return anythingElse(t, tb);
                case Wbxml.STR_I /*3*/:
                    if (t.asEndTag().name().equals("colgroup")) {
                        str2 = "html";
                        if (!tb.currentElement().nodeName().equals(str)) {
                            tb.pop();
                            tb.transition(InTable);
                            break;
                        }
                        tb.error(this);
                        return false;
                    }
                    return anythingElse(t, tb);
                case Wbxml.LITERAL /*4*/:
                    tb.insert(t.asComment());
                    break;
                case org.kxml2.kdom.Node.ENTITY_REF /*6*/:
                    str2 = "html";
                    if (tb.currentElement().nodeName().equals(str)) {
                        return true;
                    }
                    return anythingElse(t, tb);
                default:
                    return anythingElse(t, tb);
            }
            return true;
        }

        private boolean anythingElse(Token t, TreeBuilder tb) {
            if (tb.process(new EndTag("colgroup"))) {
                return tb.process(t);
            }
            return true;
        }
    },
    InTableBody {
        private static /* synthetic */ int[] $SWITCH_TABLE$org$jsoup$parser$Token$TokenType;

        static /* synthetic */ int[] $SWITCH_TABLE$org$jsoup$parser$Token$TokenType() {
            int[] iArr = $SWITCH_TABLE$org$jsoup$parser$Token$TokenType;
            if (iArr == null) {
                iArr = new int[TokenType.values().length];
                try {
                    iArr[TokenType.Character.ordinal()] = 5;
                } catch (NoSuchFieldError e) {
                }
                try {
                    iArr[TokenType.Comment.ordinal()] = 4;
                } catch (NoSuchFieldError e2) {
                }
                try {
                    iArr[TokenType.Doctype.ordinal()] = 1;
                } catch (NoSuchFieldError e3) {
                }
                try {
                    iArr[TokenType.EOF.ordinal()] = 6;
                } catch (NoSuchFieldError e4) {
                }
                try {
                    iArr[TokenType.EndTag.ordinal()] = 3;
                } catch (NoSuchFieldError e5) {
                }
                try {
                    iArr[TokenType.StartTag.ordinal()] = 2;
                } catch (NoSuchFieldError e6) {
                }
                $SWITCH_TABLE$org$jsoup$parser$Token$TokenType = iArr;
            }
            return iArr;
        }

        boolean process(Token t, TreeBuilder tb) {
            String str = "tr";
            String name;
            switch ($SWITCH_TABLE$org$jsoup$parser$Token$TokenType()[t.type.ordinal()]) {
                case Wbxml.ENTITY /*2*/:
                    StartTag startTag = t.asStartTag();
                    name = startTag.name();
                    String str2 = "tr";
                    if (name.equals(str)) {
                        tb.clearStackToTableBodyContext();
                        tb.insert(startTag);
                        tb.transition(InRow);
                        break;
                    }
                    if (StringUtil.in(name, "th", "td")) {
                        tb.error(this);
                        String str3 = "tr";
                        tb.process(new StartTag(str));
                        return tb.process(startTag);
                    }
                    if (StringUtil.in(name, "caption", "col", "colgroup", "tbody", "tfoot", "thead")) {
                        return exitTableBody(t, tb);
                    }
                    return anythingElse(t, tb);
                case Wbxml.STR_I /*3*/:
                    name = t.asEndTag().name();
                    if (StringUtil.in(name, "tbody", "tfoot", "thead")) {
                        if (tb.inTableScope(name)) {
                            tb.clearStackToTableBodyContext();
                            tb.pop();
                            tb.transition(InTable);
                            break;
                        }
                        tb.error(this);
                        return false;
                    } else if (name.equals("table")) {
                        return exitTableBody(t, tb);
                    } else {
                        String[] strArr = new String[8];
                        strArr[0] = "body";
                        strArr[1] = "caption";
                        strArr[2] = "col";
                        strArr[3] = "colgroup";
                        strArr[4] = "html";
                        strArr[5] = "td";
                        strArr[6] = "th";
                        String str4 = "tr";
                        strArr[7] = str;
                        if (!StringUtil.in(name, strArr)) {
                            return anythingElse(t, tb);
                        }
                        tb.error(this);
                        return false;
                    }
                default:
                    return anythingElse(t, tb);
            }
            return true;
        }

        private boolean exitTableBody(Token t, TreeBuilder tb) {
            if (tb.inTableScope("tbody") || tb.inTableScope("thead") || tb.inScope("tfoot")) {
                tb.clearStackToTableBodyContext();
                tb.process(new EndTag(tb.currentElement().nodeName()));
                return tb.process(t);
            }
            tb.error(this);
            return false;
        }

        private boolean anythingElse(Token t, TreeBuilder tb) {
            return tb.process(t, InTable);
        }
    },
    InRow {
        boolean process(Token t, TreeBuilder tb) {
            String str = "tr";
            String name;
            if (t.isStartTag()) {
                StartTag startTag = t.asStartTag();
                name = startTag.name();
                if (StringUtil.in(name, "th", "td")) {
                    tb.clearStackToTableRowContext();
                    tb.insert(startTag);
                    tb.transition(InCell);
                    tb.insertMarkerToFormattingElements();
                } else {
                    String[] strArr = new String[7];
                    strArr[0] = "caption";
                    strArr[1] = "col";
                    strArr[2] = "colgroup";
                    strArr[3] = "tbody";
                    strArr[4] = "tfoot";
                    strArr[5] = "thead";
                    String str2 = "tr";
                    strArr[6] = str;
                    if (StringUtil.in(name, strArr)) {
                        return handleMissingTr(t, tb);
                    }
                    return anythingElse(t, tb);
                }
            } else if (!t.isEndTag()) {
                return anythingElse(t, tb);
            } else {
                name = t.asEndTag().name();
                String str3 = "tr";
                if (name.equals(str)) {
                    if (tb.inTableScope(name)) {
                        tb.clearStackToTableRowContext();
                        tb.pop();
                        tb.transition(InTableBody);
                    } else {
                        tb.error(this);
                        return false;
                    }
                } else if (name.equals("table")) {
                    return handleMissingTr(t, tb);
                } else {
                    if (!StringUtil.in(name, "tbody", "tfoot", "thead")) {
                        if (!StringUtil.in(name, "body", "caption", "col", "colgroup", "html", "td", "th")) {
                            return anythingElse(t, tb);
                        }
                        tb.error(this);
                        return false;
                    } else if (tb.inTableScope(name)) {
                        String str4 = "tr";
                        tb.process(new EndTag(str));
                        return tb.process(t);
                    } else {
                        tb.error(this);
                        return false;
                    }
                }
            }
            return true;
        }

        private boolean anythingElse(Token t, TreeBuilder tb) {
            return tb.process(t, InTable);
        }

        private boolean handleMissingTr(Token t, TreeBuilder tb) {
            if (tb.process(new EndTag("tr"))) {
                return tb.process(t);
            }
            return false;
        }
    },
    InCell {
        boolean process(Token t, TreeBuilder tb) {
            if (t.isEndTag()) {
                String name = t.asEndTag().name();
                if (!StringUtil.in(name, "td", "th")) {
                    if (StringUtil.in(name, "body", "caption", "col", "colgroup", "html")) {
                        tb.error(this);
                        return false;
                    }
                    if (!StringUtil.in(name, "table", "tbody", "tfoot", "thead", "tr")) {
                        return anythingElse(t, tb);
                    }
                    if (tb.inTableScope(name)) {
                        closeCell(tb);
                        return tb.process(t);
                    }
                    tb.error(this);
                    return false;
                } else if (tb.inTableScope(name)) {
                    tb.generateImpliedEndTags();
                    if (!tb.currentElement().nodeName().equals(name)) {
                        tb.error(this);
                    }
                    tb.popStackToClose(name);
                    tb.clearFormattingElementsToLastMarker();
                    tb.transition(InRow);
                    return true;
                } else {
                    tb.error(this);
                    tb.transition(InRow);
                    return false;
                }
            }
            if (t.isStartTag()) {
                if (StringUtil.in(t.asStartTag().name(), "caption", "col", "colgroup", "tbody", "td", "tfoot", "th", "thead", "tr")) {
                    if (tb.inTableScope("td") || tb.inTableScope("th")) {
                        closeCell(tb);
                        return tb.process(t);
                    }
                    tb.error(this);
                    return false;
                }
            }
            return anythingElse(t, tb);
        }

        private boolean anythingElse(Token t, TreeBuilder tb) {
            return tb.process(t, InBody);
        }

        private void closeCell(TreeBuilder tb) {
            String str = "td";
            String str2 = "td";
            if (tb.inTableScope(str)) {
                String str3 = "td";
                tb.process(new EndTag(str));
                return;
            }
            tb.process(new EndTag("th"));
        }
    },
    InSelect {
        private static /* synthetic */ int[] $SWITCH_TABLE$org$jsoup$parser$Token$TokenType;

        static /* synthetic */ int[] $SWITCH_TABLE$org$jsoup$parser$Token$TokenType() {
            int[] iArr = $SWITCH_TABLE$org$jsoup$parser$Token$TokenType;
            if (iArr == null) {
                iArr = new int[TokenType.values().length];
                try {
                    iArr[TokenType.Character.ordinal()] = 5;
                } catch (NoSuchFieldError e) {
                }
                try {
                    iArr[TokenType.Comment.ordinal()] = 4;
                } catch (NoSuchFieldError e2) {
                }
                try {
                    iArr[TokenType.Doctype.ordinal()] = 1;
                } catch (NoSuchFieldError e3) {
                }
                try {
                    iArr[TokenType.EOF.ordinal()] = 6;
                } catch (NoSuchFieldError e4) {
                }
                try {
                    iArr[TokenType.EndTag.ordinal()] = 3;
                } catch (NoSuchFieldError e5) {
                }
                try {
                    iArr[TokenType.StartTag.ordinal()] = 2;
                } catch (NoSuchFieldError e6) {
                }
                $SWITCH_TABLE$org$jsoup$parser$Token$TokenType = iArr;
            }
            return iArr;
        }

        boolean process(Token t, TreeBuilder tb) {
            String str = "select";
            String str2 = "optgroup";
            String str3 = "option";
            String name;
            String str4;
            String str5;
            switch ($SWITCH_TABLE$org$jsoup$parser$Token$TokenType()[t.type.ordinal()]) {
                case Wbxml.END /*1*/:
                    tb.error(this);
                    return false;
                case Wbxml.ENTITY /*2*/:
                    StartTag start = t.asStartTag();
                    name = start.name();
                    if (name.equals("html")) {
                        return tb.process(start, InBody);
                    }
                    str4 = "option";
                    if (name.equals(str3)) {
                        str5 = "option";
                        tb.process(new EndTag(str3));
                        tb.insert(start);
                        break;
                    }
                    str4 = "optgroup";
                    if (name.equals(str2)) {
                        str5 = "option";
                        if (tb.currentElement().nodeName().equals(str3)) {
                            str5 = "option";
                            tb.process(new EndTag(str3));
                        } else {
                            str5 = "optgroup";
                            if (tb.currentElement().nodeName().equals(str2)) {
                                str5 = "optgroup";
                                tb.process(new EndTag(str2));
                            }
                        }
                        tb.insert(start);
                        break;
                    }
                    str4 = "select";
                    if (name.equals(str)) {
                        tb.error(this);
                        str5 = "select";
                        return tb.process(new EndTag(str));
                    }
                    if (StringUtil.in(name, "input", "keygen", "textarea")) {
                        tb.error(this);
                        str4 = "select";
                        if (!tb.inSelectScope(str)) {
                            return false;
                        }
                        str5 = "select";
                        tb.process(new EndTag(str));
                        return tb.process(start);
                    } else if (name.equals("script")) {
                        return tb.process(t, InHead);
                    } else {
                        return anythingElse(t, tb);
                    }
                case Wbxml.STR_I /*3*/:
                    name = t.asEndTag().name();
                    str4 = "optgroup";
                    if (name.equals(str2)) {
                        str5 = "option";
                        if (tb.currentElement().nodeName().equals(str3) && tb.aboveOnStack(tb.currentElement()) != null) {
                            str5 = "optgroup";
                            if (tb.aboveOnStack(tb.currentElement()).nodeName().equals(str2)) {
                                str5 = "option";
                                tb.process(new EndTag(str3));
                            }
                        }
                        str5 = "optgroup";
                        if (!tb.currentElement().nodeName().equals(str2)) {
                            tb.error(this);
                            break;
                        }
                        tb.pop();
                        break;
                    }
                    str4 = "option";
                    if (name.equals(str3)) {
                        str5 = "option";
                        if (!tb.currentElement().nodeName().equals(str3)) {
                            tb.error(this);
                            break;
                        }
                        tb.pop();
                        break;
                    }
                    str4 = "select";
                    if (name.equals(str)) {
                        if (tb.inSelectScope(name)) {
                            tb.popStackToClose(name);
                            tb.resetInsertionMode();
                            break;
                        }
                        tb.error(this);
                        return false;
                    }
                    return anythingElse(t, tb);
                case Wbxml.LITERAL /*4*/:
                    tb.insert(t.asComment());
                    break;
                case org.kxml2.kdom.Node.CDSECT /*5*/:
                    Character c = t.asCharacter();
                    if (!c.getData().equals(TreeBuilderState.nullString)) {
                        tb.insert(c);
                        break;
                    }
                    tb.error(this);
                    return false;
                case org.kxml2.kdom.Node.ENTITY_REF /*6*/:
                    if (!tb.currentElement().nodeName().equals("html")) {
                        tb.error(this);
                        break;
                    }
                    break;
                default:
                    return anythingElse(t, tb);
            }
            return true;
        }

        private boolean anythingElse(Token t, TreeBuilder tb) {
            tb.error(this);
            return false;
        }
    },
    InSelectInTable {
        boolean process(Token t, TreeBuilder tb) {
            if (t.isStartTag()) {
                if (StringUtil.in(t.asStartTag().name(), "caption", "table", "tbody", "tfoot", "thead", "tr", "td", "th")) {
                    tb.error(this);
                    tb.process(new EndTag("select"));
                    return tb.process(t);
                }
            }
            if (t.isEndTag()) {
                if (StringUtil.in(t.asEndTag().name(), "caption", "table", "tbody", "tfoot", "thead", "tr", "td", "th")) {
                    tb.error(this);
                    if (!tb.inTableScope(t.asEndTag().name())) {
                        return false;
                    }
                    tb.process(new EndTag("select"));
                    return tb.process(t);
                }
            }
            return tb.process(t, InSelect);
        }
    },
    AfterBody {
        boolean process(Token t, TreeBuilder tb) {
            String str = "html";
            if (TreeBuilderState.isWhitespace(t)) {
                return tb.process(t, InBody);
            }
            if (t.isComment()) {
                tb.insert(t.asComment());
            } else if (t.isDoctype()) {
                tb.error(this);
                return false;
            } else {
                String str2;
                if (t.isStartTag()) {
                    str2 = "html";
                    if (t.asStartTag().name().equals(str)) {
                        return tb.process(t, InBody);
                    }
                }
                if (t.isEndTag()) {
                    str2 = "html";
                    if (t.asEndTag().name().equals(str)) {
                        if (tb.isFragmentParsing()) {
                            tb.error(this);
                            return false;
                        }
                        tb.transition(AfterAfterBody);
                    }
                }
                if (!t.isEOF()) {
                    tb.error(this);
                    tb.transition(InBody);
                    return tb.process(t);
                }
            }
            return true;
        }
    },
    InFrameset {
        boolean process(Token t, TreeBuilder tb) {
            String str = "html";
            String str2 = "frameset";
            if (TreeBuilderState.isWhitespace(t)) {
                tb.insert(t.asCharacter());
            } else if (t.isComment()) {
                tb.insert(t.asComment());
            } else if (t.isDoctype()) {
                tb.error(this);
                return false;
            } else if (t.isStartTag()) {
                StartTag start = t.asStartTag();
                String name = start.name();
                String str3 = "html";
                if (name.equals(str)) {
                    return tb.process(start, InBody);
                }
                str3 = "frameset";
                if (name.equals(str2)) {
                    tb.insert(start);
                } else if (name.equals("frame")) {
                    tb.insertEmpty(start);
                } else if (name.equals("noframes")) {
                    return tb.process(start, InHead);
                } else {
                    tb.error(this);
                    return false;
                }
            } else {
                String str4;
                if (t.isEndTag()) {
                    str4 = "frameset";
                    if (t.asEndTag().name().equals(str2)) {
                        str4 = "html";
                        if (tb.currentElement().nodeName().equals(str)) {
                            tb.error(this);
                            return false;
                        }
                        tb.pop();
                        if (!tb.isFragmentParsing()) {
                            str4 = "frameset";
                            if (!tb.currentElement().nodeName().equals(str2)) {
                                tb.transition(AfterFrameset);
                            }
                        }
                    }
                }
                if (t.isEOF()) {
                    str4 = "html";
                    if (!tb.currentElement().nodeName().equals(str)) {
                        tb.error(this);
                        return true;
                    }
                }
                tb.error(this);
                return false;
            }
            return true;
        }
    },
    AfterFrameset {
        boolean process(Token t, TreeBuilder tb) {
            String str = "html";
            if (TreeBuilderState.isWhitespace(t)) {
                tb.insert(t.asCharacter());
            } else if (t.isComment()) {
                tb.insert(t.asComment());
            } else if (t.isDoctype()) {
                tb.error(this);
                return false;
            } else {
                String str2;
                if (t.isStartTag()) {
                    str2 = "html";
                    if (t.asStartTag().name().equals(str)) {
                        return tb.process(t, InBody);
                    }
                }
                if (t.isEndTag()) {
                    str2 = "html";
                    if (t.asEndTag().name().equals(str)) {
                        tb.transition(AfterAfterFrameset);
                    }
                }
                if (t.isStartTag() && t.asStartTag().name().equals("noframes")) {
                    return tb.process(t, InHead);
                }
                if (!t.isEOF()) {
                    tb.error(this);
                    return false;
                }
            }
            return true;
        }
    },
    AfterAfterBody {
        boolean process(Token t, TreeBuilder tb) {
            if (t.isComment()) {
                tb.insert(t.asComment());
            } else if (t.isDoctype() || TreeBuilderState.isWhitespace(t) || (t.isStartTag() && t.asStartTag().name().equals("html"))) {
                return tb.process(t, InBody);
            } else {
                if (!t.isEOF()) {
                    tb.error(this);
                    tb.transition(InBody);
                    return tb.process(t);
                }
            }
            return true;
        }
    },
    AfterAfterFrameset {
        boolean process(Token t, TreeBuilder tb) {
            if (t.isComment()) {
                tb.insert(t.asComment());
            } else if (t.isDoctype() || TreeBuilderState.isWhitespace(t) || (t.isStartTag() && t.asStartTag().name().equals("html"))) {
                return tb.process(t, InBody);
            } else {
                if (!t.isEOF()) {
                    if (t.isStartTag() && t.asStartTag().name().equals("nofrmes")) {
                        return tb.process(t, InHead);
                    }
                    tb.error(this);
                    tb.transition(InBody);
                    return tb.process(t);
                }
            }
            return true;
        }
    },
    ForeignContent {
        boolean process(Token t, TreeBuilder tb) {
            return true;
        }
    };
    
    private static String nullString;

    abstract boolean process(Token token, TreeBuilder treeBuilder);

    static {
        nullString = String.valueOf('\u0000');
    }

    private static boolean isWhitespace(Token t) {
        if (!t.isCharacter()) {
            return false;
        }
        String data = t.asCharacter().getData();
        for (int i = 0; i < data.length(); i++) {
            if (!Character.isWhitespace(data.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    private static void handleRcData(StartTag startTag, TreeBuilder tb) {
        tb.insert(startTag);
        tb.tokeniser.transition(TokeniserState.Rcdata);
        tb.markInsertionMode();
        tb.transition(Text);
    }

    private static void handleRawtext(StartTag startTag, TreeBuilder tb) {
        tb.insert(startTag);
        tb.tokeniser.transition(TokeniserState.Rawtext);
        tb.markInsertionMode();
        tb.transition(Text);
    }
}
