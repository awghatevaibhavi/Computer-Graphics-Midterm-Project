package org.jsoup.parser;

import org.kxml2.kdom.Node;

enum TokeniserState {
    Data {
        void read(Tokeniser t, CharacterReader r) {
            switch (r.current()) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.emit(r.consume());
                case '&':
                    t.advanceTransition(CharacterReferenceInData);
                case '<':
                    t.advanceTransition(TagOpen);
                case '\uffff':
                    t.emit(new EOF());
                default:
                    t.emit(r.consumeToAny('&', '<', TokeniserState.nullChar));
            }
        }
    },
    CharacterReferenceInData {
        void read(Tokeniser t, CharacterReader r) {
            Character c = t.consumeCharacterReference(null, false);
            if (c == null) {
                t.emit('&');
            } else {
                t.emit(c.charValue());
            }
            t.transition(Data);
        }
    },
    Rcdata {
        void read(Tokeniser t, CharacterReader r) {
            switch (r.current()) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    r.advance();
                    t.emit((char) TokeniserState.replacementChar);
                case '&':
                    t.advanceTransition(CharacterReferenceInRcdata);
                case '<':
                    t.advanceTransition(RcdataLessthanSign);
                case '\uffff':
                    t.emit(new EOF());
                default:
                    t.emit(r.consumeToAny('&', '<', TokeniserState.nullChar));
            }
        }
    },
    CharacterReferenceInRcdata {
        void read(Tokeniser t, CharacterReader r) {
            Character c = t.consumeCharacterReference(null, false);
            if (c == null) {
                t.emit('&');
            } else {
                t.emit(c.charValue());
            }
            t.transition(Rcdata);
        }
    },
    Rawtext {
        void read(Tokeniser t, CharacterReader r) {
            switch (r.current()) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    r.advance();
                    t.emit((char) TokeniserState.replacementChar);
                case '<':
                    t.advanceTransition(RawtextLessthanSign);
                case '\uffff':
                    t.emit(new EOF());
                default:
                    t.emit(r.consumeToAny('<', TokeniserState.nullChar));
            }
        }
    },
    ScriptData {
        void read(Tokeniser t, CharacterReader r) {
            switch (r.current()) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    r.advance();
                    t.emit((char) TokeniserState.replacementChar);
                case '<':
                    t.advanceTransition(ScriptDataLessthanSign);
                case '\uffff':
                    t.emit(new EOF());
                default:
                    t.emit(r.consumeToAny('<', TokeniserState.nullChar));
            }
        }
    },
    PLAINTEXT {
        void read(Tokeniser t, CharacterReader r) {
            switch (r.current()) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    r.advance();
                    t.emit((char) TokeniserState.replacementChar);
                case '\uffff':
                    t.emit(new EOF());
                default:
                    t.emit(r.consumeTo((char) TokeniserState.nullChar));
            }
        }
    },
    TagOpen {
        void read(Tokeniser t, CharacterReader r) {
            switch (r.current()) {
                case '!':
                    t.advanceTransition(MarkupDeclarationOpen);
                case '/':
                    t.advanceTransition(EndTagOpen);
                case '?':
                    t.advanceTransition(BogusComment);
                default:
                    if (r.matchesLetter()) {
                        t.createTagPending(true);
                        t.transition(TagName);
                        return;
                    }
                    t.error((TokeniserState) this);
                    t.emit('<');
                    t.transition(Data);
            }
        }
    },
    EndTagOpen {
        void read(Tokeniser t, CharacterReader r) {
            if (r.isEmpty()) {
                t.eofError(this);
                t.emit("</");
                t.transition(Data);
            } else if (r.matchesLetter()) {
                t.createTagPending(false);
                t.transition(TagName);
            } else if (r.matches('>')) {
                t.error((TokeniserState) this);
                t.advanceTransition(Data);
            } else {
                t.error((TokeniserState) this);
                t.advanceTransition(BogusComment);
            }
        }
    },
    TagName {
        void read(Tokeniser t, CharacterReader r) {
            t.tagPending.appendTagName(r.consumeToAny('\t', '\n', '\f', ' ', '/', '>', TokeniserState.nullChar).toLowerCase());
            switch (r.consume()) {
                case Node.DOCUMENT /*0*/:
                    t.tagPending.appendTagName(TokeniserState.replacementStr);
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                    t.transition(BeforeAttributeName);
                case '/':
                    t.transition(SelfClosingStartTag);
                case '>':
                    t.emitTagPending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.transition(Data);
                default:
            }
        }
    },
    RcdataLessthanSign {
        void read(Tokeniser t, CharacterReader r) {
            if (r.matches('/')) {
                t.createTempBuffer();
                t.advanceTransition(RCDATAEndTagOpen);
            } else if (!r.matchesLetter() || r.containsIgnoreCase("</" + t.appropriateEndTagName())) {
                t.emit("<");
                t.transition(Rcdata);
            } else {
                t.tagPending = new EndTag(t.appropriateEndTagName());
                t.emitTagPending();
                r.unconsume();
                t.transition(Data);
            }
        }
    },
    RCDATAEndTagOpen {
        void read(Tokeniser t, CharacterReader r) {
            if (r.matchesLetter()) {
                t.createTagPending(false);
                t.tagPending.appendTagName(Character.toLowerCase(r.current()));
                t.dataBuffer.append(Character.toLowerCase(r.current()));
                t.advanceTransition(RCDATAEndTagName);
                return;
            }
            t.emit("</");
            t.transition(Rcdata);
        }
    },
    RCDATAEndTagName {
        void read(Tokeniser t, CharacterReader r) {
            if (r.matchesLetter()) {
                String name = r.consumeLetterSequence();
                t.tagPending.appendTagName(name.toLowerCase());
                t.dataBuffer.append(name);
                return;
            }
            switch (r.consume()) {
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                    if (t.isAppropriateEndTagToken()) {
                        t.transition(BeforeAttributeName);
                    } else {
                        anythingElse(t, r);
                    }
                case '/':
                    if (t.isAppropriateEndTagToken()) {
                        t.transition(SelfClosingStartTag);
                    } else {
                        anythingElse(t, r);
                    }
                case '>':
                    if (t.isAppropriateEndTagToken()) {
                        t.emitTagPending();
                        t.transition(Data);
                        return;
                    }
                    anythingElse(t, r);
                default:
                    anythingElse(t, r);
            }
        }

        private void anythingElse(Tokeniser t, CharacterReader r) {
            t.emit("</" + t.dataBuffer.toString());
            t.transition(Rcdata);
        }
    },
    RawtextLessthanSign {
        void read(Tokeniser t, CharacterReader r) {
            if (r.matches('/')) {
                t.createTempBuffer();
                t.advanceTransition(RawtextEndTagOpen);
                return;
            }
            t.emit('<');
            t.transition(Rawtext);
        }
    },
    RawtextEndTagOpen {
        void read(Tokeniser t, CharacterReader r) {
            if (r.matchesLetter()) {
                t.createTagPending(false);
                t.transition(RawtextEndTagName);
                return;
            }
            t.emit("</");
            t.transition(Rawtext);
        }
    },
    RawtextEndTagName {
        void read(Tokeniser t, CharacterReader r) {
            if (r.matchesLetter()) {
                String name = r.consumeLetterSequence();
                t.tagPending.appendTagName(name.toLowerCase());
                t.dataBuffer.append(name);
            } else if (!t.isAppropriateEndTagToken() || r.isEmpty()) {
                anythingElse(t, r);
            } else {
                char c = r.consume();
                switch (c) {
                    case Node.COMMENT /*9*/:
                    case Node.DOCDECL /*10*/:
                    case '\f':
                    case ' ':
                        t.transition(BeforeAttributeName);
                    case '/':
                        t.transition(SelfClosingStartTag);
                    case '>':
                        t.emitTagPending();
                        t.transition(Data);
                    default:
                        t.dataBuffer.append(c);
                        anythingElse(t, r);
                }
            }
        }

        private void anythingElse(Tokeniser t, CharacterReader r) {
            t.emit("</" + t.dataBuffer.toString());
            t.transition(Rawtext);
        }
    },
    ScriptDataLessthanSign {
        void read(Tokeniser t, CharacterReader r) {
            switch (r.consume()) {
                case '!':
                    t.emit("<!");
                    t.transition(ScriptDataEscapeStart);
                case '/':
                    t.createTempBuffer();
                    t.transition(ScriptDataEndTagOpen);
                default:
                    t.emit("<");
                    r.unconsume();
                    t.transition(ScriptData);
            }
        }
    },
    ScriptDataEndTagOpen {
        void read(Tokeniser t, CharacterReader r) {
            if (r.matchesLetter()) {
                t.createTagPending(false);
                t.transition(ScriptDataEndTagName);
                return;
            }
            t.emit("</");
            t.transition(ScriptData);
        }
    },
    ScriptDataEndTagName {
        void read(Tokeniser t, CharacterReader r) {
            if (r.matchesLetter()) {
                String name = r.consumeLetterSequence();
                t.tagPending.appendTagName(name.toLowerCase());
                t.dataBuffer.append(name);
            } else if (!t.isAppropriateEndTagToken() || r.isEmpty()) {
                anythingElse(t, r);
            } else {
                char c = r.consume();
                switch (c) {
                    case Node.COMMENT /*9*/:
                    case Node.DOCDECL /*10*/:
                    case '\f':
                    case ' ':
                        t.transition(BeforeAttributeName);
                    case '/':
                        t.transition(SelfClosingStartTag);
                    case '>':
                        t.emitTagPending();
                        t.transition(Data);
                    default:
                        t.dataBuffer.append(c);
                        anythingElse(t, r);
                }
            }
        }

        private void anythingElse(Tokeniser t, CharacterReader r) {
            t.emit("</" + t.dataBuffer.toString());
            t.transition(ScriptData);
        }
    },
    ScriptDataEscapeStart {
        void read(Tokeniser t, CharacterReader r) {
            if (r.matches('-')) {
                t.emit('-');
                t.advanceTransition(ScriptDataEscapeStartDash);
                return;
            }
            t.transition(ScriptData);
        }
    },
    ScriptDataEscapeStartDash {
        void read(Tokeniser t, CharacterReader r) {
            if (r.matches('-')) {
                t.emit('-');
                t.advanceTransition(ScriptDataEscapedDashDash);
                return;
            }
            t.transition(ScriptData);
        }
    },
    ScriptDataEscaped {
        void read(Tokeniser t, CharacterReader r) {
            if (r.isEmpty()) {
                t.eofError(this);
                t.transition(Data);
                return;
            }
            switch (r.current()) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    r.advance();
                    t.emit((char) TokeniserState.replacementChar);
                case '-':
                    t.emit('-');
                    t.advanceTransition(ScriptDataEscapedDash);
                case '<':
                    t.advanceTransition(ScriptDataEscapedLessthanSign);
                default:
                    t.emit(r.consumeToAny('-', '<', TokeniserState.nullChar));
            }
        }
    },
    ScriptDataEscapedDash {
        void read(Tokeniser t, CharacterReader r) {
            if (r.isEmpty()) {
                t.eofError(this);
                t.transition(Data);
                return;
            }
            char c = r.consume();
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.emit((char) TokeniserState.replacementChar);
                    t.transition(ScriptDataEscaped);
                case '-':
                    t.emit(c);
                    t.transition(ScriptDataEscapedDashDash);
                case '<':
                    t.transition(ScriptDataEscapedLessthanSign);
                default:
                    t.emit(c);
                    t.transition(ScriptDataEscaped);
            }
        }
    },
    ScriptDataEscapedDashDash {
        void read(Tokeniser t, CharacterReader r) {
            if (r.isEmpty()) {
                t.eofError(this);
                t.transition(Data);
                return;
            }
            char c = r.consume();
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.emit((char) TokeniserState.replacementChar);
                    t.transition(ScriptDataEscaped);
                case '-':
                    t.emit(c);
                case '<':
                    t.transition(ScriptDataEscapedLessthanSign);
                case '>':
                    t.emit(c);
                    t.transition(ScriptData);
                default:
                    t.emit(c);
                    t.transition(ScriptDataEscaped);
            }
        }
    },
    ScriptDataEscapedLessthanSign {
        void read(Tokeniser t, CharacterReader r) {
            if (r.matchesLetter()) {
                t.createTempBuffer();
                t.dataBuffer.append(Character.toLowerCase(r.current()));
                t.emit("<" + r.current());
                t.advanceTransition(ScriptDataDoubleEscapeStart);
            } else if (r.matches('/')) {
                t.createTempBuffer();
                t.advanceTransition(ScriptDataEscapedEndTagOpen);
            } else {
                t.emit('<');
                t.transition(ScriptDataEscaped);
            }
        }
    },
    ScriptDataEscapedEndTagOpen {
        void read(Tokeniser t, CharacterReader r) {
            if (r.matchesLetter()) {
                t.createTagPending(false);
                t.tagPending.appendTagName(Character.toLowerCase(r.current()));
                t.dataBuffer.append(r.current());
                t.advanceTransition(ScriptDataEscapedEndTagName);
                return;
            }
            t.emit("</");
            t.transition(ScriptDataEscaped);
        }
    },
    ScriptDataEscapedEndTagName {
        void read(Tokeniser t, CharacterReader r) {
            if (r.matchesLetter()) {
                String name = r.consumeLetterSequence();
                t.tagPending.appendTagName(name.toLowerCase());
                t.dataBuffer.append(name);
                r.advance();
            } else if (!t.isAppropriateEndTagToken() || r.isEmpty()) {
                anythingElse(t, r);
            } else {
                char c = r.consume();
                switch (c) {
                    case Node.COMMENT /*9*/:
                    case Node.DOCDECL /*10*/:
                    case '\f':
                    case ' ':
                        t.transition(BeforeAttributeName);
                    case '/':
                        t.transition(SelfClosingStartTag);
                    case '>':
                        t.emitTagPending();
                        t.transition(Data);
                    default:
                        t.dataBuffer.append(c);
                        anythingElse(t, r);
                }
            }
        }

        private void anythingElse(Tokeniser t, CharacterReader r) {
            t.emit("</" + t.dataBuffer.toString());
            t.transition(ScriptDataEscaped);
        }
    },
    ScriptDataDoubleEscapeStart {
        void read(Tokeniser t, CharacterReader r) {
            if (r.matchesLetter()) {
                String name = r.consumeLetterSequence();
                t.dataBuffer.append(name.toLowerCase());
                t.emit(name);
                return;
            }
            char c = r.consume();
            switch (c) {
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                case '/':
                case '>':
                    if (t.dataBuffer.toString().equals("script")) {
                        t.transition(ScriptDataDoubleEscaped);
                    } else {
                        t.transition(ScriptDataEscaped);
                    }
                    t.emit(c);
                default:
                    r.unconsume();
                    t.transition(ScriptDataEscaped);
            }
        }
    },
    ScriptDataDoubleEscaped {
        void read(Tokeniser t, CharacterReader r) {
            char c = r.current();
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    r.advance();
                    t.emit((char) TokeniserState.replacementChar);
                case '-':
                    t.emit(c);
                    t.advanceTransition(ScriptDataDoubleEscapedDash);
                case '<':
                    t.emit(c);
                    t.advanceTransition(ScriptDataDoubleEscapedLessthanSign);
                case '\uffff':
                    t.eofError(this);
                    t.transition(Data);
                default:
                    t.emit(r.consumeToAny('-', '<', TokeniserState.nullChar));
            }
        }
    },
    ScriptDataDoubleEscapedDash {
        void read(Tokeniser t, CharacterReader r) {
            char c = r.consume();
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.emit((char) TokeniserState.replacementChar);
                    t.transition(ScriptDataDoubleEscaped);
                case '-':
                    t.emit(c);
                    t.transition(ScriptDataDoubleEscapedDashDash);
                case '<':
                    t.emit(c);
                    t.transition(ScriptDataDoubleEscapedLessthanSign);
                case '\uffff':
                    t.eofError(this);
                    t.transition(Data);
                default:
                    t.emit(c);
                    t.transition(ScriptDataDoubleEscaped);
            }
        }
    },
    ScriptDataDoubleEscapedDashDash {
        void read(Tokeniser t, CharacterReader r) {
            char c = r.consume();
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.emit((char) TokeniserState.replacementChar);
                    t.transition(ScriptDataDoubleEscaped);
                case '-':
                    t.emit(c);
                case '<':
                    t.emit(c);
                    t.transition(ScriptDataDoubleEscapedLessthanSign);
                case '>':
                    t.emit(c);
                    t.transition(ScriptData);
                case '\uffff':
                    t.eofError(this);
                    t.transition(Data);
                default:
                    t.emit(c);
                    t.transition(ScriptDataDoubleEscaped);
            }
        }
    },
    ScriptDataDoubleEscapedLessthanSign {
        void read(Tokeniser t, CharacterReader r) {
            if (r.matches('/')) {
                t.emit('/');
                t.createTempBuffer();
                t.advanceTransition(ScriptDataDoubleEscapeEnd);
                return;
            }
            t.transition(ScriptDataDoubleEscaped);
        }
    },
    ScriptDataDoubleEscapeEnd {
        void read(Tokeniser t, CharacterReader r) {
            if (r.matchesLetter()) {
                String name = r.consumeLetterSequence();
                t.dataBuffer.append(name.toLowerCase());
                t.emit(name);
                return;
            }
            char c = r.consume();
            switch (c) {
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                case '/':
                case '>':
                    if (t.dataBuffer.toString().equals("script")) {
                        t.transition(ScriptDataEscaped);
                    } else {
                        t.transition(ScriptDataDoubleEscaped);
                    }
                    t.emit(c);
                default:
                    r.unconsume();
                    t.transition(ScriptDataDoubleEscaped);
            }
        }
    },
    BeforeAttributeName {
        void read(Tokeniser t, CharacterReader r) {
            char c = r.consume();
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.tagPending.newAttribute();
                    r.unconsume();
                    t.transition(AttributeName);
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                case '\"':
                case '\'':
                case '<':
                case '=':
                    t.error((TokeniserState) this);
                    t.tagPending.newAttribute();
                    t.tagPending.appendAttributeName(c);
                    t.transition(AttributeName);
                case '/':
                    t.transition(SelfClosingStartTag);
                case '>':
                    t.emitTagPending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.transition(Data);
                default:
                    t.tagPending.newAttribute();
                    r.unconsume();
                    t.transition(AttributeName);
            }
        }
    },
    AttributeName {
        void read(Tokeniser t, CharacterReader r) {
            t.tagPending.appendAttributeName(r.consumeToAny('\t', '\n', '\f', ' ', '/', '=', '>', TokeniserState.nullChar, '\"', '\'', '<').toLowerCase());
            char c = r.consume();
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.tagPending.appendAttributeName((char) TokeniserState.replacementChar);
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                    t.transition(AfterAttributeName);
                case '\"':
                case '\'':
                case '<':
                    t.error((TokeniserState) this);
                    t.tagPending.appendAttributeName(c);
                case '/':
                    t.transition(SelfClosingStartTag);
                case '=':
                    t.transition(BeforeAttributeValue);
                case '>':
                    t.emitTagPending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.transition(Data);
                default:
            }
        }
    },
    AfterAttributeName {
        void read(Tokeniser t, CharacterReader r) {
            char c = r.consume();
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.tagPending.appendAttributeName((char) TokeniserState.replacementChar);
                    t.transition(AttributeName);
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                case '\"':
                case '\'':
                case '<':
                    t.error((TokeniserState) this);
                    t.tagPending.newAttribute();
                    t.tagPending.appendAttributeName(c);
                    t.transition(AttributeName);
                case '/':
                    t.transition(SelfClosingStartTag);
                case '=':
                    t.transition(BeforeAttributeValue);
                case '>':
                    t.emitTagPending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.transition(Data);
                default:
                    t.tagPending.newAttribute();
                    r.unconsume();
                    t.transition(AttributeName);
            }
        }
    },
    BeforeAttributeValue {
        void read(Tokeniser t, CharacterReader r) {
            char c = r.consume();
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.tagPending.appendAttributeValue((char) TokeniserState.replacementChar);
                    t.transition(AttributeValue_unquoted);
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                case '\"':
                    t.transition(AttributeValue_doubleQuoted);
                case '&':
                    r.unconsume();
                    t.transition(AttributeValue_unquoted);
                case '\'':
                    t.transition(AttributeValue_singleQuoted);
                case '<':
                case '=':
                case '`':
                    t.error((TokeniserState) this);
                    t.tagPending.appendAttributeValue(c);
                    t.transition(AttributeValue_unquoted);
                case '>':
                    t.error((TokeniserState) this);
                    t.emitTagPending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.transition(Data);
                default:
                    r.unconsume();
                    t.transition(AttributeValue_unquoted);
            }
        }
    },
    AttributeValue_doubleQuoted {
        void read(Tokeniser t, CharacterReader r) {
            String value = r.consumeToAny('\"', '&', TokeniserState.nullChar);
            if (value.length() > 0) {
                t.tagPending.appendAttributeValue(value);
            }
            switch (r.consume()) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.tagPending.appendAttributeValue((char) TokeniserState.replacementChar);
                case '\"':
                    t.transition(AfterAttributeValue_quoted);
                case '&':
                    Character ref = t.consumeCharacterReference(Character.valueOf('\"'), true);
                    if (ref != null) {
                        t.tagPending.appendAttributeValue(ref.charValue());
                    } else {
                        t.tagPending.appendAttributeValue('&');
                    }
                case '\uffff':
                    t.eofError(this);
                    t.transition(Data);
                default:
            }
        }
    },
    AttributeValue_singleQuoted {
        void read(Tokeniser t, CharacterReader r) {
            String value = r.consumeToAny('\'', '&', TokeniserState.nullChar);
            if (value.length() > 0) {
                t.tagPending.appendAttributeValue(value);
            }
            switch (r.consume()) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.tagPending.appendAttributeValue((char) TokeniserState.replacementChar);
                case '&':
                    Character ref = t.consumeCharacterReference(Character.valueOf('\''), true);
                    if (ref != null) {
                        t.tagPending.appendAttributeValue(ref.charValue());
                    } else {
                        t.tagPending.appendAttributeValue('&');
                    }
                case '\'':
                    t.transition(AfterAttributeValue_quoted);
                case '\uffff':
                    t.eofError(this);
                    t.transition(Data);
                default:
            }
        }
    },
    AttributeValue_unquoted {
        void read(Tokeniser t, CharacterReader r) {
            String value = r.consumeToAny('\t', '\n', '\f', ' ', '&', '>', TokeniserState.nullChar, '\"', '\'', '<', '=', '`');
            if (value.length() > 0) {
                t.tagPending.appendAttributeValue(value);
            }
            char c = r.consume();
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.tagPending.appendAttributeValue((char) TokeniserState.replacementChar);
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                    t.transition(BeforeAttributeName);
                case '\"':
                case '\'':
                case '<':
                case '=':
                case '`':
                    t.error((TokeniserState) this);
                    t.tagPending.appendAttributeValue(c);
                case '&':
                    Character ref = t.consumeCharacterReference(Character.valueOf('>'), true);
                    if (ref != null) {
                        t.tagPending.appendAttributeValue(ref.charValue());
                    } else {
                        t.tagPending.appendAttributeValue('&');
                    }
                case '>':
                    t.emitTagPending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.transition(Data);
                default:
            }
        }
    },
    AfterAttributeValue_quoted {
        void read(Tokeniser t, CharacterReader r) {
            switch (r.consume()) {
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                    t.transition(BeforeAttributeName);
                case '/':
                    t.transition(SelfClosingStartTag);
                case '>':
                    t.emitTagPending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.transition(Data);
                default:
                    t.error((TokeniserState) this);
                    r.unconsume();
                    t.transition(BeforeAttributeName);
            }
        }
    },
    SelfClosingStartTag {
        void read(Tokeniser t, CharacterReader r) {
            switch (r.consume()) {
                case '>':
                    t.tagPending.selfClosing = true;
                    t.emitTagPending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.transition(Data);
                default:
                    t.error((TokeniserState) this);
                    t.transition(BeforeAttributeName);
            }
        }
    },
    BogusComment {
        void read(Tokeniser t, CharacterReader r) {
            r.unconsume();
            Token comment = new Comment();
            comment.data.append(r.consumeTo('>'));
            t.emit(comment);
            t.advanceTransition(Data);
        }
    },
    MarkupDeclarationOpen {
        void read(Tokeniser t, CharacterReader r) {
            if (r.matchConsume("--")) {
                t.createCommentPending();
                t.transition(CommentStart);
            } else if (r.matchConsumeIgnoreCase("DOCTYPE")) {
                t.transition(Doctype);
            } else if (r.matchConsume("[CDATA[")) {
                t.transition(CdataSection);
            } else {
                t.error((TokeniserState) this);
                t.advanceTransition(BogusComment);
            }
        }
    },
    CommentStart {
        void read(Tokeniser t, CharacterReader r) {
            char c = r.consume();
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.commentPending.data.append(TokeniserState.replacementChar);
                    t.transition(Comment);
                case '-':
                    t.transition(CommentStartDash);
                case '>':
                    t.error((TokeniserState) this);
                    t.emitCommentPending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.emitCommentPending();
                    t.transition(Data);
                default:
                    t.commentPending.data.append(c);
                    t.transition(Comment);
            }
        }
    },
    CommentStartDash {
        void read(Tokeniser t, CharacterReader r) {
            char c = r.consume();
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.commentPending.data.append(TokeniserState.replacementChar);
                    t.transition(Comment);
                case '-':
                    t.transition(CommentStartDash);
                case '>':
                    t.error((TokeniserState) this);
                    t.emitCommentPending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.emitCommentPending();
                    t.transition(Data);
                default:
                    t.commentPending.data.append(c);
                    t.transition(Comment);
            }
        }
    },
    Comment {
        void read(Tokeniser t, CharacterReader r) {
            switch (r.current()) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.commentPending.data.append(TokeniserState.replacementChar);
                case '-':
                    t.advanceTransition(CommentEndDash);
                case '\uffff':
                    t.eofError(this);
                    t.emitCommentPending();
                    t.transition(Data);
                default:
                    t.commentPending.data.append(r.consumeToAny('-', TokeniserState.nullChar));
            }
        }
    },
    CommentEndDash {
        void read(Tokeniser t, CharacterReader r) {
            char c = r.consume();
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.commentPending.data.append('-').append(TokeniserState.replacementChar);
                    t.transition(Comment);
                case '-':
                    t.transition(CommentEnd);
                case '\uffff':
                    t.eofError(this);
                    t.emitCommentPending();
                    t.transition(Data);
                default:
                    t.commentPending.data.append('-').append(c);
                    t.transition(Comment);
            }
        }
    },
    CommentEnd {
        void read(Tokeniser t, CharacterReader r) {
            String str = "--";
            char c = r.consume();
            String str2;
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    str2 = "--";
                    t.commentPending.data.append(str).append(TokeniserState.replacementChar);
                    t.transition(Comment);
                case '!':
                    t.error((TokeniserState) this);
                    t.transition(CommentEndBang);
                case '-':
                    t.error((TokeniserState) this);
                    t.commentPending.data.append('-');
                case '>':
                    t.emitCommentPending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.emitCommentPending();
                    t.transition(Data);
                default:
                    t.error((TokeniserState) this);
                    str2 = "--";
                    t.commentPending.data.append(str).append(c);
                    t.transition(Comment);
            }
        }
    },
    CommentEndBang {
        void read(Tokeniser t, CharacterReader r) {
            String str = "--!";
            char c = r.consume();
            String str2;
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    str2 = "--!";
                    t.commentPending.data.append(str).append(TokeniserState.replacementChar);
                    t.transition(Comment);
                case '-':
                    str2 = "--!";
                    t.commentPending.data.append(str);
                    t.transition(CommentEndDash);
                case '>':
                    t.emitCommentPending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.emitCommentPending();
                    t.transition(Data);
                default:
                    str2 = "--!";
                    t.commentPending.data.append(str).append(c);
                    t.transition(Comment);
            }
        }
    },
    Doctype {
        void read(Tokeniser t, CharacterReader r) {
            switch (r.consume()) {
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                    t.transition(BeforeDoctypeName);
                case '\uffff':
                    t.eofError(this);
                    t.createDoctypePending();
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                default:
                    t.error((TokeniserState) this);
                    t.transition(BeforeDoctypeName);
            }
        }
    },
    BeforeDoctypeName {
        void read(Tokeniser t, CharacterReader r) {
            if (r.matchesLetter()) {
                t.createDoctypePending();
                t.transition(DoctypeName);
                return;
            }
            char c = r.consume();
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.doctypePending.name.append(TokeniserState.replacementChar);
                    t.transition(DoctypeName);
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                case '\uffff':
                    t.eofError(this);
                    t.createDoctypePending();
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                default:
                    t.createDoctypePending();
                    t.doctypePending.name.append(c);
                    t.transition(DoctypeName);
            }
        }
    },
    DoctypeName {
        void read(Tokeniser t, CharacterReader r) {
            if (r.matchesLetter()) {
                t.doctypePending.name.append(r.consumeLetterSequence().toLowerCase());
                return;
            }
            char c = r.consume();
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.doctypePending.name.append(TokeniserState.replacementChar);
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                    t.transition(AfterDoctypeName);
                case '>':
                    t.emitDoctypePending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                default:
                    t.doctypePending.name.append(c);
            }
        }
    },
    AfterDoctypeName {
        void read(Tokeniser t, CharacterReader r) {
            if (r.isEmpty()) {
                t.eofError(this);
                t.doctypePending.forceQuirks = true;
                t.emitDoctypePending();
                t.transition(Data);
            } else if (r.matches('>')) {
                t.emitDoctypePending();
                t.advanceTransition(Data);
            } else if (r.matchConsumeIgnoreCase("PUBLIC")) {
                t.transition(AfterDoctypePublicKeyword);
            } else if (r.matchConsumeIgnoreCase("SYSTEM")) {
                t.transition(AfterDoctypeSystemKeyword);
            } else {
                t.error((TokeniserState) this);
                t.doctypePending.forceQuirks = true;
                t.advanceTransition(BogusDoctype);
            }
        }
    },
    AfterDoctypePublicKeyword {
        void read(Tokeniser t, CharacterReader r) {
            switch (r.consume()) {
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                    t.transition(BeforeDoctypePublicIdentifier);
                case '\"':
                    t.error((TokeniserState) this);
                    t.transition(DoctypePublicIdentifier_doubleQuoted);
                case '\'':
                    t.error((TokeniserState) this);
                    t.transition(DoctypePublicIdentifier_singleQuoted);
                case '>':
                    t.error((TokeniserState) this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                default:
                    t.error((TokeniserState) this);
                    t.doctypePending.forceQuirks = true;
                    t.transition(BogusDoctype);
            }
        }
    },
    BeforeDoctypePublicIdentifier {
        void read(Tokeniser t, CharacterReader r) {
            switch (r.consume()) {
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                case '\"':
                    t.transition(DoctypePublicIdentifier_doubleQuoted);
                case '\'':
                    t.transition(DoctypePublicIdentifier_singleQuoted);
                case '>':
                    t.error((TokeniserState) this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                default:
                    t.error((TokeniserState) this);
                    t.doctypePending.forceQuirks = true;
                    t.transition(BogusDoctype);
            }
        }
    },
    DoctypePublicIdentifier_doubleQuoted {
        void read(Tokeniser t, CharacterReader r) {
            char c = r.consume();
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.doctypePending.publicIdentifier.append(TokeniserState.replacementChar);
                case '\"':
                    t.transition(AfterDoctypePublicIdentifier);
                case '>':
                    t.error((TokeniserState) this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                default:
                    t.doctypePending.publicIdentifier.append(c);
            }
        }
    },
    DoctypePublicIdentifier_singleQuoted {
        void read(Tokeniser t, CharacterReader r) {
            char c = r.consume();
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.doctypePending.publicIdentifier.append(TokeniserState.replacementChar);
                case '\'':
                    t.transition(AfterDoctypePublicIdentifier);
                case '>':
                    t.error((TokeniserState) this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                default:
                    t.doctypePending.publicIdentifier.append(c);
            }
        }
    },
    AfterDoctypePublicIdentifier {
        void read(Tokeniser t, CharacterReader r) {
            switch (r.consume()) {
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                    t.transition(BetweenDoctypePublicAndSystemIdentifiers);
                case '\"':
                    t.error((TokeniserState) this);
                    t.transition(DoctypeSystemIdentifier_doubleQuoted);
                case '\'':
                    t.error((TokeniserState) this);
                    t.transition(DoctypeSystemIdentifier_singleQuoted);
                case '>':
                    t.emitDoctypePending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                default:
                    t.error((TokeniserState) this);
                    t.doctypePending.forceQuirks = true;
                    t.transition(BogusDoctype);
            }
        }
    },
    BetweenDoctypePublicAndSystemIdentifiers {
        void read(Tokeniser t, CharacterReader r) {
            switch (r.consume()) {
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                case '\"':
                    t.error((TokeniserState) this);
                    t.transition(DoctypeSystemIdentifier_doubleQuoted);
                case '\'':
                    t.error((TokeniserState) this);
                    t.transition(DoctypeSystemIdentifier_singleQuoted);
                case '>':
                    t.emitDoctypePending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                default:
                    t.error((TokeniserState) this);
                    t.doctypePending.forceQuirks = true;
                    t.transition(BogusDoctype);
            }
        }
    },
    AfterDoctypeSystemKeyword {
        void read(Tokeniser t, CharacterReader r) {
            switch (r.consume()) {
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                    t.transition(BeforeDoctypeSystemIdentifier);
                case '\"':
                    t.error((TokeniserState) this);
                    t.transition(DoctypeSystemIdentifier_doubleQuoted);
                case '\'':
                    t.error((TokeniserState) this);
                    t.transition(DoctypeSystemIdentifier_singleQuoted);
                case '>':
                    t.error((TokeniserState) this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                default:
                    t.error((TokeniserState) this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
            }
        }
    },
    BeforeDoctypeSystemIdentifier {
        void read(Tokeniser t, CharacterReader r) {
            switch (r.consume()) {
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                case '\"':
                    t.transition(DoctypeSystemIdentifier_doubleQuoted);
                case '\'':
                    t.transition(DoctypeSystemIdentifier_singleQuoted);
                case '>':
                    t.error((TokeniserState) this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                default:
                    t.error((TokeniserState) this);
                    t.doctypePending.forceQuirks = true;
                    t.transition(BogusDoctype);
            }
        }
    },
    DoctypeSystemIdentifier_doubleQuoted {
        void read(Tokeniser t, CharacterReader r) {
            char c = r.consume();
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.doctypePending.systemIdentifier.append(TokeniserState.replacementChar);
                case '\"':
                    t.transition(AfterDoctypeSystemIdentifier);
                case '>':
                    t.error((TokeniserState) this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                default:
                    t.doctypePending.systemIdentifier.append(c);
            }
        }
    },
    DoctypeSystemIdentifier_singleQuoted {
        void read(Tokeniser t, CharacterReader r) {
            char c = r.consume();
            switch (c) {
                case Node.DOCUMENT /*0*/:
                    t.error((TokeniserState) this);
                    t.doctypePending.systemIdentifier.append(TokeniserState.replacementChar);
                case '\'':
                    t.transition(AfterDoctypeSystemIdentifier);
                case '>':
                    t.error((TokeniserState) this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                default:
                    t.doctypePending.systemIdentifier.append(c);
            }
        }
    },
    AfterDoctypeSystemIdentifier {
        void read(Tokeniser t, CharacterReader r) {
            switch (r.consume()) {
                case Node.COMMENT /*9*/:
                case Node.DOCDECL /*10*/:
                case '\f':
                case ' ':
                case '>':
                    t.emitDoctypePending();
                    t.transition(Data);
                case '\uffff':
                    t.eofError(this);
                    t.doctypePending.forceQuirks = true;
                    t.emitDoctypePending();
                    t.transition(Data);
                default:
                    t.error((TokeniserState) this);
                    t.transition(BogusDoctype);
            }
        }
    },
    BogusDoctype {
        void read(Tokeniser t, CharacterReader r) {
            switch (r.consume()) {
                case '>':
                    t.emitDoctypePending();
                    t.transition(Data);
                case '\uffff':
                    t.emitDoctypePending();
                    t.transition(Data);
                default:
            }
        }
    },
    CdataSection {
        void read(Tokeniser t, CharacterReader r) {
            String str = "]]>";
            String str2 = "]]>";
            t.emit(r.consumeTo(str));
            str2 = "]]>";
            r.matchConsume(str);
            t.transition(Data);
        }
    };
    
    private static final char eof = '\uffff';
    private static final char nullChar = '\u0000';
    private static final char replacementChar = '\ufffd';
    private static final String replacementStr;

    abstract void read(Tokeniser tokeniser, CharacterReader characterReader);

    static {
        replacementStr = String.valueOf(replacementChar);
    }
}
