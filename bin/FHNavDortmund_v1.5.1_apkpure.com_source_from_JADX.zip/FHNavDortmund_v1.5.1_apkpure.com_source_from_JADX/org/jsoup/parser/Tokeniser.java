package org.jsoup.parser;

import java.util.ArrayList;
import java.util.List;
import org.jsoup.helper.Validate;
import org.jsoup.nodes.Entities;

class Tokeniser {
    static final char replacementChar = '\ufffd';
    private StringBuilder charBuffer;
    Comment commentPending;
    StringBuilder dataBuffer;
    Doctype doctypePending;
    private Token emitPending;
    private List<ParseError> errors;
    private boolean isEmitPending;
    private StartTag lastStartTag;
    private CharacterReader reader;
    private boolean selfClosingFlagAcknowledged;
    private TokeniserState state;
    Tag tagPending;
    private boolean trackErrors;

    Tokeniser(CharacterReader reader) {
        this.trackErrors = true;
        this.errors = new ArrayList();
        this.state = TokeniserState.Data;
        this.isEmitPending = false;
        this.charBuffer = new StringBuilder();
        this.selfClosingFlagAcknowledged = true;
        this.reader = reader;
    }

    Token read() {
        if (!this.selfClosingFlagAcknowledged) {
            error("Self closing flag not acknowledged");
            this.selfClosingFlagAcknowledged = true;
        }
        while (!this.isEmitPending) {
            this.state.read(this, this.reader);
        }
        if (this.charBuffer.length() > 0) {
            String str = this.charBuffer.toString();
            this.charBuffer.delete(0, this.charBuffer.length());
            return new Character(str);
        }
        this.isEmitPending = false;
        return this.emitPending;
    }

    void emit(Token token) {
        Validate.isFalse(this.isEmitPending, "There is an unread token pending!");
        this.emitPending = token;
        this.isEmitPending = true;
        if (token.type == TokenType.StartTag) {
            StartTag startTag = (StartTag) token;
            this.lastStartTag = startTag;
            if (startTag.selfClosing) {
                this.selfClosingFlagAcknowledged = false;
            }
        } else if (token.type == TokenType.EndTag) {
            if (((EndTag) token).attributes.size() > 0) {
                error("Attributes incorrectly present on end tag");
            }
        }
    }

    void emit(String str) {
        this.charBuffer.append(str);
    }

    void emit(char c) {
        this.charBuffer.append(c);
    }

    TokeniserState getState() {
        return this.state;
    }

    void transition(TokeniserState state) {
        this.state = state;
    }

    void advanceTransition(TokeniserState state) {
        this.reader.advance();
        this.state = state;
    }

    void acknowledgeSelfClosingFlag() {
        this.selfClosingFlagAcknowledged = true;
    }

    Character consumeCharacterReference(Character additionalAllowedCharacter, boolean inAttribute) {
        String str = ";";
        if (this.reader.isEmpty()) {
            return null;
        }
        if (additionalAllowedCharacter != null && additionalAllowedCharacter.charValue() == this.reader.current()) {
            return null;
        }
        if (this.reader.matchesAny('\t', '\n', '\f', '<', '&')) {
            return null;
        }
        this.reader.mark();
        if (this.reader.matchConsume("#")) {
            boolean isHexMode = this.reader.matchConsumeIgnoreCase("X");
            String numRef = isHexMode ? this.reader.consumeHexSequence() : this.reader.consumeDigitSequence();
            if (numRef.length() == 0) {
                characterReferenceError();
                this.reader.rewindToMark();
                return null;
            }
            String str2 = ";";
            if (!this.reader.matchConsume(str)) {
                characterReferenceError();
            }
            int charval = -1;
            try {
                charval = Integer.valueOf(numRef, isHexMode ? 16 : 10).intValue();
            } catch (NumberFormatException e) {
            }
            if (charval != -1 && ((charval < 55296 || charval > 57343) && charval <= 1114111)) {
                return Character.valueOf((char) charval);
            }
            characterReferenceError();
            return Character.valueOf(replacementChar);
        }
        String nameRef = this.reader.consumeLetterSequence();
        boolean looksLegit = this.reader.matches(';');
        boolean found = false;
        while (nameRef.length() > 0 && !found) {
            if (Entities.isNamedEntity(nameRef)) {
                found = true;
            } else {
                nameRef = nameRef.substring(0, nameRef.length() - 1);
                this.reader.unconsume();
            }
        }
        if (!found) {
            if (looksLegit) {
                characterReferenceError();
            }
            this.reader.rewindToMark();
            return null;
        } else if (inAttribute && (this.reader.matchesLetter() || this.reader.matchesDigit() || this.reader.matches('='))) {
            this.reader.rewindToMark();
            return null;
        } else {
            str2 = ";";
            if (!this.reader.matchConsume(str)) {
                characterReferenceError();
            }
            return Entities.getCharacterByName(nameRef);
        }
    }

    Tag createTagPending(boolean start) {
        this.tagPending = start ? new StartTag() : new EndTag();
        return this.tagPending;
    }

    void emitTagPending() {
        this.tagPending.finaliseTag();
        emit(this.tagPending);
    }

    void createCommentPending() {
        this.commentPending = new Comment();
    }

    void emitCommentPending() {
        emit(this.commentPending);
    }

    void createDoctypePending() {
        this.doctypePending = new Doctype();
    }

    void emitDoctypePending() {
        emit(this.doctypePending);
    }

    void createTempBuffer() {
        this.dataBuffer = new StringBuilder();
    }

    boolean isAppropriateEndTagToken() {
        return this.tagPending.tagName.equals(this.lastStartTag.tagName);
    }

    String appropriateEndTagName() {
        return this.lastStartTag.tagName;
    }

    boolean isTrackErrors() {
        return this.trackErrors;
    }

    void setTrackErrors(boolean trackErrors) {
        this.trackErrors = trackErrors;
    }

    void error(TokeniserState state) {
        if (this.trackErrors) {
            this.errors.add(new ParseError("Unexpected character in input", this.reader.current(), state, this.reader.pos()));
        }
    }

    void eofError(TokeniserState state) {
        if (this.trackErrors) {
            this.errors.add(new ParseError("Unexpectedly reached end of file (EOF)", state, this.reader.pos()));
        }
    }

    private void characterReferenceError() {
        if (this.trackErrors) {
            this.errors.add(new ParseError("Invalid character reference", this.reader.pos()));
        }
    }

    private void error(String errorMsg) {
        if (this.trackErrors) {
            this.errors.add(new ParseError(errorMsg, this.reader.pos()));
        }
    }

    boolean currentNodeInHtmlNS() {
        return true;
    }
}
