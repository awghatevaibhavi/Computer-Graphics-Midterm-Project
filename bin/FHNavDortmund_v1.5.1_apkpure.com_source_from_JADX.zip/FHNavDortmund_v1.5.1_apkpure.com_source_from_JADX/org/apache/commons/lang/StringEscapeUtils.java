package org.apache.commons.lang;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Locale;
import org.apache.commons.lang.exception.NestableRuntimeException;
import org.apache.commons.lang.text.StrBuilder;
import org.ksoap2.SoapEnvelope;
import org.kxml2.kdom.Node;

public class StringEscapeUtils {
    private static final char CSV_DELIMITER = ',';
    private static final char CSV_QUOTE = '\"';
    private static final String CSV_QUOTE_STR;
    private static final char[] CSV_SEARCH_CHARS;

    static {
        CSV_QUOTE_STR = String.valueOf(CSV_QUOTE);
        CSV_SEARCH_CHARS = new char[]{CSV_DELIMITER, CSV_QUOTE, CharUtils.CR, '\n'};
    }

    public static String escapeJava(String str) {
        return escapeJavaStyleString(str, false, false);
    }

    public static void escapeJava(Writer out, String str) throws IOException {
        escapeJavaStyleString(out, str, false, false);
    }

    public static String escapeJavaScript(String str) {
        return escapeJavaStyleString(str, true, true);
    }

    public static void escapeJavaScript(Writer out, String str) throws IOException {
        escapeJavaStyleString(out, str, true, true);
    }

    private static String escapeJavaStyleString(String str, boolean escapeSingleQuotes, boolean escapeForwardSlash) {
        if (str == null) {
            return null;
        }
        try {
            StringWriter writer = new StringWriter(str.length() * 2);
            escapeJavaStyleString(writer, str, escapeSingleQuotes, escapeForwardSlash);
            return writer.toString();
        } catch (IOException e) {
            throw new UnhandledException(e);
        }
    }

    private static void escapeJavaStyleString(Writer out, String str, boolean escapeSingleQuote, boolean escapeForwardSlash) throws IOException {
        String str2 = "\\u00";
        if (out == null) {
            throw new IllegalArgumentException("The Writer must not be null");
        } else if (str != null) {
            int sz = str.length();
            for (int i = 0; i < sz; i++) {
                char ch = str.charAt(i);
                if (ch <= '\u0fff') {
                    if (ch <= '\u00ff') {
                        String str3;
                        if (ch <= '\u007f') {
                            if (ch >= ' ') {
                                switch (ch) {
                                    case '\"':
                                        out.write(92);
                                        out.write(34);
                                        break;
                                    case '\'':
                                        if (escapeSingleQuote) {
                                            out.write(92);
                                        }
                                        out.write(39);
                                        break;
                                    case '/':
                                        if (escapeForwardSlash) {
                                            out.write(92);
                                        }
                                        out.write(47);
                                        break;
                                    case '\\':
                                        out.write(92);
                                        out.write(92);
                                        break;
                                    default:
                                        out.write(ch);
                                        break;
                                }
                            }
                            switch (ch) {
                                case Node.PROCESSING_INSTRUCTION /*8*/:
                                    out.write(92);
                                    out.write(98);
                                    break;
                                case Node.COMMENT /*9*/:
                                    out.write(92);
                                    out.write(116);
                                    break;
                                case Node.DOCDECL /*10*/:
                                    out.write(92);
                                    out.write(SoapEnvelope.VER11);
                                    break;
                                case '\f':
                                    out.write(92);
                                    out.write(102);
                                    break;
                                case '\r':
                                    out.write(92);
                                    out.write(114);
                                    break;
                                default:
                                    if (ch <= '\u000f') {
                                        out.write(new StringBuffer().append("\\u000").append(hex(ch)).toString());
                                        break;
                                    }
                                    str3 = "\\u00";
                                    out.write(new StringBuffer().append(str2).append(hex(ch)).toString());
                                    break;
                            }
                        }
                        str3 = "\\u00";
                        out.write(new StringBuffer().append(str2).append(hex(ch)).toString());
                    } else {
                        out.write(new StringBuffer().append("\\u0").append(hex(ch)).toString());
                    }
                } else {
                    out.write(new StringBuffer().append("\\u").append(hex(ch)).toString());
                }
            }
        }
    }

    private static String hex(char ch) {
        return Integer.toHexString(ch).toUpperCase(Locale.ENGLISH);
    }

    public static String unescapeJava(String str) {
        if (str == null) {
            return null;
        }
        try {
            StringWriter writer = new StringWriter(str.length());
            unescapeJava(writer, str);
            return writer.toString();
        } catch (IOException e) {
            throw new UnhandledException(e);
        }
    }

    public static void unescapeJava(Writer out, String str) throws IOException {
        if (out == null) {
            throw new IllegalArgumentException("The Writer must not be null");
        } else if (str != null) {
            int sz = str.length();
            StrBuilder unicode = new StrBuilder(4);
            boolean hadSlash = false;
            boolean inUnicode = false;
            for (int i = 0; i < sz; i++) {
                char ch = str.charAt(i);
                if (inUnicode) {
                    unicode.append(ch);
                    if (unicode.length() == 4) {
                        try {
                            out.write((char) Integer.parseInt(unicode.toString(), 16));
                            unicode.setLength(0);
                            inUnicode = false;
                            hadSlash = false;
                        } catch (NumberFormatException e) {
                            throw new NestableRuntimeException(new StringBuffer().append("Unable to parse unicode value: ").append(unicode).toString(), e);
                        }
                    }
                    continue;
                } else if (hadSlash) {
                    hadSlash = false;
                    switch (ch) {
                        case '\"':
                            out.write(34);
                            break;
                        case '\'':
                            out.write(39);
                            break;
                        case '\\':
                            out.write(92);
                            break;
                        case 'b':
                            out.write(8);
                            break;
                        case 'f':
                            out.write(12);
                            break;
                        case SoapEnvelope.VER11 /*110*/:
                            out.write(10);
                            break;
                        case 'r':
                            out.write(13);
                            break;
                        case 't':
                            out.write(9);
                            break;
                        case 'u':
                            inUnicode = true;
                            break;
                        default:
                            out.write(ch);
                            break;
                    }
                } else if (ch == '\\') {
                    hadSlash = true;
                } else {
                    out.write(ch);
                }
            }
            if (hadSlash) {
                out.write(92);
            }
        }
    }

    public static String unescapeJavaScript(String str) {
        return unescapeJava(str);
    }

    public static void unescapeJavaScript(Writer out, String str) throws IOException {
        unescapeJava(out, str);
    }

    public static String escapeHtml(String str) {
        if (str == null) {
            return null;
        }
        try {
            StringWriter writer = new StringWriter((int) (((double) str.length()) * 1.5d));
            escapeHtml(writer, str);
            return writer.toString();
        } catch (IOException e) {
            throw new UnhandledException(e);
        }
    }

    public static void escapeHtml(Writer writer, String string) throws IOException {
        if (writer == null) {
            throw new IllegalArgumentException("The Writer must not be null.");
        } else if (string != null) {
            Entities.HTML40.escape(writer, string);
        }
    }

    public static String unescapeHtml(String str) {
        if (str == null) {
            return null;
        }
        try {
            StringWriter writer = new StringWriter((int) (((double) str.length()) * 1.5d));
            unescapeHtml(writer, str);
            return writer.toString();
        } catch (IOException e) {
            throw new UnhandledException(e);
        }
    }

    public static void unescapeHtml(Writer writer, String string) throws IOException {
        if (writer == null) {
            throw new IllegalArgumentException("The Writer must not be null.");
        } else if (string != null) {
            Entities.HTML40.unescape(writer, string);
        }
    }

    public static void escapeXml(Writer writer, String str) throws IOException {
        if (writer == null) {
            throw new IllegalArgumentException("The Writer must not be null.");
        } else if (str != null) {
            Entities.XML.escape(writer, str);
        }
    }

    public static String escapeXml(String str) {
        if (str == null) {
            return null;
        }
        return Entities.XML.escape(str);
    }

    public static void unescapeXml(Writer writer, String str) throws IOException {
        if (writer == null) {
            throw new IllegalArgumentException("The Writer must not be null.");
        } else if (str != null) {
            Entities.XML.unescape(writer, str);
        }
    }

    public static String unescapeXml(String str) {
        if (str == null) {
            return null;
        }
        return Entities.XML.unescape(str);
    }

    public static String escapeSql(String str) {
        if (str == null) {
            return null;
        }
        return StringUtils.replace(str, "'", "''");
    }

    public static String escapeCsv(String str) {
        if (StringUtils.containsNone(str, CSV_SEARCH_CHARS)) {
            return str;
        }
        try {
            StringWriter writer = new StringWriter();
            escapeCsv(writer, str);
            return writer.toString();
        } catch (IOException e) {
            throw new UnhandledException(e);
        }
    }

    public static void escapeCsv(Writer out, String str) throws IOException {
        if (!StringUtils.containsNone(str, CSV_SEARCH_CHARS)) {
            out.write(34);
            for (int i = 0; i < str.length(); i++) {
                char c = str.charAt(i);
                if (c == CSV_QUOTE) {
                    out.write(34);
                }
                out.write(c);
            }
            out.write(34);
        } else if (str != null) {
            out.write(str);
        }
    }

    public static String unescapeCsv(String str) {
        if (str == null) {
            return null;
        }
        try {
            StringWriter writer = new StringWriter();
            unescapeCsv(writer, str);
            return writer.toString();
        } catch (IOException e) {
            throw new UnhandledException(e);
        }
    }

    public static void unescapeCsv(Writer out, String str) throws IOException {
        if (str != null) {
            if (str.length() < 2) {
                out.write(str);
            } else if (str.charAt(0) == CSV_QUOTE && str.charAt(str.length() - 1) == CSV_QUOTE) {
                String quoteless = str.substring(1, str.length() - 1);
                if (StringUtils.containsAny(quoteless, CSV_SEARCH_CHARS)) {
                    str = StringUtils.replace(quoteless, new StringBuffer().append(CSV_QUOTE_STR).append(CSV_QUOTE_STR).toString(), CSV_QUOTE_STR);
                }
                out.write(str);
            } else {
                out.write(str);
            }
        }
    }
}
