package org.apache.commons.lang;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;

public class SerializationUtils {
    public static Object clone(Serializable object) {
        return deserialize(serialize(object));
    }

    public static void serialize(Serializable obj, OutputStream outputStream) {
        Throwable ex;
        Throwable e;
        if (outputStream == null) {
            throw new IllegalArgumentException("The OutputStream must not be null");
        }
        ObjectOutputStream out = null;
        try {
            ObjectOutputStream out2 = new ObjectOutputStream(outputStream);
            try {
                out2.writeObject(obj);
                if (out2 != null) {
                    try {
                        out2.close();
                    } catch (IOException e2) {
                    }
                }
            } catch (Throwable e3) {
                ex = e3;
                out = out2;
                try {
                    throw new SerializationException(ex);
                } catch (Throwable th) {
                    e3 = th;
                    if (out != null) {
                        try {
                            out.close();
                        } catch (IOException e4) {
                        }
                    }
                    throw e3;
                }
            } catch (Throwable th2) {
                e3 = th2;
                out = out2;
                if (out != null) {
                    out.close();
                }
                throw e3;
            }
        } catch (Throwable e32) {
            ex = e32;
            throw new SerializationException(ex);
        }
    }

    public static byte[] serialize(Serializable obj) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream(512);
        serialize(obj, baos);
        return baos.toByteArray();
    }

    public static Object deserialize(InputStream inputStream) {
        Throwable ex;
        Throwable e;
        if (inputStream == null) {
            throw new IllegalArgumentException("The InputStream must not be null");
        }
        ObjectInputStream objectInputStream = null;
        try {
            ObjectInputStream in = new ObjectInputStream(inputStream);
            try {
                Object readObject = in.readObject();
                if (in != null) {
                    try {
                        in.close();
                    } catch (IOException e2) {
                    }
                }
                return readObject;
            } catch (Throwable e3) {
                ex = e3;
                objectInputStream = in;
                try {
                    throw new SerializationException(ex);
                } catch (Throwable th) {
                    e3 = th;
                    if (objectInputStream != null) {
                        try {
                            objectInputStream.close();
                        } catch (IOException e4) {
                        }
                    }
                    throw e3;
                }
            } catch (Throwable e32) {
                ex = e32;
                objectInputStream = in;
                throw new SerializationException(ex);
            } catch (Throwable th2) {
                e32 = th2;
                objectInputStream = in;
                if (objectInputStream != null) {
                    objectInputStream.close();
                }
                throw e32;
            }
        } catch (Throwable e322) {
            ex = e322;
            throw new SerializationException(ex);
        } catch (Throwable e3222) {
            ex = e3222;
            throw new SerializationException(ex);
        }
    }

    public static Object deserialize(byte[] objectData) {
        if (objectData != null) {
            return deserialize(new ByteArrayInputStream(objectData));
        }
        throw new IllegalArgumentException("The byte[] must not be null");
    }
}
