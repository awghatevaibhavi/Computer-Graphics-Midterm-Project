package org.apache.commons.lang;

import com.flurry.android.CallbackEvent;
import java.math.BigDecimal;
import java.math.BigInteger;
import org.ksoap2.SoapEnvelope;
import org.kxml2.wap.Wbxml;

public final class NumberUtils {
    public static int stringToInt(String str) {
        return stringToInt(str, 0);
    }

    public static int stringToInt(String str, int defaultValue) {
        try {
            return Integer.parseInt(str);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    public static Number createNumber(String val) throws NumberFormatException {
        if (val == null) {
            return null;
        }
        if (val.length() == 0) {
            throw new NumberFormatException("\"\" is not a valid number.");
        } else if (val.length() == 1 && !Character.isDigit(val.charAt(0))) {
            throw new NumberFormatException(new StringBuffer().append(val).append(" is not a valid number.").toString());
        } else if (val.startsWith("--")) {
            return null;
        } else {
            if (val.startsWith("0x") || val.startsWith("-0x")) {
                return createInteger(val);
            }
            String dec;
            String mant;
            String dec2;
            char lastChar = val.charAt(val.length() - 1);
            int decPos = val.indexOf(46);
            int expPos = (val.indexOf(CallbackEvent.ERROR_MARKET_LAUNCH) + val.indexOf(69)) + 1;
            if (decPos > -1) {
                if (expPos <= -1) {
                    dec = val.substring(decPos + 1);
                } else if (expPos < decPos) {
                    throw new NumberFormatException(new StringBuffer().append(val).append(" is not a valid number.").toString());
                } else {
                    dec = val.substring(decPos + 1, expPos);
                }
                mant = val.substring(0, decPos);
                dec2 = dec;
            } else {
                if (expPos > -1) {
                    dec2 = val.substring(null, expPos);
                } else {
                    dec2 = val;
                }
                mant = dec2;
                dec2 = null;
            }
            boolean allZeros;
            Float f;
            if (Character.isDigit(lastChar)) {
                if (expPos <= -1 || expPos >= val.length() - '\u0001') {
                    dec = null;
                } else {
                    dec = val.substring(expPos + 1, val.length());
                }
                if (dec2 == null && dec == null) {
                    try {
                        return createInteger(val);
                    } catch (NumberFormatException e) {
                        try {
                            return createLong(val);
                        } catch (NumberFormatException e2) {
                            return createBigInteger(val);
                        }
                    }
                }
                allZeros = (isAllZeros(mant) == null || isAllZeros(dec) == null) ? false : true;
                try {
                    f = createFloat(val);
                    if (!f.isInfinite() && (f.floatValue() != 0.0f || allZeros)) {
                        return f;
                    }
                } catch (NumberFormatException e3) {
                }
                try {
                    Double d = createDouble(val);
                    if (!d.isInfinite() && (d.doubleValue() != null || allZeros)) {
                        return d;
                    }
                } catch (NumberFormatException e4) {
                }
                return createBigDecimal(val);
            }
            String exp;
            if (expPos <= -1 || expPos >= val.length() - 1) {
                exp = null;
            } else {
                exp = val.substring(expPos + 1, val.length() - 1);
            }
            String numeric = val.substring(0, val.length() - 1);
            allZeros = isAllZeros(mant) && isAllZeros(exp);
            switch (lastChar) {
                case Wbxml.LITERAL_C /*68*/:
                case SoapEnvelope.VER10 /*100*/:
                    break;
                case 'F':
                case 'f':
                    try {
                        f = createFloat(numeric);
                        if (f.isInfinite() == null && (f.floatValue() != '\u0000' || allZeros)) {
                            return f;
                        }
                    } catch (NumberFormatException e5) {
                        break;
                    }
                case 'L':
                case 'l':
                    if (dec2 == null && exp == null && ((numeric.charAt(false) == '-' && isDigits(numeric.substring(1))) || isDigits(numeric))) {
                        try {
                            return createLong(numeric);
                        } catch (NumberFormatException e6) {
                            return createBigInteger(numeric);
                        }
                    }
                    throw new NumberFormatException(new StringBuffer().append(val).append(" is not a valid number.").toString());
            }
            try {
                dec2 = createDouble(numeric);
                if (!dec2.isInfinite() && (((double) dec2.floatValue()) != 0.0d || allZeros)) {
                    return dec2;
                }
            } catch (NumberFormatException e7) {
            }
            try {
                return createBigDecimal(numeric);
            } catch (NumberFormatException e8) {
                throw new NumberFormatException(new StringBuffer().append(val).append(" is not a valid number.").toString());
            }
        }
    }

    private static boolean isAllZeros(String s) {
        if (s == null) {
            return true;
        }
        for (int i = s.length() - 1; i >= 0; i--) {
            if (s.charAt(i) != '0') {
                return false;
            }
        }
        return s.length() > 0;
    }

    public static Float createFloat(String val) {
        return Float.valueOf(val);
    }

    public static Double createDouble(String val) {
        return Double.valueOf(val);
    }

    public static Integer createInteger(String val) {
        return Integer.decode(val);
    }

    public static Long createLong(String val) {
        return Long.valueOf(val);
    }

    public static BigInteger createBigInteger(String val) {
        return new BigInteger(val);
    }

    public static BigDecimal createBigDecimal(String val) {
        return new BigDecimal(val);
    }

    public static long minimum(long a, long b, long c) {
        if (b < a) {
            a = b;
        }
        if (c < a) {
            return c;
        }
        return a;
    }

    public static int minimum(int a, int b, int c) {
        if (b < a) {
            a = b;
        }
        if (c < a) {
            return c;
        }
        return a;
    }

    public static long maximum(long a, long b, long c) {
        if (b > a) {
            a = b;
        }
        if (c > a) {
            return c;
        }
        return a;
    }

    public static int maximum(int a, int b, int c) {
        if (b > a) {
            a = b;
        }
        if (c > a) {
            return c;
        }
        return a;
    }

    public static int compare(double lhs, double rhs) {
        if (lhs < rhs) {
            return -1;
        }
        if (lhs > rhs) {
            return 1;
        }
        long lhsBits = Double.doubleToLongBits(lhs);
        long rhsBits = Double.doubleToLongBits(rhs);
        if (lhsBits == rhsBits) {
            return 0;
        }
        if (lhsBits < rhsBits) {
            return -1;
        }
        return 1;
    }

    public static int compare(float lhs, float rhs) {
        if (lhs < rhs) {
            return -1;
        }
        if (lhs > rhs) {
            return 1;
        }
        int lhsBits = Float.floatToIntBits(lhs);
        int rhsBits = Float.floatToIntBits(rhs);
        if (lhsBits == rhsBits) {
            return 0;
        }
        if (lhsBits < rhsBits) {
            return -1;
        }
        return 1;
    }

    public static boolean isDigits(String str) {
        if (str == null || str.length() == 0) {
            return false;
        }
        for (int i = 0; i < str.length(); i++) {
            if (!Character.isDigit(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean isNumber(java.lang.String r15) {
        /*
        r14 = 45;
        r13 = 57;
        r12 = 48;
        r11 = 1;
        r10 = 0;
        r8 = org.apache.commons.lang.StringUtils.isEmpty(r15);
        if (r8 == 0) goto L_0x0010;
    L_0x000e:
        r8 = r10;
    L_0x000f:
        return r8;
    L_0x0010:
        r1 = r15.toCharArray();
        r7 = r1.length;
        r4 = 0;
        r3 = 0;
        r0 = 0;
        r2 = 0;
        r8 = r1[r10];
        if (r8 != r14) goto L_0x0034;
    L_0x001d:
        r6 = r11;
    L_0x001e:
        r8 = r6 + 1;
        if (r7 <= r8) goto L_0x005f;
    L_0x0022:
        r8 = r1[r6];
        if (r8 != r12) goto L_0x005f;
    L_0x0026:
        r8 = r6 + 1;
        r8 = r1[r8];
        r9 = 120; // 0x78 float:1.68E-43 double:5.93E-322;
        if (r8 != r9) goto L_0x005f;
    L_0x002e:
        r5 = r6 + 2;
        if (r5 != r7) goto L_0x0038;
    L_0x0032:
        r8 = r10;
        goto L_0x000f;
    L_0x0034:
        r6 = r10;
        goto L_0x001e;
    L_0x0036:
        r5 = r5 + 1;
    L_0x0038:
        r8 = r1.length;
        if (r5 >= r8) goto L_0x005d;
    L_0x003b:
        r8 = r1[r5];
        if (r8 < r12) goto L_0x0043;
    L_0x003f:
        r8 = r1[r5];
        if (r8 <= r13) goto L_0x0036;
    L_0x0043:
        r8 = r1[r5];
        r9 = 97;
        if (r8 < r9) goto L_0x004f;
    L_0x0049:
        r8 = r1[r5];
        r9 = 102; // 0x66 float:1.43E-43 double:5.04E-322;
        if (r8 <= r9) goto L_0x0036;
    L_0x004f:
        r8 = r1[r5];
        r9 = 65;
        if (r8 < r9) goto L_0x005b;
    L_0x0055:
        r8 = r1[r5];
        r9 = 70;
        if (r8 <= r9) goto L_0x0036;
    L_0x005b:
        r8 = r10;
        goto L_0x000f;
    L_0x005d:
        r8 = r11;
        goto L_0x000f;
    L_0x005f:
        r7 = r7 + -1;
        r5 = r6;
    L_0x0062:
        if (r5 < r7) goto L_0x006c;
    L_0x0064:
        r8 = r7 + 1;
        if (r5 >= r8) goto L_0x00b5;
    L_0x0068:
        if (r0 == 0) goto L_0x00b5;
    L_0x006a:
        if (r2 != 0) goto L_0x00b5;
    L_0x006c:
        r8 = r1[r5];
        if (r8 < r12) goto L_0x0079;
    L_0x0070:
        r8 = r1[r5];
        if (r8 > r13) goto L_0x0079;
    L_0x0074:
        r2 = 1;
        r0 = 0;
    L_0x0076:
        r5 = r5 + 1;
        goto L_0x0062;
    L_0x0079:
        r8 = r1[r5];
        r9 = 46;
        if (r8 != r9) goto L_0x0087;
    L_0x007f:
        if (r3 != 0) goto L_0x0083;
    L_0x0081:
        if (r4 == 0) goto L_0x0085;
    L_0x0083:
        r8 = r10;
        goto L_0x000f;
    L_0x0085:
        r3 = 1;
        goto L_0x0076;
    L_0x0087:
        r8 = r1[r5];
        r9 = 101; // 0x65 float:1.42E-43 double:5.0E-322;
        if (r8 == r9) goto L_0x0093;
    L_0x008d:
        r8 = r1[r5];
        r9 = 69;
        if (r8 != r9) goto L_0x00a0;
    L_0x0093:
        if (r4 == 0) goto L_0x0098;
    L_0x0095:
        r8 = r10;
        goto L_0x000f;
    L_0x0098:
        if (r2 != 0) goto L_0x009d;
    L_0x009a:
        r8 = r10;
        goto L_0x000f;
    L_0x009d:
        r4 = 1;
        r0 = 1;
        goto L_0x0076;
    L_0x00a0:
        r8 = r1[r5];
        r9 = 43;
        if (r8 == r9) goto L_0x00aa;
    L_0x00a6:
        r8 = r1[r5];
        if (r8 != r14) goto L_0x00b2;
    L_0x00aa:
        if (r0 != 0) goto L_0x00af;
    L_0x00ac:
        r8 = r10;
        goto L_0x000f;
    L_0x00af:
        r0 = 0;
        r2 = 0;
        goto L_0x0076;
    L_0x00b2:
        r8 = r10;
        goto L_0x000f;
    L_0x00b5:
        r8 = r1.length;
        if (r5 >= r8) goto L_0x0108;
    L_0x00b8:
        r8 = r1[r5];
        if (r8 < r12) goto L_0x00c3;
    L_0x00bc:
        r8 = r1[r5];
        if (r8 > r13) goto L_0x00c3;
    L_0x00c0:
        r8 = r11;
        goto L_0x000f;
    L_0x00c3:
        r8 = r1[r5];
        r9 = 101; // 0x65 float:1.42E-43 double:5.0E-322;
        if (r8 == r9) goto L_0x00cf;
    L_0x00c9:
        r8 = r1[r5];
        r9 = 69;
        if (r8 != r9) goto L_0x00d2;
    L_0x00cf:
        r8 = r10;
        goto L_0x000f;
    L_0x00d2:
        if (r0 != 0) goto L_0x00ef;
    L_0x00d4:
        r8 = r1[r5];
        r9 = 100;
        if (r8 == r9) goto L_0x00ec;
    L_0x00da:
        r8 = r1[r5];
        r9 = 68;
        if (r8 == r9) goto L_0x00ec;
    L_0x00e0:
        r8 = r1[r5];
        r9 = 102; // 0x66 float:1.43E-43 double:5.04E-322;
        if (r8 == r9) goto L_0x00ec;
    L_0x00e6:
        r8 = r1[r5];
        r9 = 70;
        if (r8 != r9) goto L_0x00ef;
    L_0x00ec:
        r8 = r2;
        goto L_0x000f;
    L_0x00ef:
        r8 = r1[r5];
        r9 = 108; // 0x6c float:1.51E-43 double:5.34E-322;
        if (r8 == r9) goto L_0x00fb;
    L_0x00f5:
        r8 = r1[r5];
        r9 = 76;
        if (r8 != r9) goto L_0x0105;
    L_0x00fb:
        if (r2 == 0) goto L_0x0102;
    L_0x00fd:
        if (r4 != 0) goto L_0x0102;
    L_0x00ff:
        r8 = r11;
        goto L_0x000f;
    L_0x0102:
        r8 = r10;
        goto L_0x000f;
    L_0x0105:
        r8 = r10;
        goto L_0x000f;
    L_0x0108:
        if (r0 != 0) goto L_0x010f;
    L_0x010a:
        if (r2 == 0) goto L_0x010f;
    L_0x010c:
        r8 = r11;
        goto L_0x000f;
    L_0x010f:
        r8 = r10;
        goto L_0x000f;
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.commons.lang.NumberUtils.isNumber(java.lang.String):boolean");
    }
}
