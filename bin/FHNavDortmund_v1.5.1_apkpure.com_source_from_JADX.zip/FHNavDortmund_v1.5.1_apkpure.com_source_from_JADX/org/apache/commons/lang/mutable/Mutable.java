package org.apache.commons.lang.mutable;

public interface Mutable {
    Object getValue();

    void setValue(Object obj);
}
