package org.apache.commons.lang;

public class NullArgumentException extends IllegalArgumentException {
    private static final long serialVersionUID = 1174360235354917591L;

    public NullArgumentException(String argName) {
        String str;
        StringBuffer stringBuffer = new StringBuffer();
        if (argName == null) {
            str = "Argument";
        } else {
            str = argName;
        }
        super(stringBuffer.append(str).append(" must not be null.").toString());
    }
}
