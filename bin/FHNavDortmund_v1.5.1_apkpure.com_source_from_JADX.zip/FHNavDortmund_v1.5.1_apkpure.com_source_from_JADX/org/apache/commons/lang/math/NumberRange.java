package org.apache.commons.lang.math;

import java.io.Serializable;
import org.apache.commons.lang.text.StrBuilder;

public final class NumberRange extends Range implements Serializable {
    private static final long serialVersionUID = 71849363892710L;
    private transient int hashCode;
    private final Number max;
    private final Number min;
    private transient String toString;

    public NumberRange(Number num) {
        String str = "The number must not be NaN";
        this.hashCode = 0;
        this.toString = null;
        if (num == null) {
            throw new IllegalArgumentException("The number must not be null");
        } else if (num instanceof Comparable) {
            String str2;
            if (num instanceof Double) {
                if (((Double) num).isNaN()) {
                    str2 = "The number must not be NaN";
                    throw new IllegalArgumentException(str);
                }
            }
            if (num instanceof Float) {
                if (((Float) num).isNaN()) {
                    str2 = "The number must not be NaN";
                    throw new IllegalArgumentException(str);
                }
            }
            this.min = num;
            this.max = num;
        } else {
            throw new IllegalArgumentException("The number must implement Comparable");
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public NumberRange(java.lang.Number r6, java.lang.Number r7) {
        /*
        r5 = this;
        r4 = "The number must not be NaN";
        r5.<init>();
        r2 = 0;
        r5.hashCode = r2;
        r2 = 0;
        r5.toString = r2;
        if (r6 == 0) goto L_0x000f;
    L_0x000d:
        if (r7 != 0) goto L_0x0017;
    L_0x000f:
        r2 = new java.lang.IllegalArgumentException;
        r3 = "The numbers must not be null";
        r2.<init>(r3);
        throw r2;
    L_0x0017:
        r2 = r6.getClass();
        r3 = r7.getClass();
        if (r2 == r3) goto L_0x0029;
    L_0x0021:
        r2 = new java.lang.IllegalArgumentException;
        r3 = "The numbers must be of the same type";
        r2.<init>(r3);
        throw r2;
    L_0x0029:
        r2 = r6 instanceof java.lang.Comparable;
        if (r2 != 0) goto L_0x0035;
    L_0x002d:
        r2 = new java.lang.IllegalArgumentException;
        r3 = "The numbers must implement Comparable";
        r2.<init>(r3);
        throw r2;
    L_0x0035:
        r2 = r6 instanceof java.lang.Double;
        if (r2 == 0) goto L_0x0055;
    L_0x0039:
        r0 = r6;
        r0 = (java.lang.Double) r0;
        r2 = r0;
        r2 = r2.isNaN();
        if (r2 != 0) goto L_0x004d;
    L_0x0043:
        r0 = r7;
        r0 = (java.lang.Double) r0;
        r2 = r0;
        r2 = r2.isNaN();
        if (r2 == 0) goto L_0x0075;
    L_0x004d:
        r2 = new java.lang.IllegalArgumentException;
        r3 = "The number must not be NaN";
        r2.<init>(r4);
        throw r2;
    L_0x0055:
        r2 = r6 instanceof java.lang.Float;
        if (r2 == 0) goto L_0x0075;
    L_0x0059:
        r0 = r6;
        r0 = (java.lang.Float) r0;
        r2 = r0;
        r2 = r2.isNaN();
        if (r2 != 0) goto L_0x006d;
    L_0x0063:
        r0 = r7;
        r0 = (java.lang.Float) r0;
        r2 = r0;
        r2 = r2.isNaN();
        if (r2 == 0) goto L_0x0075;
    L_0x006d:
        r2 = new java.lang.IllegalArgumentException;
        r3 = "The number must not be NaN";
        r2.<init>(r4);
        throw r2;
    L_0x0075:
        r0 = r6;
        r0 = (java.lang.Comparable) r0;
        r2 = r0;
        r1 = r2.compareTo(r7);
        if (r1 != 0) goto L_0x0084;
    L_0x007f:
        r5.min = r6;
        r5.max = r6;
    L_0x0083:
        return;
    L_0x0084:
        if (r1 <= 0) goto L_0x008b;
    L_0x0086:
        r5.min = r7;
        r5.max = r6;
        goto L_0x0083;
    L_0x008b:
        r5.min = r6;
        r5.max = r7;
        goto L_0x0083;
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.commons.lang.math.NumberRange.<init>(java.lang.Number, java.lang.Number):void");
    }

    public Number getMinimumNumber() {
        return this.min;
    }

    public Number getMaximumNumber() {
        return this.max;
    }

    public boolean containsNumber(Number number) {
        if (number == null) {
            return false;
        }
        if (number.getClass() != this.min.getClass()) {
            throw new IllegalArgumentException("The number must be of the same type as the range numbers");
        }
        return ((Comparable) this.min).compareTo(number) <= 0 && ((Comparable) this.max).compareTo(number) >= 0;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof NumberRange)) {
            return false;
        }
        NumberRange range = (NumberRange) obj;
        return this.min.equals(range.min) && this.max.equals(range.max);
    }

    public int hashCode() {
        if (this.hashCode == 0) {
            this.hashCode = 17;
            this.hashCode = (this.hashCode * 37) + getClass().hashCode();
            this.hashCode = (this.hashCode * 37) + this.min.hashCode();
            this.hashCode = (this.hashCode * 37) + this.max.hashCode();
        }
        return this.hashCode;
    }

    public String toString() {
        if (this.toString == null) {
            StrBuilder buf = new StrBuilder(32);
            buf.append("Range[");
            buf.append(this.min);
            buf.append(',');
            buf.append(this.max);
            buf.append(']');
            this.toString = buf.toString();
        }
        return this.toString;
    }
}
