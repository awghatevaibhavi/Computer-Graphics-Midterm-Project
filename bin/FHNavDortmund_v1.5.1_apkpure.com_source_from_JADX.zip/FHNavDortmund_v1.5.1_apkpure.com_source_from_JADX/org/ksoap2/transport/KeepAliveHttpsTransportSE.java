package org.ksoap2.transport;

import java.io.IOException;

public class KeepAliveHttpsTransportSE extends HttpsTransportSE {
    private HttpsServiceConnectionSE conn;
    private final String file;
    private final String host;
    private final int port;
    private final int timeout;

    class 1 extends HttpsServiceConnectionSE {
        private final KeepAliveHttpsTransportSE this$0;

        1(KeepAliveHttpsTransportSE keepAliveHttpsTransportSE, String x0, int x1, String x2, int x3) {
            super(x0, x1, x2, x3);
            this.this$0 = keepAliveHttpsTransportSE;
        }

        public void setRequestProperty(String key, String value) {
            if (!"Connection".equalsIgnoreCase(key) || !"close".equalsIgnoreCase(value)) {
                super.setRequestProperty(key, value);
            }
        }
    }

    public KeepAliveHttpsTransportSE(String host, int port, String file, int timeout) {
        super(host, port, file, timeout);
        this.conn = null;
        this.host = host;
        this.port = port;
        this.file = file;
        this.timeout = timeout;
    }

    protected ServiceConnection getServiceConnection() throws IOException {
        this.conn = new 1(this, this.host, this.port, this.file, this.timeout);
        this.conn.setRequestProperty("Connection", "keep-alive");
        return this.conn;
    }
}
