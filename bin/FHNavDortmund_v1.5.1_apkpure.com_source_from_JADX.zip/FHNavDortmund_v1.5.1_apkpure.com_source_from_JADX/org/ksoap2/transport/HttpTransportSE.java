package org.ksoap2.transport;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.ksoap2.HeaderProperty;
import org.ksoap2.SoapEnvelope;
import org.xmlpull.v1.XmlPullParserException;

public class HttpTransportSE extends Transport {
    private ServiceConnection connection;

    public HttpTransportSE(String url) {
        super(null, url);
    }

    public HttpTransportSE(Proxy proxy, String url) {
        super(proxy, url);
    }

    public HttpTransportSE(String url, int timeout) {
        super(url, timeout);
    }

    public void call(String soapAction, SoapEnvelope envelope) throws IOException, XmlPullParserException {
        call(soapAction, envelope, null);
    }

    public List call(String soapAction, SoapEnvelope envelope, List headers) throws IOException, XmlPullParserException {
        InputStream is;
        if (soapAction == null) {
            soapAction = "\"\"";
        }
        byte[] requestData = createRequestData(envelope);
        this.requestDump = this.debug ? new String(requestData) : null;
        this.responseDump = null;
        this.connection = getServiceConnection();
        this.connection.setRequestProperty("User-Agent", "kSOAP/2.0");
        this.connection.setRequestProperty("SOAPAction", soapAction);
        this.connection.setRequestProperty("Content-Type", "text/xml");
        this.connection.setRequestProperty("Connection", "close");
        this.connection.setRequestProperty("Content-Length", new StringBuffer().append(StringUtils.EMPTY).append(requestData.length).toString());
        if (headers != null) {
            for (int i = 0; i < headers.size(); i++) {
                HeaderProperty hp = (HeaderProperty) headers.get(i);
                this.connection.setRequestProperty(hp.getKey(), hp.getValue());
            }
        }
        this.connection.setRequestMethod("POST");
        this.connection.connect();
        OutputStream os = this.connection.openOutputStream();
        os.write(requestData, 0, requestData.length);
        os.flush();
        os.close();
        List retHeaders = null;
        try {
            this.connection.connect();
            is = this.connection.openInputStream();
            retHeaders = this.connection.getResponseProperties();
        } catch (IOException e) {
            IOException e2 = e;
            is = this.connection.getErrorStream();
            if (is == null) {
                this.connection.disconnect();
                throw e2;
            }
        }
        if (this.debug) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[256];
            while (true) {
                int rd = is.read(buf, 0, 256);
                if (rd == -1) {
                    break;
                }
                bos.write(buf, 0, rd);
            }
            bos.flush();
            buf = bos.toByteArray();
            this.responseDump = new String(buf);
            is.close();
            is = new ByteArrayInputStream(buf);
        }
        parseResponse(envelope, is);
        return retHeaders;
    }

    public ServiceConnection getConnection() {
        return (ServiceConnectionSE) this.connection;
    }

    protected ServiceConnection getServiceConnection() throws IOException {
        return new ServiceConnectionSE(this.proxy, this.url);
    }

    public String getHost() {
        String retVal = null;
        try {
            retVal = new URL(this.url).getHost();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return retVal;
    }

    public int getPort() {
        int retVal = -1;
        try {
            retVal = new URL(this.url).getPort();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return retVal;
    }

    public String getPath() {
        String retVal = null;
        try {
            retVal = new URL(this.url).getPath();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return retVal;
    }
}
