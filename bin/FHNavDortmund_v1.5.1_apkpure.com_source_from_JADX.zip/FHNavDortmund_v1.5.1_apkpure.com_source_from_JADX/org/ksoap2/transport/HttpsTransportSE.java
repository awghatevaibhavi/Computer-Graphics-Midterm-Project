package org.ksoap2.transport;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class HttpsTransportSE extends HttpTransportSE {
    static final String PROTOCOL = "https";
    private HttpsServiceConnectionSE conn;
    private final String file;
    private final String host;
    private final int port;
    private final int timeout;

    public HttpsTransportSE(String host, int port, String file, int timeout) {
        super(new StringBuffer().append("https://").append(host).append(":").append(port).append(file).toString());
        this.conn = null;
        this.host = host;
        this.port = port;
        this.file = file;
        this.timeout = timeout;
    }

    public ServiceConnection getConnection() {
        return this.conn;
    }

    protected ServiceConnection getServiceConnection() throws IOException {
        this.conn = new HttpsServiceConnectionSE(this.host, this.port, this.file, this.timeout);
        return this.conn;
    }

    public String getHost() {
        String retVal = null;
        try {
            retVal = new URL(this.url).getHost();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return retVal;
    }

    public int getPort() {
        int retVal = -1;
        try {
            retVal = new URL(this.url).getPort();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return retVal;
    }

    public String getPath() {
        String retVal = null;
        try {
            retVal = new URL(this.url).getPath();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return retVal;
    }
}
