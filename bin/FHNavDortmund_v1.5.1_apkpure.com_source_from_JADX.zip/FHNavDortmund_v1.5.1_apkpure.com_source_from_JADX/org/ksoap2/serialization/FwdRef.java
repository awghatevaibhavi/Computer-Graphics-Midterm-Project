package org.ksoap2.serialization;

class FwdRef {
    int index;
    FwdRef next;
    Object obj;

    FwdRef() {
    }
}
