package org.ksoap2.serialization;

import java.util.Vector;
import org.apache.commons.lang.StringUtils;

public class PropertyInfo {
    public static final Class BOOLEAN_CLASS;
    public static final Class INTEGER_CLASS;
    public static final Class LONG_CLASS;
    public static final int MULTI_REF = 2;
    public static final Class OBJECT_CLASS;
    public static final PropertyInfo OBJECT_TYPE;
    public static final int REF_ONLY = 4;
    public static final Class STRING_CLASS;
    public static final int TRANSIENT = 1;
    public static final Class VECTOR_CLASS;
    public PropertyInfo elementType;
    public int flags;
    public boolean multiRef;
    public String name;
    public String namespace;
    public Object type;
    protected Object value;

    static {
        OBJECT_CLASS = new Object().getClass();
        STRING_CLASS = StringUtils.EMPTY.getClass();
        INTEGER_CLASS = new Integer(0).getClass();
        LONG_CLASS = new Long(0).getClass();
        BOOLEAN_CLASS = new Boolean(true).getClass();
        VECTOR_CLASS = new Vector().getClass();
        OBJECT_TYPE = new PropertyInfo();
    }

    public PropertyInfo() {
        this.type = OBJECT_CLASS;
    }

    public void clear() {
        this.type = OBJECT_CLASS;
        this.flags = 0;
        this.name = null;
        this.namespace = null;
    }

    public PropertyInfo getElementType() {
        return this.elementType;
    }

    public void setElementType(PropertyInfo elementType) {
        this.elementType = elementType;
    }

    public int getFlags() {
        return this.flags;
    }

    public void setFlags(int flags) {
        this.flags = flags;
    }

    public boolean isMultiRef() {
        return this.multiRef;
    }

    public void setMultiRef(boolean multiRef) {
        this.multiRef = multiRef;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNamespace() {
        return this.namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public Object getType() {
        return this.type;
    }

    public void setType(Object type) {
        this.type = type;
    }

    public Object getValue() {
        return this.value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.name);
        sb.append(" : ");
        if (this.value != null) {
            sb.append(this.value);
        } else {
            sb.append("(not set)");
        }
        return sb.toString();
    }
}
