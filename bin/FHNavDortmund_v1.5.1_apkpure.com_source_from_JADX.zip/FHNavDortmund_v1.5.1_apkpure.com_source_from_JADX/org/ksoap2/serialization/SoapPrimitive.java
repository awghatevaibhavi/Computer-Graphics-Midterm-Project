package org.ksoap2.serialization;

public class SoapPrimitive extends AttributeContainer {
    String name;
    String namespace;
    String value;

    public SoapPrimitive(String namespace, String name, String value) {
        this.namespace = namespace;
        this.name = name;
        this.value = value;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean equals(java.lang.Object r8) {
        /*
        r7 = this;
        r6 = 1;
        r5 = 0;
        r3 = r8 instanceof org.ksoap2.serialization.SoapPrimitive;
        if (r3 != 0) goto L_0x0008;
    L_0x0006:
        r3 = r5;
    L_0x0007:
        return r3;
    L_0x0008:
        r0 = r8;
        r0 = (org.ksoap2.serialization.SoapPrimitive) r0;
        r1 = r0;
        r3 = r7.name;
        r4 = r1.name;
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x003b;
    L_0x0016:
        r3 = r7.namespace;
        if (r3 != 0) goto L_0x0031;
    L_0x001a:
        r3 = r1.namespace;
        if (r3 != 0) goto L_0x003b;
    L_0x001e:
        r3 = r7.value;
        if (r3 != 0) goto L_0x003d;
    L_0x0022:
        r3 = r1.value;
        if (r3 != 0) goto L_0x003b;
    L_0x0026:
        r2 = r6;
    L_0x0027:
        if (r2 == 0) goto L_0x0048;
    L_0x0029:
        r3 = r7.attributesAreEqual(r1);
        if (r3 == 0) goto L_0x0048;
    L_0x002f:
        r3 = r6;
        goto L_0x0007;
    L_0x0031:
        r3 = r7.namespace;
        r4 = r1.namespace;
        r3 = r3.equals(r4);
        if (r3 != 0) goto L_0x001e;
    L_0x003b:
        r2 = r5;
        goto L_0x0027;
    L_0x003d:
        r3 = r7.value;
        r4 = r1.value;
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x003b;
    L_0x0047:
        goto L_0x0026;
    L_0x0048:
        r3 = r5;
        goto L_0x0007;
        */
        throw new UnsupportedOperationException("Method not decompiled: org.ksoap2.serialization.SoapPrimitive.equals(java.lang.Object):boolean");
    }

    public int hashCode() {
        return this.name.hashCode() ^ (this.namespace == null ? 0 : this.namespace.hashCode());
    }

    public String toString() {
        return this.value;
    }

    public String getNamespace() {
        return this.namespace;
    }

    public String getName() {
        return this.name;
    }
}
