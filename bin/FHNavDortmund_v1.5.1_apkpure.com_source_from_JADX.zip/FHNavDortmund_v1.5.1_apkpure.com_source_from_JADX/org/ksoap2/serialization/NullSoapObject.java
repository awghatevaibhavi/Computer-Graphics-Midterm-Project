package org.ksoap2.serialization;

public class NullSoapObject {
    public String toString() {
        return null;
    }
}
