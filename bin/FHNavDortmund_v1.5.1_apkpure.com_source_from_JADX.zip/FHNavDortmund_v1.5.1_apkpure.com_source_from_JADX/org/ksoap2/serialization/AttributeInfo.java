package org.ksoap2.serialization;

public class AttributeInfo extends PropertyInfo {
}
