package org.ksoap2.serialization;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Vector;
import org.apache.commons.lang.StringUtils;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.SoapFault;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

public class SoapSerializationEnvelope extends SoapEnvelope {
    private static final String ANY_TYPE_LABEL = "anyType";
    private static final String ARRAY_MAPPING_NAME = "Array";
    private static final String ARRAY_TYPE_LABEL = "arrayType";
    static final Marshal DEFAULT_MARSHAL;
    private static final String HREF_LABEL = "href";
    private static final String ID_LABEL = "id";
    private static final String ITEM_LABEL = "item";
    private static final String NIL_LABEL = "nil";
    private static final String NULL_LABEL = "null";
    protected static final int QNAME_MARSHAL = 3;
    protected static final int QNAME_NAMESPACE = 0;
    protected static final int QNAME_TYPE = 1;
    private static final String ROOT_LABEL = "root";
    private static final String TYPE_LABEL = "type";
    static Class class$org$ksoap2$serialization$SoapObject;
    protected boolean addAdornments;
    protected Hashtable classToQName;
    public boolean dotNet;
    Hashtable idMap;
    public boolean implicitTypes;
    Vector multiRef;
    public Hashtable properties;
    protected Hashtable qNameToClass;

    static {
        DEFAULT_MARSHAL = new DM();
    }

    public SoapSerializationEnvelope(int version) {
        super(version);
        this.properties = new Hashtable();
        this.idMap = new Hashtable();
        this.qNameToClass = new Hashtable();
        this.classToQName = new Hashtable();
        this.addAdornments = true;
        addMapping(this.enc, ARRAY_MAPPING_NAME, PropertyInfo.VECTOR_CLASS);
        DEFAULT_MARSHAL.register(this);
    }

    public boolean isAddAdornments() {
        return this.addAdornments;
    }

    public void setAddAdornments(boolean addAdornments) {
        this.addAdornments = addAdornments;
    }

    public void parseBody(XmlPullParser parser) throws IOException, XmlPullParserException {
        this.bodyIn = null;
        parser.nextTag();
        if (parser.getEventType() == 2 && parser.getNamespace().equals(this.env) && parser.getName().equals("Fault")) {
            SoapFault fault = new SoapFault();
            fault.parse(parser);
            this.bodyIn = fault;
            return;
        }
        while (parser.getEventType() == 2) {
            String rootAttr = parser.getAttributeValue(this.enc, ROOT_LABEL);
            Object o = read(parser, null, -1, parser.getNamespace(), parser.getName(), PropertyInfo.OBJECT_TYPE);
            if ("1".equals(rootAttr) || this.bodyIn == null) {
                this.bodyIn = o;
            }
            parser.nextTag();
        }
    }

    protected void readSerializable(XmlPullParser parser, SoapObject obj) throws IOException, XmlPullParserException {
        for (int counter = QNAME_NAMESPACE; counter < parser.getAttributeCount(); counter += QNAME_TYPE) {
            obj.addAttribute(parser.getAttributeName(counter), parser.getAttributeValue(counter));
        }
        readSerializable(parser, (KvmSerializable) obj);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected void readSerializable(org.xmlpull.v1.XmlPullParser r22, org.ksoap2.serialization.KvmSerializable r23) throws java.io.IOException, org.xmlpull.v1.XmlPullParserException {
        /*
        r21 = this;
        r7 = -1;
        r20 = r23.getPropertyCount();
        r10 = new org.ksoap2.serialization.PropertyInfo;
        r10.<init>();
    L_0x000a:
        r4 = r22.nextTag();
        r5 = 3;
        if (r4 == r5) goto L_0x00c4;
    L_0x0011:
        r16 = r22.getName();
        r18 = r20;
        r0 = r21;
        r0 = r0.implicitTypes;
        r4 = r0;
        if (r4 == 0) goto L_0x0025;
    L_0x001e:
        r0 = r23;
        r0 = r0 instanceof org.ksoap2.serialization.SoapObject;
        r4 = r0;
        if (r4 != 0) goto L_0x009d;
    L_0x0025:
        r19 = r18;
        r18 = r19 + -1;
        if (r19 != 0) goto L_0x0047;
    L_0x002b:
        r4 = new java.lang.RuntimeException;
        r5 = new java.lang.StringBuffer;
        r5.<init>();
        r6 = "Unknown Property: ";
        r5 = r5.append(r6);
        r0 = r5;
        r1 = r16;
        r5 = r0.append(r1);
        r5 = r5.toString();
        r4.<init>(r5);
        throw r4;
    L_0x0047:
        r7 = r7 + 1;
        r0 = r7;
        r1 = r20;
        if (r0 < r1) goto L_0x004f;
    L_0x004e:
        r7 = 0;
    L_0x004f:
        r0 = r21;
        r0 = r0.properties;
        r4 = r0;
        r0 = r23;
        r1 = r7;
        r2 = r4;
        r3 = r10;
        r0.getPropertyInfo(r1, r2, r3);
        r4 = r10.namespace;
        if (r4 != 0) goto L_0x006b;
    L_0x0060:
        r4 = r10.name;
        r0 = r16;
        r1 = r4;
        r4 = r0.equals(r1);
        if (r4 != 0) goto L_0x0088;
    L_0x006b:
        r4 = r10.name;
        if (r4 != 0) goto L_0x0071;
    L_0x006f:
        if (r7 == 0) goto L_0x0088;
    L_0x0071:
        r4 = r10.name;
        r0 = r16;
        r1 = r4;
        r4 = r0.equals(r1);
        if (r4 == 0) goto L_0x0025;
    L_0x007c:
        r4 = r22.getNamespace();
        r5 = r10.namespace;
        r4 = r4.equals(r5);
        if (r4 == 0) goto L_0x0025;
    L_0x0088:
        r8 = 0;
        r9 = 0;
        r4 = r21;
        r5 = r22;
        r6 = r23;
        r4 = r4.read(r5, r6, r7, r8, r9, r10);
        r0 = r23;
        r1 = r7;
        r2 = r4;
        r0.setProperty(r1, r2);
        goto L_0x000a;
    L_0x009d:
        r0 = r23;
        r0 = (org.ksoap2.serialization.SoapObject) r0;
        r4 = r0;
        r6 = r22.getName();
        r14 = r23.getPropertyCount();
        r0 = r23;
        r0 = (org.ksoap2.serialization.SoapObject) r0;
        r5 = r0;
        r15 = r5.getNamespace();
        r17 = org.ksoap2.serialization.PropertyInfo.OBJECT_TYPE;
        r11 = r21;
        r12 = r22;
        r13 = r23;
        r5 = r11.read(r12, r13, r14, r15, r16, r17);
        r4.addProperty(r6, r5);
        goto L_0x000a;
    L_0x00c4:
        r4 = 3;
        r5 = 0;
        r6 = 0;
        r0 = r22;
        r1 = r4;
        r2 = r5;
        r3 = r6;
        r0.require(r1, r2, r3);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: org.ksoap2.serialization.SoapSerializationEnvelope.readSerializable(org.xmlpull.v1.XmlPullParser, org.ksoap2.serialization.KvmSerializable):void");
    }

    protected Object readUnknown(XmlPullParser parser, String typeNamespace, String typeName) throws IOException, XmlPullParserException {
        int i;
        SoapObject soapObject;
        Object obj;
        String name = parser.getName();
        String namespace = parser.getNamespace();
        Vector attributeInfoVector = new Vector();
        for (int attributeCount = QNAME_NAMESPACE; attributeCount < parser.getAttributeCount(); attributeCount += QNAME_TYPE) {
            AttributeInfo attributeInfo = new AttributeInfo();
            attributeInfo.setName(parser.getAttributeName(attributeCount));
            attributeInfo.setValue(parser.getAttributeValue(attributeCount));
            attributeInfo.setNamespace(parser.getAttributeNamespace(attributeCount));
            attributeInfo.setType(parser.getAttributeType(attributeCount));
            attributeInfoVector.addElement(attributeInfo);
        }
        parser.next();
        Object obj2 = null;
        String text = null;
        if (parser.getEventType() == 4) {
            text = parser.getText();
            SoapPrimitive soapPrimitive = new SoapPrimitive(typeNamespace, typeName, text);
            obj2 = soapPrimitive;
            for (i = QNAME_NAMESPACE; i < attributeInfoVector.size(); i += QNAME_TYPE) {
                soapPrimitive.addAttribute((AttributeInfo) attributeInfoVector.elementAt(i));
            }
            parser.next();
        } else if (parser.getEventType() == QNAME_MARSHAL) {
            soapObject = new SoapObject(typeNamespace, typeName);
            for (i = QNAME_NAMESPACE; i < attributeInfoVector.size(); i += QNAME_TYPE) {
                soapObject.addAttribute((AttributeInfo) attributeInfoVector.elementAt(i));
            }
            SoapObject result = soapObject;
        }
        if (parser.getEventType() != 2) {
            obj = obj2;
        } else if (text == null || text.trim().length() == 0) {
            soapObject = new SoapObject(typeNamespace, typeName);
            for (i = QNAME_NAMESPACE; i < attributeInfoVector.size(); i += QNAME_TYPE) {
                soapObject.addAttribute((AttributeInfo) attributeInfoVector.elementAt(i));
            }
            while (parser.getEventType() != QNAME_MARSHAL) {
                soapObject.addProperty(parser.getName(), read(parser, soapObject, soapObject.getPropertyCount(), null, null, PropertyInfo.OBJECT_TYPE));
                parser.nextTag();
            }
            obj = soapObject;
        } else {
            throw new RuntimeException("Malformed input: Mixed content");
        }
        parser.require(QNAME_MARSHAL, namespace, name);
        return obj;
    }

    private int getIndex(String value, int start, int dflt) {
        if (value == null) {
            return dflt;
        }
        return value.length() - start < QNAME_MARSHAL ? dflt : Integer.parseInt(value.substring(start + QNAME_TYPE, value.length() - QNAME_TYPE));
    }

    protected void readVector(XmlPullParser parser, Vector v, PropertyInfo elementType) throws IOException, XmlPullParserException {
        String namespace = null;
        String name = null;
        int size = v.size();
        boolean dynamic = true;
        String type = parser.getAttributeValue(this.enc, ARRAY_TYPE_LABEL);
        if (type != null) {
            String prefix;
            int cut0 = type.indexOf(58);
            int cut1 = type.indexOf("[", cut0);
            name = type.substring(cut0 + QNAME_TYPE, cut1);
            if (cut0 == -1) {
                prefix = StringUtils.EMPTY;
            } else {
                prefix = type.substring(QNAME_NAMESPACE, cut0);
            }
            namespace = parser.getNamespace(prefix);
            size = getIndex(type, cut1, -1);
            if (size != -1) {
                v.setSize(size);
                dynamic = false;
            }
        }
        if (elementType == null) {
            elementType = PropertyInfo.OBJECT_TYPE;
        }
        parser.nextTag();
        int position = getIndex(parser.getAttributeValue(this.enc, "offset"), QNAME_NAMESPACE, QNAME_NAMESPACE);
        while (parser.getEventType() != QNAME_MARSHAL) {
            position = getIndex(parser.getAttributeValue(this.enc, "position"), QNAME_NAMESPACE, position);
            if (dynamic && position >= size) {
                size = position + QNAME_TYPE;
                v.setSize(size);
            }
            v.setElementAt(read(parser, v, position, namespace, name, elementType), position);
            position += QNAME_TYPE;
            parser.nextTag();
        }
        parser.require(QNAME_MARSHAL, null, null);
    }

    public Object read(XmlPullParser parser, Object owner, int index, String namespace, String name, PropertyInfo expected) throws IOException, XmlPullParserException {
        Object obj;
        String elementName = parser.getName();
        String href = parser.getAttributeValue(null, HREF_LABEL);
        Object obj2;
        FwdRef f;
        if (href == null) {
            String nullAttr = parser.getAttributeValue(this.xsi, NIL_LABEL);
            String id = parser.getAttributeValue(null, ID_LABEL);
            if (nullAttr == null) {
                nullAttr = parser.getAttributeValue(this.xsi, NULL_LABEL);
            }
            if (nullAttr == null || !SoapEnvelope.stringToBoolean(nullAttr)) {
                String type = parser.getAttributeValue(this.xsi, TYPE_LABEL);
                if (type != null) {
                    int cut = type.indexOf(58);
                    name = type.substring(cut + QNAME_TYPE);
                    namespace = parser.getNamespace(cut == -1 ? StringUtils.EMPTY : type.substring(QNAME_NAMESPACE, cut));
                } else if (name == null && namespace == null) {
                    if (parser.getAttributeValue(this.enc, ARRAY_TYPE_LABEL) != null) {
                        namespace = this.enc;
                        name = ARRAY_MAPPING_NAME;
                    } else {
                        Object[] names = getInfo(expected.type, null);
                        namespace = names[QNAME_NAMESPACE];
                        name = names[QNAME_TYPE];
                    }
                }
                if (type == null) {
                    this.implicitTypes = true;
                }
                obj2 = readInstance(parser, namespace, name, expected);
                if (obj2 == null) {
                    obj2 = readUnknown(parser, namespace, name);
                }
            } else {
                obj2 = null;
                parser.nextTag();
                parser.require(QNAME_MARSHAL, null, elementName);
            }
            if (id != null) {
                Object hlp = this.idMap.get(id);
                if (hlp instanceof FwdRef) {
                    f = (FwdRef) hlp;
                    do {
                        if (f.obj instanceof KvmSerializable) {
                            ((KvmSerializable) f.obj).setProperty(f.index, obj2);
                        } else {
                            ((Vector) f.obj).setElementAt(obj2, f.index);
                        }
                        f = f.next;
                    } while (f != null);
                } else if (hlp != null) {
                    throw new RuntimeException("double ID");
                }
                this.idMap.put(id, obj2);
            }
            obj = obj2;
        } else if (owner == null) {
            throw new RuntimeException("href at root level?!?");
        } else {
            href = href.substring(QNAME_TYPE);
            obj2 = this.idMap.get(href);
            if (obj2 == null || (obj2 instanceof FwdRef)) {
                f = new FwdRef();
                f.next = (FwdRef) obj2;
                f.obj = owner;
                f.index = index;
                this.idMap.put(href, f);
                obj2 = null;
            }
            parser.nextTag();
            parser.require(QNAME_MARSHAL, null, elementName);
            obj = obj2;
        }
        parser.require(QNAME_MARSHAL, null, elementName);
        return obj;
    }

    public Object readInstance(XmlPullParser parser, String namespace, String name, PropertyInfo expected) throws IOException, XmlPullParserException {
        Class obj = this.qNameToClass.get(new SoapPrimitive(namespace, name, null));
        if (obj == null) {
            return null;
        }
        if (obj instanceof Marshal) {
            return ((Marshal) obj).readInstance(parser, namespace, name, expected);
        }
        Object newInstance;
        if (obj instanceof SoapObject) {
            newInstance = ((SoapObject) obj).newInstance();
        } else {
            Class class$;
            if (class$org$ksoap2$serialization$SoapObject == null) {
                class$ = class$("org.ksoap2.serialization.SoapObject");
                class$org$ksoap2$serialization$SoapObject = class$;
            } else {
                class$ = class$org$ksoap2$serialization$SoapObject;
            }
            if (obj == class$) {
                newInstance = new SoapObject(namespace, name);
            } else {
                try {
                    newInstance = obj.newInstance();
                } catch (Exception e) {
                    throw new RuntimeException(e.toString());
                }
            }
        }
        if (newInstance instanceof SoapObject) {
            readSerializable(parser, (SoapObject) newInstance);
        } else if (newInstance instanceof KvmSerializable) {
            readSerializable(parser, (KvmSerializable) newInstance);
        } else if (newInstance instanceof Vector) {
            readVector(parser, (Vector) newInstance, expected.elementType);
        } else {
            throw new RuntimeException(new StringBuffer().append("no deserializer for ").append(newInstance.getClass()).toString());
        }
        return newInstance;
    }

    static Class class$(String x0) {
        try {
            return Class.forName(x0);
        } catch (ClassNotFoundException x1) {
            throw new NoClassDefFoundError(x1.getMessage());
        }
    }

    public Object[] getInfo(Object type, Object instance) {
        Class type2;
        if (type == null) {
            if ((instance instanceof SoapObject) || (instance instanceof SoapPrimitive)) {
                type2 = instance;
            } else {
                type2 = instance.getClass();
            }
        }
        if (type2 instanceof SoapObject) {
            SoapObject so = (SoapObject) type2;
            return new Object[]{so.getNamespace(), so.getName(), null, null};
        } else if (type2 instanceof SoapPrimitive) {
            SoapPrimitive sp = (SoapPrimitive) type2;
            return new Object[]{sp.getNamespace(), sp.getName(), null, DEFAULT_MARSHAL};
        } else {
            if ((type2 instanceof Class) && type2 != PropertyInfo.OBJECT_CLASS) {
                Object[] tmp = (Object[]) this.classToQName.get(type2.getName());
                if (tmp != null) {
                    return tmp;
                }
            }
            return new Object[]{this.xsd, ANY_TYPE_LABEL, null, null};
        }
    }

    public void addMapping(String namespace, String name, Class clazz, Marshal marshal) {
        Object obj;
        Hashtable hashtable = this.qNameToClass;
        SoapPrimitive soapPrimitive = new SoapPrimitive(namespace, name, null);
        if (marshal == null) {
            obj = clazz;
        } else {
            Marshal marshal2 = marshal;
        }
        hashtable.put(soapPrimitive, obj);
        this.classToQName.put(clazz.getName(), new Object[]{namespace, name, QNAME_NAMESPACE, marshal});
    }

    public void addMapping(String namespace, String name, Class clazz) {
        addMapping(namespace, name, clazz, null);
    }

    public void addTemplate(SoapObject so) {
        this.qNameToClass.put(new SoapPrimitive(so.namespace, so.name, null), so);
    }

    public Object getResponse() throws SoapFault {
        if (this.bodyIn instanceof SoapFault) {
            throw ((SoapFault) this.bodyIn);
        }
        KvmSerializable ks = this.bodyIn;
        if (ks.getPropertyCount() == 0) {
            return null;
        }
        if (ks.getPropertyCount() == QNAME_TYPE) {
            return ks.getProperty(QNAME_NAMESPACE);
        }
        Vector ret = new Vector();
        for (int i = QNAME_NAMESPACE; i < ks.getPropertyCount(); i += QNAME_TYPE) {
            ret.add(ks.getProperty(i));
        }
        return ret;
    }

    public Object getResult() {
        KvmSerializable ks = this.bodyIn;
        return ks.getPropertyCount() == 0 ? null : ks.getProperty(QNAME_NAMESPACE);
    }

    public void writeBody(XmlSerializer writer) throws IOException {
        String str;
        String str2;
        String str3 = StringUtils.EMPTY;
        this.multiRef = new Vector();
        this.multiRef.addElement(this.bodyOut);
        Object[] qName = getInfo(null, this.bodyOut);
        if (this.dotNet) {
            str = StringUtils.EMPTY;
            str2 = str3;
        } else {
            str2 = (String) qName[QNAME_NAMESPACE];
        }
        writer.startTag(str2, (String) qName[QNAME_TYPE]);
        if (this.dotNet) {
            writer.attribute(null, "xmlns", (String) qName[QNAME_NAMESPACE]);
        }
        if (this.addAdornments) {
            writer.attribute(null, ID_LABEL, qName[2] == null ? "o0" : (String) qName[2]);
            writer.attribute(this.enc, ROOT_LABEL, "1");
        }
        writeElement(writer, this.bodyOut, null, qName[QNAME_MARSHAL]);
        if (this.dotNet) {
            str = StringUtils.EMPTY;
            str = str3;
        } else {
            str = (String) qName[QNAME_NAMESPACE];
        }
        writer.endTag(str, (String) qName[QNAME_TYPE]);
    }

    public void writeObjectBody(XmlSerializer writer, SoapObject obj) throws IOException {
        SoapObject soapObject = obj;
        for (int counter = QNAME_NAMESPACE; counter < soapObject.getAttributeCount(); counter += QNAME_TYPE) {
            AttributeInfo attributeInfo = new AttributeInfo();
            soapObject.getAttributeInfo(counter, attributeInfo);
            writer.attribute(attributeInfo.getNamespace(), attributeInfo.getName(), attributeInfo.getValue().toString());
        }
        writeObjectBody(writer, (KvmSerializable) obj);
    }

    public void writeObjectBody(XmlSerializer writer, KvmSerializable obj) throws IOException {
        PropertyInfo info = new PropertyInfo();
        int cnt = obj.getPropertyCount();
        for (int i = QNAME_NAMESPACE; i < cnt; i += QNAME_TYPE) {
            obj.getPropertyInfo(i, this.properties, info);
            if ((info.flags & QNAME_TYPE) == 0) {
                writer.startTag(info.namespace, info.name);
                writeProperty(writer, obj.getProperty(i), info);
                writer.endTag(info.namespace, info.name);
            }
        }
    }

    protected void writeProperty(XmlSerializer writer, Object obj, PropertyInfo type) throws IOException {
        if (obj == null) {
            String str;
            String str2 = this.xsi;
            if (this.version >= SoapEnvelope.VER12) {
                str = NIL_LABEL;
            } else {
                str = NULL_LABEL;
            }
            writer.attribute(str2, str, "true");
            return;
        }
        Object[] qName = getInfo(null, obj);
        if (type.multiRef || qName[2] != null) {
            int i = this.multiRef.indexOf(obj);
            if (i == -1) {
                i = this.multiRef.size();
                this.multiRef.addElement(obj);
            }
            writer.attribute(null, HREF_LABEL, qName[2] == null ? new StringBuffer().append("#o").append(i).toString() : new StringBuffer().append("#").append(qName[2]).toString());
            return;
        }
        if (!(this.implicitTypes && obj.getClass() == type.type)) {
            writer.attribute(this.xsi, TYPE_LABEL, new StringBuffer().append(writer.getPrefix((String) qName[QNAME_NAMESPACE], true)).append(":").append(qName[QNAME_TYPE]).toString());
        }
        writeElement(writer, obj, type, qName[QNAME_MARSHAL]);
    }

    private void writeElement(XmlSerializer writer, Object element, PropertyInfo type, Object marshal) throws IOException {
        if (marshal != null) {
            ((Marshal) marshal).writeInstance(writer, element);
        } else if (element instanceof SoapObject) {
            writeObjectBody(writer, (SoapObject) element);
        } else if (element instanceof KvmSerializable) {
            writeObjectBody(writer, (KvmSerializable) element);
        } else if (element instanceof Vector) {
            writeVectorBody(writer, (Vector) element, type.elementType);
        } else {
            throw new RuntimeException(new StringBuffer().append("Cannot serialize: ").append(element).toString());
        }
    }

    protected void writeVectorBody(XmlSerializer writer, Vector vector, PropertyInfo elementType) throws IOException {
        String itemsTagName = ITEM_LABEL;
        String itemsNamespace = null;
        if (elementType == null) {
            elementType = PropertyInfo.OBJECT_TYPE;
        } else if ((elementType instanceof PropertyInfo) && elementType.name != null) {
            itemsTagName = elementType.name;
            itemsNamespace = elementType.namespace;
        }
        int cnt = vector.size();
        Object[] arrType = getInfo(elementType.type, null);
        writer.attribute(this.enc, ARRAY_TYPE_LABEL, new StringBuffer().append(writer.getPrefix((String) arrType[QNAME_NAMESPACE], false)).append(":").append(arrType[QNAME_TYPE]).append("[").append(cnt).append("]").toString());
        boolean skipped = false;
        for (int i = QNAME_NAMESPACE; i < cnt; i += QNAME_TYPE) {
            if (vector.elementAt(i) == null) {
                skipped = true;
            } else {
                writer.startTag(itemsNamespace, itemsTagName);
                if (skipped) {
                    writer.attribute(this.enc, "position", new StringBuffer().append("[").append(i).append("]").toString());
                    skipped = false;
                }
                writeProperty(writer, vector.elementAt(i), elementType);
                writer.endTag(itemsNamespace, itemsTagName);
            }
        }
    }
}
