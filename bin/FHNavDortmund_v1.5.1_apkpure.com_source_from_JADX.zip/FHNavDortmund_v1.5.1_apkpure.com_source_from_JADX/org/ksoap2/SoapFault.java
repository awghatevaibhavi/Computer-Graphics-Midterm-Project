package org.ksoap2;

import java.io.IOException;
import org.apache.commons.lang.StringUtils;
import org.kxml2.kdom.Node;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

public class SoapFault extends IOException {
    public Node detail;
    public String faultactor;
    public String faultcode;
    public String faultstring;

    public void parse(XmlPullParser parser) throws IOException, XmlPullParserException {
        String str = SoapEnvelope.ENV;
        String str2 = "Fault";
        String str3 = SoapEnvelope.ENV;
        str3 = "Fault";
        parser.require(2, str, str2);
        while (parser.nextTag() == 2) {
            String name = parser.getName();
            if (name.equals("detail")) {
                this.detail = new Node();
                this.detail.parse(parser);
                str3 = parser.getNamespace();
                String str4 = SoapEnvelope.ENV;
                if (str3.equals(str)) {
                    str4 = "Fault";
                    if (parser.getName().equals(str2)) {
                        break;
                    }
                } else {
                    continue;
                }
            } else {
                if (name.equals("faultcode")) {
                    this.faultcode = parser.nextText();
                } else if (name.equals("faultstring")) {
                    this.faultstring = parser.nextText();
                } else if (name.equals("faultactor")) {
                    this.faultactor = parser.nextText();
                } else {
                    throw new RuntimeException(new StringBuffer().append("unexpected tag:").append(name).toString());
                }
                parser.require(3, null, name);
            }
        }
        str3 = SoapEnvelope.ENV;
        str3 = "Fault";
        parser.require(3, str, str2);
        parser.nextTag();
    }

    public void write(XmlSerializer xw) throws IOException {
        String str = "faultcode";
        String str2 = "detail";
        String str3 = "Fault";
        String str4 = StringUtils.EMPTY;
        String str5 = "Fault";
        xw.startTag(SoapEnvelope.ENV, str3);
        String str6 = "faultcode";
        xw.startTag(null, str);
        StringBuffer stringBuffer = new StringBuffer();
        str5 = StringUtils.EMPTY;
        xw.text(stringBuffer.append(str4).append(this.faultcode).toString());
        str6 = "faultcode";
        xw.endTag(null, str);
        xw.startTag(null, "faultstring");
        stringBuffer = new StringBuffer();
        str5 = StringUtils.EMPTY;
        xw.text(stringBuffer.append(str4).append(this.faultstring).toString());
        xw.endTag(null, "faultstring");
        str6 = "detail";
        xw.startTag(null, str2);
        if (this.detail != null) {
            this.detail.write(xw);
        }
        str6 = "detail";
        xw.endTag(null, str2);
        str5 = "Fault";
        xw.endTag(SoapEnvelope.ENV, str3);
    }

    public String getMessage() {
        return this.faultstring;
    }

    public String toString() {
        return new StringBuffer().append("SoapFault - faultcode: '").append(this.faultcode).append("' faultstring: '").append(this.faultstring).append("' faultactor: '").append(this.faultactor).append("' detail: ").append(this.detail).toString();
    }
}
