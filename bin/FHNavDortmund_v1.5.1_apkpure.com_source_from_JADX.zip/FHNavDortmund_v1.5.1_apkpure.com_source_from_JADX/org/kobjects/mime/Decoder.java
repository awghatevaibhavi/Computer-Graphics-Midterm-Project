package org.kobjects.mime;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Hashtable;

public class Decoder {
    String boundary;
    char[] buf;
    String characterEncoding;
    boolean consumed;
    boolean eof;
    Hashtable header;
    InputStream is;

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final java.lang.String readLine() throws java.io.IOException {
        /*
        r8 = this;
        r7 = -1;
        r6 = 0;
        r0 = 0;
    L_0x0003:
        r4 = r8.is;
        r2 = r4.read();
        if (r2 != r7) goto L_0x000f;
    L_0x000b:
        if (r0 != 0) goto L_0x000f;
    L_0x000d:
        r4 = 0;
    L_0x000e:
        return r4;
    L_0x000f:
        if (r2 == r7) goto L_0x0015;
    L_0x0011:
        r4 = 10;
        if (r2 != r4) goto L_0x001d;
    L_0x0015:
        r4 = new java.lang.String;
        r5 = r8.buf;
        r4.<init>(r5, r6, r0);
        goto L_0x000e;
    L_0x001d:
        r4 = 13;
        if (r2 == r4) goto L_0x0003;
    L_0x0021:
        r4 = r8.buf;
        r4 = r4.length;
        if (r0 < r4) goto L_0x0039;
    L_0x0026:
        r4 = r8.buf;
        r4 = r4.length;
        r4 = r4 * 3;
        r4 = r4 / 2;
        r3 = new char[r4];
        r4 = r8.buf;
        r5 = r8.buf;
        r5 = r5.length;
        java.lang.System.arraycopy(r4, r6, r3, r6, r5);
        r8.buf = r3;
    L_0x0039:
        r4 = r8.buf;
        r1 = r0 + 1;
        r5 = (char) r2;
        r4[r0] = r5;
        r0 = r1;
        goto L_0x0003;
        */
        throw new UnsupportedOperationException("Method not decompiled: org.kobjects.mime.Decoder.readLine():java.lang.String");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.util.Hashtable getHeaderElements(java.lang.String r10) {
        /*
        r9 = 59;
        r8 = 34;
        r7 = -1;
        r1 = "";
        r3 = 0;
        r4 = new java.util.Hashtable;
        r4.<init>();
        r2 = r10.length();
    L_0x0011:
        if (r3 >= r2) goto L_0x001e;
    L_0x0013:
        r5 = r10.charAt(r3);
        r6 = 32;
        if (r5 > r6) goto L_0x001e;
    L_0x001b:
        r3 = r3 + 1;
        goto L_0x0011;
    L_0x001e:
        if (r3 < r2) goto L_0x0021;
    L_0x0020:
        return r4;
    L_0x0021:
        r5 = r10.charAt(r3);
        if (r5 != r8) goto L_0x0075;
    L_0x0027:
        r3 = r3 + 1;
        r0 = r10.indexOf(r8, r3);
        if (r0 != r7) goto L_0x0048;
    L_0x002f:
        r5 = new java.lang.RuntimeException;
        r6 = new java.lang.StringBuilder;
        r6.<init>();
        r7 = "End quote expected in ";
        r6 = r6.append(r7);
        r6 = r6.append(r10);
        r6 = r6.toString();
        r5.<init>(r6);
        throw r5;
    L_0x0048:
        r5 = r10.substring(r3, r0);
        r4.put(r1, r5);
        r3 = r0 + 2;
        if (r3 >= r2) goto L_0x0020;
    L_0x0053:
        r5 = 1;
        r5 = r3 - r5;
        r5 = r10.charAt(r5);
        if (r5 == r9) goto L_0x008c;
    L_0x005c:
        r5 = new java.lang.RuntimeException;
        r6 = new java.lang.StringBuilder;
        r6.<init>();
        r7 = "; expected in ";
        r6 = r6.append(r7);
        r6 = r6.append(r10);
        r6 = r6.toString();
        r5.<init>(r6);
        throw r5;
    L_0x0075:
        r0 = r10.indexOf(r9, r3);
        if (r0 != r7) goto L_0x0083;
    L_0x007b:
        r5 = r10.substring(r3);
        r4.put(r1, r5);
        goto L_0x0020;
    L_0x0083:
        r5 = r10.substring(r3, r0);
        r4.put(r1, r5);
        r3 = r0 + 1;
    L_0x008c:
        r5 = 61;
        r0 = r10.indexOf(r5, r3);
        if (r0 == r7) goto L_0x0020;
    L_0x0094:
        r5 = r10.substring(r3, r0);
        r5 = r5.toLowerCase();
        r1 = r5.trim();
        r3 = r0 + 1;
        goto L_0x0011;
        */
        throw new UnsupportedOperationException("Method not decompiled: org.kobjects.mime.Decoder.getHeaderElements(java.lang.String):java.util.Hashtable");
    }

    public Decoder(InputStream is, String _bound) throws IOException {
        this(is, _bound, null);
    }

    public Decoder(InputStream is, String _bound, String characterEncoding) throws IOException {
        String str = "--";
        this.buf = new char[256];
        this.characterEncoding = characterEncoding;
        this.is = is;
        String str2 = "--";
        this.boundary = str + _bound;
        String line;
        do {
            line = readLine();
            if (line == null) {
                throw new IOException("Unexpected EOF");
            }
        } while (!line.startsWith(this.boundary));
        String str3 = "--";
        if (line.endsWith(str)) {
            this.eof = true;
            is.close();
        }
        this.consumed = true;
    }

    public Enumeration getHeaderNames() {
        return this.header.keys();
    }

    public String getHeader(String key) {
        return (String) this.header.get(key.toLowerCase());
    }

    public String readContent() throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        readContent(bos);
        String result = this.characterEncoding == null ? new String(bos.toByteArray()) : new String(bos.toByteArray(), this.characterEncoding);
        System.out.println("Field content: '" + result + "'");
        return result;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void readContent(java.io.OutputStream r13) throws java.io.IOException {
        /*
        r12 = this;
        r10 = 0;
        r9 = 1;
        r11 = "Unexpected EOF";
        r7 = r12.consumed;
        if (r7 == 0) goto L_0x0010;
    L_0x0008:
        r7 = new java.lang.RuntimeException;
        r8 = "Content already consumed!";
        r7.<init>(r8);
        throw r7;
    L_0x0010:
        r5 = "";
        r7 = "Content-Type";
        r1 = r12.getHeader(r7);
        r7 = "base64";
        r8 = "Content-Transfer-Encoding";
        r8 = r12.getHeader(r8);
        r7 = r7.equals(r8);
        if (r7 == 0) goto L_0x0052;
    L_0x0026:
        r0 = new java.io.ByteArrayOutputStream;
        r0.<init>();
    L_0x002b:
        r5 = r12.readLine();
        if (r5 != 0) goto L_0x0039;
    L_0x0031:
        r7 = new java.io.IOException;
        r8 = "Unexpected EOF";
        r7.<init>(r11);
        throw r7;
    L_0x0039:
        r7 = r12.boundary;
        r7 = r5.startsWith(r7);
        if (r7 == 0) goto L_0x004e;
    L_0x0041:
        r7 = "--";
        r7 = r5.endsWith(r7);
        if (r7 == 0) goto L_0x004b;
    L_0x0049:
        r12.eof = r9;
    L_0x004b:
        r12.consumed = r9;
        return;
    L_0x004e:
        org.kobjects.base64.Base64.decode(r5, r13);
        goto L_0x002b;
    L_0x0052:
        r7 = new java.lang.StringBuilder;
        r7.<init>();
        r8 = "\r\n";
        r7 = r7.append(r8);
        r8 = r12.boundary;
        r7 = r7.append(r8);
        r2 = r7.toString();
        r6 = 0;
    L_0x0068:
        r7 = r12.is;
        r3 = r7.read();
        r7 = -1;
        if (r3 != r7) goto L_0x0079;
    L_0x0071:
        r7 = new java.lang.RuntimeException;
        r8 = "Unexpected EOF";
        r7.<init>(r11);
        throw r7;
    L_0x0079:
        r7 = (char) r3;
        r8 = r2.charAt(r6);
        if (r7 != r8) goto L_0x008d;
    L_0x0080:
        r6 = r6 + 1;
        r7 = r2.length();
        if (r6 != r7) goto L_0x0068;
    L_0x0088:
        r5 = r12.readLine();
        goto L_0x0041;
    L_0x008d:
        if (r6 <= 0) goto L_0x00a5;
    L_0x008f:
        r4 = 0;
    L_0x0090:
        if (r4 >= r6) goto L_0x009d;
    L_0x0092:
        r7 = r2.charAt(r4);
        r7 = (byte) r7;
        r13.write(r7);
        r4 = r4 + 1;
        goto L_0x0090;
    L_0x009d:
        r7 = (char) r3;
        r8 = r2.charAt(r10);
        if (r7 != r8) goto L_0x00ac;
    L_0x00a4:
        r6 = r9;
    L_0x00a5:
        if (r6 != 0) goto L_0x0068;
    L_0x00a7:
        r7 = (byte) r3;
        r13.write(r7);
        goto L_0x0068;
    L_0x00ac:
        r6 = r10;
        goto L_0x00a5;
        */
        throw new UnsupportedOperationException("Method not decompiled: org.kobjects.mime.Decoder.readContent(java.io.OutputStream):void");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean next() throws java.io.IOException {
        /*
        r6 = this;
        r5 = 0;
        r2 = r6.consumed;
        if (r2 != 0) goto L_0x0009;
    L_0x0005:
        r2 = 0;
        r6.readContent(r2);
    L_0x0009:
        r2 = r6.eof;
        if (r2 == 0) goto L_0x000f;
    L_0x000d:
        r2 = r5;
    L_0x000e:
        return r2;
    L_0x000f:
        r2 = new java.util.Hashtable;
        r2.<init>();
        r6.header = r2;
    L_0x0016:
        r1 = r6.readLine();
        if (r1 == 0) goto L_0x0024;
    L_0x001c:
        r2 = "";
        r2 = r1.equals(r2);
        if (r2 == 0) goto L_0x0028;
    L_0x0024:
        r6.consumed = r5;
        r2 = 1;
        goto L_0x000e;
    L_0x0028:
        r2 = 58;
        r0 = r1.indexOf(r2);
        r2 = -1;
        if (r0 != r2) goto L_0x004a;
    L_0x0031:
        r2 = new java.io.IOException;
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r4 = "colon missing in multipart header line: ";
        r3 = r3.append(r4);
        r3 = r3.append(r1);
        r3 = r3.toString();
        r2.<init>(r3);
        throw r2;
    L_0x004a:
        r2 = r6.header;
        r3 = r1.substring(r5, r0);
        r3 = r3.trim();
        r3 = r3.toLowerCase();
        r4 = r0 + 1;
        r4 = r1.substring(r4);
        r4 = r4.trim();
        r2.put(r3, r4);
        goto L_0x0016;
        */
        throw new UnsupportedOperationException("Method not decompiled: org.kobjects.mime.Decoder.next():boolean");
    }
}
