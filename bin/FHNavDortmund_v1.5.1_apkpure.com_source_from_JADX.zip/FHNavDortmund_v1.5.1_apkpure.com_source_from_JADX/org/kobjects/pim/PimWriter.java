package org.kobjects.pim;

import java.io.IOException;
import java.io.Writer;
import java.util.Enumeration;

public class PimWriter {
    Writer writer;

    public PimWriter(Writer writer) {
        this.writer = writer;
    }

    public void writeEntry(PimItem item) throws IOException {
        String str = "\r\n";
        this.writer.write("begin:");
        this.writer.write(item.getType());
        String str2 = "\r\n";
        this.writer.write(str);
        Enumeration e = item.fieldNames();
        while (e.hasMoreElements()) {
            String name = (String) e.nextElement();
            for (int i = 0; i < item.getFieldCount(name); i++) {
                PimField field = item.getField(name, i);
                this.writer.write(name);
                this.writer.write(58);
                this.writer.write(field.getValue().toString());
                str2 = "\r\n";
                this.writer.write(str);
            }
        }
        this.writer.write("end:");
        this.writer.write(item.getType());
        this.writer.write("\r\n\r\n");
    }
}
