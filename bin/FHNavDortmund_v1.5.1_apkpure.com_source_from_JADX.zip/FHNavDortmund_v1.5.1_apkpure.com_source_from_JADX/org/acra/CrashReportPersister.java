package org.acra;

import android.content.Context;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Map.Entry;
import org.acra.collector.CrashReportData;
import org.kxml2.kdom.Node;

final class CrashReportPersister {
    private static final int CONTINUE = 3;
    private static final int IGNORE = 5;
    private static final int KEY_DONE = 4;
    private static final String LINE_SEPARATOR = "\n";
    private static final int NONE = 0;
    private static final int SLASH = 1;
    private static final int UNICODE = 2;
    private final Context context;

    CrashReportPersister(Context context) {
        this.context = context;
    }

    public CrashReportData load(String fileName) throws IOException {
        FileInputStream in = this.context.openFileInput(fileName);
        if (in == null) {
            throw new IllegalArgumentException("Invalid crash report fileName : " + fileName);
        }
        try {
            CrashReportData load;
            BufferedInputStream bis = new BufferedInputStream(in, ACRAConstants.DEFAULT_BUFFER_SIZE_IN_BYTES);
            bis.mark(Integer.MAX_VALUE);
            boolean isEbcdic = isEbcdic(bis);
            bis.reset();
            if (isEbcdic) {
                load = load(new InputStreamReader(bis));
                in.close();
            } else {
                load = load(new InputStreamReader(bis, "ISO8859-1"));
            }
            return load;
        } finally {
            in.close();
        }
    }

    public void store(CrashReportData crashData, String fileName) throws IOException {
        OutputStream out = this.context.openFileOutput(fileName, NONE);
        try {
            StringBuilder buffer = new StringBuilder(200);
            OutputStreamWriter writer = new OutputStreamWriter(out, "ISO8859_1");
            for (Entry<ReportField, String> entry : crashData.entrySet()) {
                dumpString(buffer, ((ReportField) entry.getKey()).toString(), true);
                buffer.append('=');
                dumpString(buffer, (String) entry.getValue(), false);
                buffer.append(LINE_SEPARATOR);
                writer.write(buffer.toString());
                buffer.setLength(NONE);
            }
            writer.flush();
        } finally {
            out.close();
        }
    }

    private boolean isEbcdic(BufferedInputStream in) throws IOException {
        byte b;
        do {
            b = (byte) in.read();
            if (b == -1) {
                return false;
            }
            if (b == 35 || b == 10 || b == 61) {
                return false;
            }
        } while (b != 21);
        return true;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private synchronized org.acra.collector.CrashReportData load(java.io.Reader r25) throws java.io.IOException {
        /*
        r24 = this;
        monitor-enter(r24);
        r14 = 0;
        r20 = 0;
        r7 = 0;
        r22 = 40;
        r0 = r22;
        r0 = new char[r0];	 Catch:{ all -> 0x0044 }
        r6 = r0;
        r17 = 0;
        r13 = -1;
        r10 = 1;
        r8 = new org.acra.collector.CrashReportData;	 Catch:{ all -> 0x0044 }
        r8.<init>();	 Catch:{ all -> 0x0044 }
        r5 = new java.io.BufferedReader;	 Catch:{ all -> 0x0044 }
        r22 = 8192; // 0x2000 float:1.14794E-41 double:4.0474E-320;
        r0 = r5;
        r1 = r25;
        r2 = r22;
        r0.<init>(r1, r2);	 Catch:{ all -> 0x0044 }
        r18 = r17;
    L_0x0023:
        r11 = r5.read();	 Catch:{ all -> 0x0044 }
        r22 = -1;
        r0 = r11;
        r1 = r22;
        if (r0 != r1) goto L_0x0047;
    L_0x002e:
        r22 = 2;
        r0 = r14;
        r1 = r22;
        if (r0 != r1) goto L_0x01c5;
    L_0x0035:
        r22 = 4;
        r0 = r7;
        r1 = r22;
        if (r0 > r1) goto L_0x01c5;
    L_0x003c:
        r22 = new java.lang.IllegalArgumentException;	 Catch:{ all -> 0x0044 }
        r23 = "luni.08";
        r22.<init>(r23);	 Catch:{ all -> 0x0044 }
        throw r22;	 Catch:{ all -> 0x0044 }
    L_0x0044:
        r22 = move-exception;
        monitor-exit(r24);
        throw r22;
    L_0x0047:
        r0 = r11;
        r0 = (char) r0;
        r16 = r0;
        r0 = r6;
        r0 = r0.length;	 Catch:{ all -> 0x0044 }
        r22 = r0;
        r0 = r18;
        r1 = r22;
        if (r0 != r1) goto L_0x0070;
    L_0x0055:
        r0 = r6;
        r0 = r0.length;	 Catch:{ all -> 0x0044 }
        r22 = r0;
        r22 = r22 * 2;
        r0 = r22;
        r0 = new char[r0];	 Catch:{ all -> 0x0044 }
        r15 = r0;
        r22 = 0;
        r23 = 0;
        r0 = r6;
        r1 = r22;
        r2 = r15;
        r3 = r23;
        r4 = r18;
        java.lang.System.arraycopy(r0, r1, r2, r3, r4);	 Catch:{ all -> 0x0044 }
        r6 = r15;
    L_0x0070:
        r22 = 2;
        r0 = r14;
        r1 = r22;
        if (r0 != r1) goto L_0x00bf;
    L_0x0077:
        r22 = 16;
        r0 = r16;
        r1 = r22;
        r9 = java.lang.Character.digit(r0, r1);	 Catch:{ all -> 0x0044 }
        if (r9 < 0) goto L_0x00ae;
    L_0x0083:
        r22 = r20 << 4;
        r20 = r22 + r9;
        r7 = r7 + 1;
        r22 = 4;
        r0 = r7;
        r1 = r22;
        if (r0 < r1) goto L_0x0023;
    L_0x0090:
        r14 = 0;
        r17 = r18 + 1;
        r0 = r20;
        r0 = (char) r0;	 Catch:{ all -> 0x0044 }
        r22 = r0;
        r6[r18] = r22;	 Catch:{ all -> 0x0044 }
        r22 = 10;
        r0 = r16;
        r1 = r22;
        if (r0 == r1) goto L_0x00bd;
    L_0x00a2:
        r22 = 133; // 0x85 float:1.86E-43 double:6.57E-322;
        r0 = r16;
        r1 = r22;
        if (r0 == r1) goto L_0x00bd;
    L_0x00aa:
        r18 = r17;
        goto L_0x0023;
    L_0x00ae:
        r22 = 4;
        r0 = r7;
        r1 = r22;
        if (r0 > r1) goto L_0x0090;
    L_0x00b5:
        r22 = new java.lang.IllegalArgumentException;	 Catch:{ all -> 0x0044 }
        r23 = "luni.09";
        r22.<init>(r23);	 Catch:{ all -> 0x0044 }
        throw r22;	 Catch:{ all -> 0x0044 }
    L_0x00bd:
        r18 = r17;
    L_0x00bf:
        r22 = 1;
        r0 = r14;
        r1 = r22;
        if (r0 != r1) goto L_0x00f8;
    L_0x00c6:
        r14 = 0;
        switch(r16) {
            case 10: goto L_0x00e0;
            case 13: goto L_0x00dd;
            case 98: goto L_0x00e3;
            case 102: goto L_0x00e6;
            case 110: goto L_0x00e9;
            case 114: goto L_0x00ec;
            case 116: goto L_0x00ef;
            case 117: goto L_0x00f2;
            case 133: goto L_0x00e0;
            default: goto L_0x00ca;
        };	 Catch:{ all -> 0x0044 }
    L_0x00ca:
        r10 = 0;
        r22 = 4;
        r0 = r14;
        r1 = r22;
        if (r0 != r1) goto L_0x00d5;
    L_0x00d2:
        r13 = r18;
        r14 = 0;
    L_0x00d5:
        r17 = r18 + 1;
        r6[r18] = r16;	 Catch:{ all -> 0x0044 }
        r18 = r17;
        goto L_0x0023;
    L_0x00dd:
        r14 = 3;
        goto L_0x0023;
    L_0x00e0:
        r14 = 5;
        goto L_0x0023;
    L_0x00e3:
        r16 = 8;
        goto L_0x00ca;
    L_0x00e6:
        r16 = 12;
        goto L_0x00ca;
    L_0x00e9:
        r16 = 10;
        goto L_0x00ca;
    L_0x00ec:
        r16 = 13;
        goto L_0x00ca;
    L_0x00ef:
        r16 = 9;
        goto L_0x00ca;
    L_0x00f2:
        r14 = 2;
        r7 = 0;
        r20 = r7;
        goto L_0x0023;
    L_0x00f8:
        switch(r16) {
            case 10: goto L_0x014c;
            case 13: goto L_0x0156;
            case 33: goto L_0x0121;
            case 35: goto L_0x0121;
            case 58: goto L_0x01a8;
            case 61: goto L_0x01a8;
            case 92: goto L_0x019c;
            case 133: goto L_0x0156;
            default: goto L_0x00fb;
        };	 Catch:{ all -> 0x0044 }
    L_0x00fb:
        r22 = java.lang.Character.isWhitespace(r16);	 Catch:{ all -> 0x0044 }
        if (r22 == 0) goto L_0x01b4;
    L_0x0101:
        r22 = 3;
        r0 = r14;
        r1 = r22;
        if (r0 != r1) goto L_0x0109;
    L_0x0108:
        r14 = 5;
    L_0x0109:
        if (r18 == 0) goto L_0x0023;
    L_0x010b:
        r0 = r18;
        r1 = r13;
        if (r0 == r1) goto L_0x0023;
    L_0x0110:
        r22 = 5;
        r0 = r14;
        r1 = r22;
        if (r0 == r1) goto L_0x0023;
    L_0x0117:
        r22 = -1;
        r0 = r13;
        r1 = r22;
        if (r0 != r1) goto L_0x01b4;
    L_0x011e:
        r14 = 4;
        goto L_0x0023;
    L_0x0121:
        if (r10 == 0) goto L_0x00fb;
    L_0x0123:
        r11 = r5.read();	 Catch:{ all -> 0x0044 }
        r22 = -1;
        r0 = r11;
        r1 = r22;
        if (r0 == r1) goto L_0x0023;
    L_0x012e:
        r0 = r11;
        r0 = (char) r0;	 Catch:{ all -> 0x0044 }
        r16 = r0;
        r22 = 13;
        r0 = r16;
        r1 = r22;
        if (r0 == r1) goto L_0x0023;
    L_0x013a:
        r22 = 10;
        r0 = r16;
        r1 = r22;
        if (r0 == r1) goto L_0x0023;
    L_0x0142:
        r22 = 133; // 0x85 float:1.86E-43 double:6.57E-322;
        r0 = r16;
        r1 = r22;
        if (r0 != r1) goto L_0x0123;
    L_0x014a:
        goto L_0x0023;
    L_0x014c:
        r22 = 3;
        r0 = r14;
        r1 = r22;
        if (r0 != r1) goto L_0x0156;
    L_0x0153:
        r14 = 5;
        goto L_0x0023;
    L_0x0156:
        r14 = 0;
        r10 = 1;
        if (r18 > 0) goto L_0x015e;
    L_0x015a:
        if (r18 != 0) goto L_0x0195;
    L_0x015c:
        if (r13 != 0) goto L_0x0195;
    L_0x015e:
        r22 = -1;
        r0 = r13;
        r1 = r22;
        if (r0 != r1) goto L_0x0167;
    L_0x0165:
        r13 = r18;
    L_0x0167:
        r19 = new java.lang.String;	 Catch:{ all -> 0x0044 }
        r22 = 0;
        r0 = r19;
        r1 = r6;
        r2 = r22;
        r3 = r18;
        r0.<init>(r1, r2, r3);	 Catch:{ all -> 0x0044 }
        r22 = org.acra.ReportField.class;
        r23 = 0;
        r0 = r19;
        r1 = r23;
        r2 = r13;
        r23 = r0.substring(r1, r2);	 Catch:{ all -> 0x0044 }
        r22 = java.lang.Enum.valueOf(r22, r23);	 Catch:{ all -> 0x0044 }
        r0 = r19;
        r1 = r13;
        r23 = r0.substring(r1);	 Catch:{ all -> 0x0044 }
        r0 = r8;
        r1 = r22;
        r2 = r23;
        r0.put(r1, r2);	 Catch:{ all -> 0x0044 }
    L_0x0195:
        r13 = -1;
        r17 = 0;
        r18 = r17;
        goto L_0x0023;
    L_0x019c:
        r22 = 4;
        r0 = r14;
        r1 = r22;
        if (r0 != r1) goto L_0x01a5;
    L_0x01a3:
        r13 = r18;
    L_0x01a5:
        r14 = 1;
        goto L_0x0023;
    L_0x01a8:
        r22 = -1;
        r0 = r13;
        r1 = r22;
        if (r0 != r1) goto L_0x00fb;
    L_0x01af:
        r14 = 0;
        r13 = r18;
        goto L_0x0023;
    L_0x01b4:
        r22 = 5;
        r0 = r14;
        r1 = r22;
        if (r0 == r1) goto L_0x01c2;
    L_0x01bb:
        r22 = 3;
        r0 = r14;
        r1 = r22;
        if (r0 != r1) goto L_0x00ca;
    L_0x01c2:
        r14 = 0;
        goto L_0x00ca;
    L_0x01c5:
        r22 = -1;
        r0 = r13;
        r1 = r22;
        if (r0 != r1) goto L_0x01d0;
    L_0x01cc:
        if (r18 <= 0) goto L_0x01d0;
    L_0x01ce:
        r13 = r18;
    L_0x01d0:
        if (r13 < 0) goto L_0x021f;
    L_0x01d2:
        r19 = new java.lang.String;	 Catch:{ all -> 0x0044 }
        r22 = 0;
        r0 = r19;
        r1 = r6;
        r2 = r22;
        r3 = r18;
        r0.<init>(r1, r2, r3);	 Catch:{ all -> 0x0044 }
        r22 = org.acra.ReportField.class;
        r23 = 0;
        r0 = r19;
        r1 = r23;
        r2 = r13;
        r23 = r0.substring(r1, r2);	 Catch:{ all -> 0x0044 }
        r12 = java.lang.Enum.valueOf(r22, r23);	 Catch:{ all -> 0x0044 }
        r12 = (org.acra.ReportField) r12;	 Catch:{ all -> 0x0044 }
        r0 = r19;
        r1 = r13;
        r21 = r0.substring(r1);	 Catch:{ all -> 0x0044 }
        r22 = 1;
        r0 = r14;
        r1 = r22;
        if (r0 != r1) goto L_0x0218;
    L_0x0201:
        r22 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0044 }
        r22.<init>();	 Catch:{ all -> 0x0044 }
        r0 = r22;
        r1 = r21;
        r22 = r0.append(r1);	 Catch:{ all -> 0x0044 }
        r23 = "\u0000";
        r22 = r22.append(r23);	 Catch:{ all -> 0x0044 }
        r21 = r22.toString();	 Catch:{ all -> 0x0044 }
    L_0x0218:
        r0 = r8;
        r1 = r12;
        r2 = r21;
        r0.put(r1, r2);	 Catch:{ all -> 0x0044 }
    L_0x021f:
        monitor-exit(r24);
        return r8;
        */
        throw new UnsupportedOperationException("Method not decompiled: org.acra.CrashReportPersister.load(java.io.Reader):org.acra.collector.CrashReportData");
    }

    private void dumpString(StringBuilder buffer, String string, boolean key) {
        int i = NONE;
        if (!key && NONE < string.length() && string.charAt(NONE) == ' ') {
            buffer.append("\\ ");
            i = NONE + SLASH;
        }
        while (i < string.length()) {
            char ch = string.charAt(i);
            switch (ch) {
                case Node.COMMENT /*9*/:
                    buffer.append("\\t");
                    break;
                case Node.DOCDECL /*10*/:
                    buffer.append("\\n");
                    break;
                case '\f':
                    buffer.append("\\f");
                    break;
                case '\r':
                    buffer.append("\\r");
                    break;
                default:
                    if ("\\#!=:".indexOf(ch) >= 0 || (key && ch == ' ')) {
                        buffer.append('\\');
                    }
                    if (ch >= ' ' && ch <= '~') {
                        buffer.append(ch);
                        break;
                    }
                    String hex = Integer.toHexString(ch);
                    buffer.append("\\u");
                    for (int j = NONE; j < KEY_DONE - hex.length(); j += SLASH) {
                        buffer.append("0");
                    }
                    buffer.append(hex);
                    break;
                    break;
            }
            i += SLASH;
        }
    }
}
