package org.acra.collector;

final class DropBoxCollector {
    private static final String NO_RESULT = "N/A";
    private static final String[] SYSTEM_TAGS;

    DropBoxCollector() {
    }

    static {
        SYSTEM_TAGS = new String[]{"system_app_anr", "system_app_wtf", "system_app_crash", "system_server_anr", "system_server_wtf", "system_server_crash", "BATTERY_DISCHARGE_INFO", "SYSTEM_RECOVERY_LOG", "SYSTEM_BOOT", "SYSTEM_LAST_KMSG", "APANIC_CONSOLE", "APANIC_THREADS", "SYSTEM_RESTART", "SYSTEM_TOMBSTONE", "data_app_strictmode"};
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String read(android.content.Context r18, java.lang.String[] r19) {
        /*
        r3 = org.acra.collector.Compatibility.getDropBoxServiceName();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        if (r3 != 0) goto L_0x0009;
    L_0x0006:
        r18 = "N/A";
    L_0x0008:
        return r18;
    L_0x0009:
        r0 = r18;
        r1 = r3;
        r3 = r0.getSystemService(r1);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r18 = r3.getClass();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r4 = "getNextEntry";
        r5 = 2;
        r5 = new java.lang.Class[r5];	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r6 = 0;
        r7 = java.lang.String.class;
        r5[r6] = r7;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r6 = 1;
        r7 = java.lang.Long.TYPE;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r5[r6] = r7;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r0 = r18;
        r1 = r4;
        r2 = r5;
        r5 = r0.getMethod(r1, r2);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        if (r5 != 0) goto L_0x0030;
    L_0x002d:
        r18 = "";
        goto L_0x0008;
    L_0x0030:
        r15 = new android.text.format.Time;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r15.<init>();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r15.setToNow();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r0 = r15;
        r0 = r0.minute;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r18 = r0;
        r4 = org.acra.ACRA.getConfig();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r4 = r4.dropboxCollectionMinutes();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r18 = r18 - r4;
        r0 = r18;
        r1 = r15;
        r1.minute = r0;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r18 = 0;
        r0 = r15;
        r1 = r18;
        r0.normalize(r1);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r18 = 0;
        r0 = r15;
        r1 = r18;
        r13 = r0.toMillis(r1);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r18 = new java.util.ArrayList;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r18.<init>();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r4 = org.acra.ACRA.getConfig();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r4 = r4.includeDropBoxSystemTags();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        if (r4 == 0) goto L_0x0078;
    L_0x006c:
        r4 = SYSTEM_TAGS;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r4 = java.util.Arrays.asList(r4);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r0 = r18;
        r1 = r4;
        r0.addAll(r1);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
    L_0x0078:
        if (r19 == 0) goto L_0x0087;
    L_0x007a:
        r0 = r19;
        r0 = r0.length;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r4 = r0;
        if (r4 <= 0) goto L_0x0087;
    L_0x0080:
        r19 = java.util.Arrays.asList(r19);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r18.addAll(r19);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
    L_0x0087:
        r19 = r18.isEmpty();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        if (r19 == 0) goto L_0x0091;
    L_0x008d:
        r18 = "No tag configured for collection.";
        goto L_0x0008;
    L_0x0091:
        r19 = new java.lang.StringBuilder;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r19.<init>();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r8 = r18.iterator();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
    L_0x009a:
        r18 = r8.hasNext();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        if (r18 == 0) goto L_0x01c8;
    L_0x00a0:
        r11 = r8.next();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r11 = (java.lang.String) r11;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r18 = "Tag: ";
        r0 = r19;
        r1 = r18;
        r18 = r0.append(r1);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r0 = r18;
        r1 = r11;
        r18 = r0.append(r1);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r4 = 10;
        r0 = r18;
        r1 = r4;
        r0.append(r1);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r18 = 2;
        r0 = r18;
        r0 = new java.lang.Object[r0];	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r18 = r0;
        r4 = 0;
        r18[r4] = r11;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r4 = 1;
        r6 = java.lang.Long.valueOf(r13);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r18[r4] = r6;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r0 = r5;
        r1 = r3;
        r2 = r18;
        r4 = r0.invoke(r1, r2);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        if (r4 != 0) goto L_0x00fa;
    L_0x00db:
        r18 = "Nothing.";
        r0 = r19;
        r1 = r18;
        r18 = r0.append(r1);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r4 = 10;
        r0 = r18;
        r1 = r4;
        r0.append(r1);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        goto L_0x009a;
    L_0x00ee:
        r18 = move-exception;
        r18 = org.acra.ACRA.LOG_TAG;
        r19 = "DropBoxManager not available.";
        android.util.Log.i(r18, r19);
    L_0x00f6:
        r18 = "N/A";
        goto L_0x0008;
    L_0x00fa:
        r18 = r4.getClass();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r6 = "getText";
        r7 = 1;
        r7 = new java.lang.Class[r7];	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r9 = 0;
        r10 = java.lang.Integer.TYPE;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r7[r9] = r10;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r0 = r18;
        r1 = r6;
        r2 = r7;
        r6 = r0.getMethod(r1, r2);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r7 = r4.getClass();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r9 = "getTimeMillis";
        r18 = 0;
        r18 = (java.lang.Class[]) r18;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r0 = r7;
        r1 = r9;
        r2 = r18;
        r7 = r0.getMethod(r1, r2);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r9 = r4.getClass();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r10 = "close";
        r18 = 0;
        r18 = (java.lang.Class[]) r18;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r0 = r9;
        r1 = r10;
        r2 = r18;
        r18 = r0.getMethod(r1, r2);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
    L_0x0134:
        if (r4 == 0) goto L_0x009a;
    L_0x0136:
        r9 = 0;
        r9 = (java.lang.Object[]) r9;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r9 = r7.invoke(r4, r9);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r9 = (java.lang.Long) r9;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r9 = r9.longValue();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r15.set(r9);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r12 = "@";
        r0 = r19;
        r1 = r12;
        r12 = r0.append(r1);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r16 = r15.format2445();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r0 = r12;
        r1 = r16;
        r12 = r0.append(r1);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r16 = 10;
        r0 = r12;
        r1 = r16;
        r0.append(r1);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r12 = 1;
        r12 = new java.lang.Object[r12];	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r16 = 0;
        r17 = 500; // 0x1f4 float:7.0E-43 double:2.47E-321;
        r17 = java.lang.Integer.valueOf(r17);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r12[r16] = r17;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r12 = r6.invoke(r4, r12);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r12 = (java.lang.String) r12;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        if (r12 == 0) goto L_0x01ac;
    L_0x0177:
        r16 = "Text: ";
        r0 = r19;
        r1 = r16;
        r16 = r0.append(r1);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r0 = r16;
        r1 = r12;
        r12 = r0.append(r1);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r16 = 10;
        r0 = r12;
        r1 = r16;
        r0.append(r1);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
    L_0x0190:
        r12 = 0;
        r12 = (java.lang.Object[]) r12;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r0 = r18;
        r1 = r4;
        r2 = r12;
        r0.invoke(r1, r2);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r4 = 2;
        r4 = new java.lang.Object[r4];	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r12 = 0;
        r4[r12] = r11;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r12 = 1;
        r9 = java.lang.Long.valueOf(r9);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r4[r12] = r9;	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r4 = r5.invoke(r3, r4);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        goto L_0x0134;
    L_0x01ac:
        r12 = "Not Text!";
        r0 = r19;
        r1 = r12;
        r12 = r0.append(r1);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        r16 = 10;
        r0 = r12;
        r1 = r16;
        r0.append(r1);	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        goto L_0x0190;
    L_0x01be:
        r18 = move-exception;
        r18 = org.acra.ACRA.LOG_TAG;
        r19 = "DropBoxManager not available.";
        android.util.Log.i(r18, r19);
        goto L_0x00f6;
    L_0x01c8:
        r18 = r19.toString();	 Catch:{ SecurityException -> 0x00ee, NoSuchMethodException -> 0x01be, IllegalArgumentException -> 0x01ce, IllegalAccessException -> 0x01d8, InvocationTargetException -> 0x01e2, NoSuchFieldException -> 0x01ec }
        goto L_0x0008;
    L_0x01ce:
        r18 = move-exception;
        r18 = org.acra.ACRA.LOG_TAG;
        r19 = "DropBoxManager not available.";
        android.util.Log.i(r18, r19);
        goto L_0x00f6;
    L_0x01d8:
        r18 = move-exception;
        r18 = org.acra.ACRA.LOG_TAG;
        r19 = "DropBoxManager not available.";
        android.util.Log.i(r18, r19);
        goto L_0x00f6;
    L_0x01e2:
        r18 = move-exception;
        r18 = org.acra.ACRA.LOG_TAG;
        r19 = "DropBoxManager not available.";
        android.util.Log.i(r18, r19);
        goto L_0x00f6;
    L_0x01ec:
        r18 = move-exception;
        r18 = org.acra.ACRA.LOG_TAG;
        r19 = "DropBoxManager not available.";
        android.util.Log.i(r18, r19);
        goto L_0x00f6;
        */
        throw new UnsupportedOperationException("Method not decompiled: org.acra.collector.DropBoxCollector.read(android.content.Context, java.lang.String[]):java.lang.String");
    }
}
