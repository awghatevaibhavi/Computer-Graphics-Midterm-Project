package org.acra.collector;

import android.content.Context;
import android.provider.Settings.Secure;
import android.provider.Settings.System;
import android.util.Log;
import java.lang.reflect.Field;
import org.acra.ACRA;

final class SettingsCollector {
    SettingsCollector() {
    }

    public static String collectSystemSettings(Context ctx) {
        String str;
        String str2 = "Error : ";
        StringBuilder result = new StringBuilder();
        for (Field key : System.class.getFields()) {
            if (!key.isAnnotationPresent(Deprecated.class) && key.getType() == String.class) {
                try {
                    String value = System.getString(ctx.getContentResolver(), (String) key.get(null));
                    if (value != null) {
                        result.append(key.getName()).append("=").append(value).append("\n");
                    }
                } catch (IllegalArgumentException e) {
                    str = "Error : ";
                    Log.w(ACRA.LOG_TAG, str2, e);
                } catch (IllegalAccessException e2) {
                    str = "Error : ";
                    Log.w(ACRA.LOG_TAG, str2, e2);
                }
            }
        }
        return result.toString();
    }

    public static String collectSecureSettings(Context ctx) {
        String str;
        String str2 = "Error : ";
        StringBuilder result = new StringBuilder();
        for (Field key : Secure.class.getFields()) {
            if (!key.isAnnotationPresent(Deprecated.class) && key.getType() == String.class && isAuthorized(key)) {
                try {
                    String value = Secure.getString(ctx.getContentResolver(), (String) key.get(null));
                    if (value != null) {
                        result.append(key.getName()).append("=").append(value).append("\n");
                    }
                } catch (IllegalArgumentException e) {
                    str = "Error : ";
                    Log.w(ACRA.LOG_TAG, str2, e);
                } catch (IllegalAccessException e2) {
                    str = "Error : ";
                    Log.w(ACRA.LOG_TAG, str2, e2);
                }
            }
        }
        return result.toString();
    }

    private static boolean isAuthorized(Field key) {
        if (key == null || key.getName().startsWith("WIFI_AP")) {
            return false;
        }
        return true;
    }
}
