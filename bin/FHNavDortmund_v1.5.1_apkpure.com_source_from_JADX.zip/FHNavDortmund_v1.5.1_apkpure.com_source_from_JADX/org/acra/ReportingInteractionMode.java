package org.acra;

public enum ReportingInteractionMode {
    SILENT,
    NOTIFICATION,
    TOAST,
    DIALOG
}
