package FHNav.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

public class Stundenplan implements Serializable {
    private static final long serialVersionUID = 3022166862004615344L;
    private ArrayList<Veranstaltung> veranstaltungen;

    public interface Listener {
        void onModelStateUpdated(Stundenplan stundenplan);
    }

    public Stundenplan() {
        this.veranstaltungen = new ArrayList();
    }

    public void refresh() {
        Iterator it = this.veranstaltungen.iterator();
        while (it.hasNext()) {
            ((Veranstaltung) it.next()).refresh();
        }
    }

    public void addVeranstaltung(Veranstaltung veranstaltung) {
        if (!this.veranstaltungen.contains(veranstaltung)) {
            this.veranstaltungen.add(veranstaltung);
        }
    }

    public void removeVeranstaltung(Veranstaltung veranstaltung) {
        if (this.veranstaltungen.contains(veranstaltung)) {
            this.veranstaltungen.remove(veranstaltung);
        }
    }

    public ArrayList<Veranstaltung> getVeranstaltungen() {
        return this.veranstaltungen;
    }

    public void setVeranstaltungen(ArrayList<Veranstaltung> veranstaltungen) {
        this.veranstaltungen = veranstaltungen;
    }
}
