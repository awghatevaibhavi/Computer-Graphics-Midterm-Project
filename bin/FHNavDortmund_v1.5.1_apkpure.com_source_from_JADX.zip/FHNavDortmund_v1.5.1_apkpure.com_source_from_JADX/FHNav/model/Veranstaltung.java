package FHNav.model;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.StringUtils;
import org.kxml2.kdom.Node;
import org.kxml2.wap.Wbxml;

public class Veranstaltung implements Serializable, Comparable<Veranstaltung> {
    private static final long serialVersionUID = 2879848547456847640L;
    private int dauer;
    private String dozent;
    private Date endTime;
    private String name;
    private String raum;
    private String semester;
    private int start;
    private Date startTime;
    private String studentSet;
    private String studiengang;
    private String type;
    private int wochentag;

    public Veranstaltung() {
        String str = StringUtils.EMPTY;
        String str2 = StringUtils.EMPTY;
        this.dozent = str;
        str2 = StringUtils.EMPTY;
        this.name = str;
        this.start = 0;
        this.dauer = 0;
        this.wochentag = 1;
        str2 = StringUtils.EMPTY;
        this.type = str;
        str2 = StringUtils.EMPTY;
        this.raum = str;
        str2 = StringUtils.EMPTY;
        this.studiengang = str;
        str2 = StringUtils.EMPTY;
        this.semester = str;
        str2 = StringUtils.EMPTY;
        this.studentSet = str;
        this.startTime = null;
        this.endTime = null;
    }

    public Veranstaltung(String dozent, String name, int wochentag, int start, int duration, String raum, String studiengang, String semester, String type, String studentSet) {
        String str = StringUtils.EMPTY;
        String str2 = StringUtils.EMPTY;
        this.dozent = str;
        str2 = StringUtils.EMPTY;
        this.name = str;
        this.start = 0;
        this.dauer = 0;
        this.wochentag = 1;
        str2 = StringUtils.EMPTY;
        this.type = str;
        str2 = StringUtils.EMPTY;
        this.raum = str;
        str2 = StringUtils.EMPTY;
        this.studiengang = str;
        str2 = StringUtils.EMPTY;
        this.semester = str;
        str2 = StringUtils.EMPTY;
        this.studentSet = str;
        this.startTime = null;
        this.endTime = null;
        setDozent(dozent);
        setName(name);
        setWochentag(wochentag);
        setStart(start);
        setDuration(duration);
        setRaum(raum);
        setStudiengang(studiengang);
        setSemester(semester);
        setType(type);
        setStudentSet(studentSet);
    }

    public int compareTo(Veranstaltung ver) {
        if (ver.startTime == null) {
            ver.refresh();
        }
        if (this.startTime == null) {
            refresh();
        }
        if (this == ver) {
            return 0;
        }
        if (this.wochentag < ver.wochentag) {
            return -1;
        }
        if (this.wochentag > ver.wochentag) {
            return 1;
        }
        if (this.wochentag != ver.wochentag) {
            return 0;
        }
        if (this.startTime.before(ver.startTime)) {
            return -1;
        }
        return 1;
    }

    public void refresh() {
        if (this.startTime == null) {
            setStartTime(getStartDateFromInt(this.start));
        }
        if (this.endTime == null) {
            setEndTime(getEndDateFromInt(this.start, this.dauer));
        }
    }

    public static Date getEndDateFromInt(int value, int duration) {
        Date dt = getStartDateFromInt(value + (duration - 1));
        dt.setMinutes(dt.getMinutes() + 45);
        return dt;
    }

    public static Date getStartDateFromInt(int value) {
        value++;
        Date dt = new Date();
        switch (value) {
            case Wbxml.END /*1*/:
                dt.setHours(8);
                dt.setMinutes(30);
                break;
            case Wbxml.ENTITY /*2*/:
                dt.setHours(9);
                dt.setMinutes(20);
                break;
            case Wbxml.STR_I /*3*/:
                dt.setHours(10);
                dt.setMinutes(15);
                break;
            case Wbxml.LITERAL /*4*/:
                dt.setHours(11);
                dt.setMinutes(5);
                break;
            case Node.CDSECT /*5*/:
                dt.setHours(12);
                dt.setMinutes(0);
                break;
            case Node.ENTITY_REF /*6*/:
                dt.setHours(12);
                dt.setMinutes(50);
                break;
            case Node.IGNORABLE_WHITESPACE /*7*/:
                dt.setHours(14);
                dt.setMinutes(15);
                break;
            case Node.PROCESSING_INSTRUCTION /*8*/:
                dt.setHours(15);
                dt.setMinutes(5);
                break;
            case Node.COMMENT /*9*/:
                dt.setHours(16);
                dt.setMinutes(0);
                break;
            case Node.DOCDECL /*10*/:
                dt.setHours(16);
                dt.setMinutes(50);
                break;
            case 11:
                dt.setHours(17);
                dt.setMinutes(45);
                break;
            case 12:
                dt.setHours(18);
                dt.setMinutes(35);
                break;
        }
        return dt;
    }

    public boolean equals(Object o) {
        if (o == null || !(o instanceof Veranstaltung)) {
            return false;
        }
        Veranstaltung oVeranstaltung = (Veranstaltung) o;
        if (this.raum.equals(oVeranstaltung.raum) && this.dozent.equals(oVeranstaltung.dozent) && this.name.equals(oVeranstaltung.name) && this.studiengang.equals(oVeranstaltung.studiengang) && this.type.equals(oVeranstaltung.type) && this.studentSet.equals(oVeranstaltung.studentSet) && this.wochentag == oVeranstaltung.wochentag && this.semester.equals(oVeranstaltung.semester)) {
            return true;
        }
        return false;
    }

    public String getStudentSet() {
        return this.studentSet;
    }

    public void setStudentSet(String studentSet) {
        this.studentSet = studentSet;
    }

    public int getDauer() {
        return this.dauer;
    }

    public void setDauer(int dauer) {
        this.dauer = dauer;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSemester() {
        return this.semester;
    }

    public int getWochentag() {
        return this.wochentag;
    }

    public void setWochentag(int wochentag) {
        this.wochentag = wochentag;
    }

    public int getStart() {
        return this.start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public int getDuration() {
        return this.dauer;
    }

    public void setDuration(int duration) {
        this.dauer = duration;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public String getDozent() {
        return this.dozent;
    }

    public void setDozent(String dozent) {
        this.dozent = dozent;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRaum() {
        return this.raum;
    }

    public void setRaum(String raum) {
        this.raum = raum;
    }

    public String getStudiengang() {
        return this.studiengang;
    }

    public void setStudiengang(String studiengang) {
        this.studiengang = studiengang;
    }

    public Date getStartTime() {
        return this.startTime;
    }

    public void setStartTime(Date startTime) {
        startTime.setMonth(1);
        startTime.setYear(2000);
        startTime.setDate(1);
        startTime.setSeconds(0);
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return this.endTime;
    }

    public void setEndTime(Date endTime) {
        endTime.setMonth(1);
        endTime.setYear(2000);
        endTime.setDate(1);
        endTime.setSeconds(0);
        this.endTime = endTime;
    }
}
