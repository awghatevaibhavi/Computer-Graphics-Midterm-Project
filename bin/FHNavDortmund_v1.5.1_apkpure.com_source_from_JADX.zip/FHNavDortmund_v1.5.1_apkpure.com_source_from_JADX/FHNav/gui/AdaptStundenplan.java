package FHNav.gui;

import FHNav.controller.IOManager;
import FHNav.controller.MainApplicationManager;
import FHNav.controller.Tools;
import FHNav.gui.helper.ExtendedListAdapter;
import FHNav.gui.helper.SeparatedListAdapter;
import FHNav.model.Veranstaltung;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import com.flurry.android.FlurryAgent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class AdaptStundenplan extends Activity {
    Button btn_back;
    Button btn_delete;
    Button btn_select_all;
    ListView lv1;
    boolean select;
    public SeparatedListAdapter separatedListAdapter;
    private ArrayList<Veranstaltung> veranstaltungen;

    /* renamed from: FHNav.gui.AdaptStundenplan.1 */
    class C00001 implements OnClickListener {
        C00001() {
        }

        public void onClick(View v) {
            AdaptStundenplan.this.onBackPressed();
        }
    }

    /* renamed from: FHNav.gui.AdaptStundenplan.2 */
    class C00012 implements OnClickListener {
        C00012() {
        }

        public void onClick(View v) {
            if (AdaptStundenplan.this.select) {
                AdaptStundenplan.this.select_all();
            } else {
                AdaptStundenplan.this.deselect_all();
            }
        }
    }

    /* renamed from: FHNav.gui.AdaptStundenplan.3 */
    class C00023 implements OnClickListener {
        C00023() {
        }

        public void onClick(View v) {
            String str = " ";
            ArrayList<Veranstaltung> tmpArr = new ArrayList();
            int count = 0;
            for (int i = 0; i < AdaptStundenplan.this.separatedListAdapter.sections.size(); i++) {
                ExtendedListAdapter el = AdaptStundenplan.this.separatedListAdapter.sections.values().toArray()[i];
                for (int j = 0; j < el.getChecked().size(); j++) {
                    if (((Boolean) el.getChecked().get(j)).booleanValue()) {
                        tmpArr.add((Veranstaltung) el.getItems().get(j));
                        count++;
                    }
                }
            }
            if (tmpArr.size() == 0) {
                Toast.makeText(AdaptStundenplan.this.getApplicationContext(), AdaptStundenplan.this.getString(C0026R.string.addveranstaltung_toast_text_0b), 0).show();
                return;
            }
            Iterator it = tmpArr.iterator();
            while (it.hasNext()) {
                AdaptStundenplan.this.veranstaltungen.remove((Veranstaltung) it.next());
            }
            if (count > 0) {
                MainApplicationManager.getStundenplan().setVeranstaltungen(AdaptStundenplan.this.veranstaltungen);
                IOManager.saveStundenplan(MainApplicationManager.getStundenplan(), AdaptStundenplan.this.getApplicationContext());
                AdaptStundenplan.this.deselect_all();
                AdaptStundenplan.this.build_list();
                String str2 = " ";
                str2 = " ";
                Toast.makeText(AdaptStundenplan.this.getApplicationContext(), new StringBuilder(String.valueOf(AdaptStundenplan.this.getString(C0026R.string.adaptstundenplan_toast_text_1a))).append(str).append(count).append(str).append(AdaptStundenplan.this.getString(C0026R.string.adaptstundenplan_toast_text_1b)).toString(), 0).show();
            }
        }
    }

    public AdaptStundenplan() {
        this.select = true;
    }

    public void onStart() {
        super.onStart();
        if (MainApplicationManager.isFinish()) {
            finish();
        }
        Log.e(getClass().toString(), "Start");
        FlurryAgent.onStartSession(this, "I7RRJ22MKL64Q9JLNZW8");
    }

    public void onStop() {
        super.onStop();
        FlurryAgent.onEndSession(this);
        Log.e(getClass().toString(), "Stop");
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0026R.layout.adaptstundenplan);
        this.veranstaltungen = MainApplicationManager.getVeranstaltungen();
        Collections.sort(this.veranstaltungen);
        build_list();
        this.btn_back = (Button) findViewById(C0026R.id.adaptstundenplan_back);
        this.btn_back.setOnClickListener(new C00001());
        this.btn_select_all = (Button) findViewById(C0026R.id.adaptstundenplan_select_all);
        this.btn_select_all.setOnClickListener(new C00012());
        this.btn_delete = (Button) findViewById(C0026R.id.adaptstundenplan_delete);
        this.btn_delete.setOnClickListener(new C00023());
    }

    public void select_all() {
        for (int i = 0; i < this.separatedListAdapter.sections.size(); i++) {
            this.separatedListAdapter.sections.values().toArray()[i].selectAll();
            this.separatedListAdapter.notifyDataSetChanged();
            this.select = false;
            this.btn_select_all.setText(C0026R.string.button_deselect_all_label);
        }
    }

    public void deselect_all() {
        for (int i = 0; i < this.separatedListAdapter.sections.size(); i++) {
            this.separatedListAdapter.sections.values().toArray()[i].deselectAll();
        }
        this.separatedListAdapter.notifyDataSetChanged();
        this.select = true;
        this.btn_select_all.setText(C0026R.string.button_select_all_label);
    }

    private void build_list() {
        int i;
        this.separatedListAdapter = new SeparatedListAdapter(this);
        ExtendedListAdapter[] els = new ExtendedListAdapter[7];
        for (i = 0; i < els.length; i++) {
            els[i] = new ExtendedListAdapter(this, new ArrayList());
        }
        Iterator it = this.veranstaltungen.iterator();
        while (it.hasNext()) {
            Veranstaltung ver = (Veranstaltung) it.next();
            els[ver.getWochentag() - 1].getItems().add(ver);
        }
        for (i = 0; i < els.length; i++) {
            if (els[i].getItems().size() > 0) {
                els[i].refresh();
                this.separatedListAdapter.addSection(getString(Tools.getWeekday(i + 1)), els[i]);
            }
        }
        this.lv1 = (ListView) findViewById(C0026R.id.adaptstundenplan_list);
        this.lv1.setAdapter(this.separatedListAdapter);
    }
}
