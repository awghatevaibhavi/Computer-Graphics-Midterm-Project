package FHNav.gui;

/* renamed from: FHNav.gui.R */
public final class C0026R {

    /* renamed from: FHNav.gui.R.attr */
    public static final class attr {
    }

    /* renamed from: FHNav.gui.R.drawable */
    public static final class drawable {
        public static final int android_button = 2130837504;
        public static final int background = 2130837505;
        public static final int basicbackground = 2130837506;
        public static final int bg2 = 2130837507;
        public static final int bgunten = 2130837508;
        public static final int bgwizard = 2130837509;
        public static final int ergeschoss = 2130837510;
        public static final int ic_menu_refresh = 2130837511;
        public static final int ic_tab_template = 2130837512;
        public static final int ic_tab_template2 = 2130837513;
        public static final int icon = 2130837514;
        public static final int logo2 = 2130837515;
        public static final int nadel = 2130837516;
        public static final int nadel2 = 2130837517;
        public static final int ziel = 2130837518;
    }

    /* renamed from: FHNav.gui.R.id */
    public static final class id {
        public static final int Button01 = 2131099675;
        public static final int Button02 = 2131099676;
        public static final int Button03 = 2131099677;
        public static final int Spinner01 = 2131099653;
        public static final int TextView01 = 2131099713;
        public static final int WizardOK = 2131099714;
        public static final int adaptstundenplan_back = 2131099652;
        public static final int adaptstundenplan_delete = 2131099650;
        public static final int adaptstundenplan_list = 2131099648;
        public static final int adaptstundenplan_select_all = 2131099651;
        public static final int addveranstaltung_add = 2131099655;
        public static final int addveranstaltung_back = 2131099657;
        public static final int addveranstaltung_select_all = 2131099656;
        public static final int addvorlesung_list = 2131099654;
        public static final int alert_dialog_connection_problem_button = 2131099659;
        public static final int alert_dialog_connection_problem_buttonNext = 2131099660;
        public static final int alert_dialog_connection_problem_text1 = 2131099658;
        public static final int calendarSpinner = 2131099663;
        public static final int dateDisplayFrom = 2131099664;
        public static final int dateDisplayTo = 2131099666;
        public static final int editText = 2131099704;
        public static final int empty = 2131099674;
        public static final int exit_application = 2131099682;
        public static final int extenden_row_bottomtext = 2131099670;
        public static final int extenden_row_checkbox = 2131099668;
        public static final int extenden_row_toptext = 2131099669;
        public static final int header_calendar = 2131099662;
        public static final int imageView1 = 2131099712;
        public static final int info_application = 2131099681;
        public static final int layout_root = 2131099661;
        public static final int linearLayout1 = 2131099683;
        public static final int linearLayout1x = 2131099687;
        public static final int linearLayout2 = 2131099697;
        public static final int linearLayout3 = 2131099649;
        public static final int linearLayout4 = 2131099692;
        public static final int listView1 = 2131099673;
        public static final int list_header_title = 2131099679;
        public static final int mensa_refresh = 2131099671;
        public static final int menu_header = 2131099680;
        public static final int new_game = 2131099716;
        public static final int normal_row_bottomtext = 2131099703;
        public static final int normal_row_toptext = 2131099702;
        public static final int outDetails = 2131099705;
        public static final int own_entry_dialog_courseName_te = 2131099689;
        public static final int own_entry_dialog_prof_te = 2131099696;
        public static final int own_entry_dialog_room_te = 2131099694;
        public static final int own_entry_dialog_weekDay_Spinner = 2131099691;
        public static final int pickDateFrom = 2131099665;
        public static final int pickDateTo = 2131099667;
        public static final int pickTimeFrom = 2131099699;
        public static final int pickTimeTo = 2131099701;
        public static final int quit = 2131099717;
        public static final int scrollView1 = 2131099686;
        public static final int settings_lecture_details_groupletter_checkbox = 2131099707;
        public static final int settings_lecture_details_lecturer_checkbox = 2131099708;
        public static final int settings_lecture_details_type_checkbox = 2131099709;
        public static final int settings_restart_wizard_button = 2131099710;
        public static final int settings_text_size_spinner = 2131099706;
        public static final int spinner1 = 2131099672;
        public static final int spinnerFromRoom = 2131099684;
        public static final int spinnerTarget = 2131099711;
        public static final int spinnerToRoom = 2131099685;
        public static final int textView1 = 2131099698;
        public static final int textView2 = 2131099688;
        public static final int textView3 = 2131099690;
        public static final int textView4 = 2131099693;
        public static final int textView5 = 2131099695;
        public static final int textView6 = 2131099700;
        public static final int transfer = 2131099718;
        public static final int webView1 = 2131099678;
        public static final int wizard_refresh = 2131099715;
    }

    /* renamed from: FHNav.gui.R.layout */
    public static final class layout {
        public static final int adaptstundenplan = 2130903040;
        public static final int addvorlesung = 2130903041;
        public static final int alert_dialog_connection_problem = 2130903042;
        public static final int calendardialog = 2130903043;
        public static final int editagendarow = 2130903044;
        public static final int extras = 2130903045;
        public static final int extras2 = 2130903046;
        public static final int list_header = 2130903047;
        public static final int menu = 2130903048;
        public static final int navigation = 2130903049;
        public static final int ownentrydialog = 2130903050;
        public static final int row = 2130903051;
        public static final int row2 = 2130903052;
        public static final int settings = 2130903053;
        public static final int spinnerlayout = 2130903054;
        public static final int splashscreen = 2130903055;
        public static final int wizard = 2130903056;
    }

    /* renamed from: FHNav.gui.R.menu */
    public static final class menu {
        public static final int menu = 2131034112;
    }

    /* renamed from: FHNav.gui.R.string */
    public static final class string {
        public static final int adaptstundenplan_toast_text_1a = 2130968603;
        public static final int adaptstundenplan_toast_text_1b = 2130968604;
        public static final int add_adaptstundenplan_title = 2130968633;
        public static final int add_hauptmenue_title = 2130968629;
        public static final int add_settings_title = 2130968634;
        public static final int add_vorlesung_title = 2130968632;
        public static final int add_wizard_title = 2130968635;
        public static final int addveranstaltung_toast_text_0 = 2130968599;
        public static final int addveranstaltung_toast_text_0b = 2130968660;
        public static final int addveranstaltung_toast_text_1a = 2130968600;
        public static final int addveranstaltung_toast_text_1b = 2130968601;
        public static final int addvorlesung_spinner_text = 2130968598;
        public static final int agenda_view = 2130968631;
        public static final int alert_dialog_connection_problem_msg = 2130968596;
        public static final int alert_dialog_connection_problem_msg2 = 2130968597;
        public static final int alert_dialog_connection_problem_next_button = 2130968658;
        public static final int alert_dialog_connection_problem_next_button2 = 2130968659;
        public static final int alert_dialog_connection_problem_retry_button = 2130968657;
        public static final int alert_dialog_connection_problem_title = 2130968595;
        public static final int app_name = 2130968576;
        public static final int button_add_label = 2130968590;
        public static final int button_back_label = 2130968594;
        public static final int button_delete_label = 2130968593;
        public static final int button_deselect_all_label = 2130968592;
        public static final int button_select_all_label = 2130968591;
        public static final int calendar_transfer_toast_text_1b = 2130968602;
        public static final int canteenSpezialHeader = 2130968642;
        public static final int crash_toast_text = 2130968678;
        public static final int editmenu_add = 2130968606;
        public static final int editmenu_add_own = 2130968607;
        public static final int editmenu_change_view = 2130968605;
        public static final int editmenu_commit = 2130968609;
        public static final int editmenu_delete = 2130968608;
        public static final int empty_list = 2130968654;
        public static final int empty_list_downloading = 2130968655;
        public static final int empty_list_downloading_no = 2130968656;
        public static final int error = 2130968627;
        public static final int error_calendar = 2130968628;
        public static final int extras_button1a = 2130968638;
        public static final int extras_button1b = 2130968639;
        public static final int extras_button2 = 2130968640;
        public static final int extras_button3 = 2130968641;
        public static final int extras_title = 2130968637;
        public static final int friday = 2130968614;
        public static final int menu_edit_button = 2130968577;
        public static final int menu_empty_list = 2130968580;
        public static final int menu_extras_button = 2130968636;
        public static final int menu_navigation_button = 2130968578;
        public static final int menu_settings_button = 2130968579;
        public static final int monday = 2130968610;
        public static final int normal_view = 2130968630;
        public static final int own_entry_dialog_courseName = 2130968670;
        public static final int own_entry_dialog_failure = 2130968677;
        public static final int own_entry_dialog_header = 2130968676;
        public static final int own_entry_dialog_prof = 2130968673;
        public static final int own_entry_dialog_room = 2130968672;
        public static final int own_entry_dialog_time = 2130968674;
        public static final int own_entry_dialog_to = 2130968675;
        public static final int own_entry_dialog_weekDay = 2130968671;
        public static final int page_name_bplan = 2130968652;
        public static final int page_name_lplan = 2130968649;
        public static final int page_name_lplan2 = 2130968650;
        public static final int page_name_mensa = 2130968645;
        public static final int page_name_mensa_kostbar = 2130968647;
        public static final int page_name_news = 2130968644;
        public static final int page_name_news_W = 2130968646;
        public static final int page_name_pplan = 2130968648;
        public static final int page_name_splan = 2130968651;
        public static final int page_select_header = 2130968643;
        public static final int progess_dialog_message = 2130968589;
        public static final int saturday = 2130968615;
        public static final int settings_Back_button = 2130968662;
        public static final int settings_OK_button = 2130968661;
        public static final int settings_alert_message = 2130968667;
        public static final int settings_alert_negativeButton = 2130968669;
        public static final int settings_alert_positiveButton = 2130968668;
        public static final int settings_alert_title = 2130968666;
        public static final int settings_default_button = 2130968663;
        public static final int settings_lecture_details = 2130968622;
        public static final int settings_lecture_details_groupletter = 2130968623;
        public static final int settings_lecture_details_lecturer = 2130968624;
        public static final int settings_lecture_details_type = 2130968625;
        public static final int settings_pathToFile_label = 2130968626;
        public static final int settings_restart_wizard = 2130968617;
        public static final int settings_test_size_0 = 2130968619;
        public static final int settings_test_size_1 = 2130968620;
        public static final int settings_test_size_2 = 2130968621;
        public static final int settings_text_size = 2130968618;
        public static final int sunday = 2130968616;
        public static final int the = 2130968653;
        public static final int thursday = 2130968613;
        public static final int timetable_menu = 2130968665;
        public static final int tomorrow = 2130968664;
        public static final int tuesday = 2130968611;
        public static final int wednesday = 2130968612;
        public static final int wizard_alert_message = 2130968585;
        public static final int wizard_alert_positiveButton = 2130968586;
        public static final int wizard_alert_title = 2130968584;
        public static final int wizard_error_positiveButton = 2130968588;
        public static final int wizard_error_title = 2130968587;
        public static final int wizard_ok_button = 2130968582;
        public static final int wizard_skip_button = 2130968583;
        public static final int wizard_study_course = 2130968581;
    }
}
