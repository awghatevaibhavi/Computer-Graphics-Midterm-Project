package FHNav.gui;

import FHNav.controller.MainApplicationManager;
import FHNav.controller.SettingsManager;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.TextView;
import com.flurry.android.FlurryAgent;
import java.util.Date;
import org.apache.commons.lang.time.DateUtils;

public class SplashScreen extends Activity {
    protected int _splashTime;
    int datarefresh;
    final Handler handler;
    long startTime;
    TextView t1;

    /* renamed from: FHNav.gui.SplashScreen.1 */
    class C00441 extends Handler {
        C00441() {
        }

        public void handleMessage(Message msg) {
            int waited = msg.arg1;
            if (SplashScreen.this.t1 == null) {
                return;
            }
            if (waited <= 300) {
                SplashScreen.this.t1.setText("Loading Data...");
            } else if (waited <= 400) {
                SplashScreen.this.t1.setText("Starting Daemons...");
            } else if (waited <= DateUtils.MILLIS_IN_SECOND) {
                SplashScreen.this.t1.setText("Initialising GUI...");
            }
        }
    }

    /* renamed from: FHNav.gui.SplashScreen.2 */
    class C00452 extends Thread {
        C00452() {
        }

        public void run() {
            Class cls = Menu.class;
            int waited = 0;
            while (waited < SplashScreen.this._splashTime) {
                try {
                    C00452.sleep(100);
                    waited += 100;
                    Message msg = SplashScreen.this.handler.obtainMessage();
                    msg.arg1 = waited;
                    SplashScreen.this.handler.sendMessage(msg);
                } catch (InterruptedException e) {
                } finally {
                    SplashScreen.this.finish();
                    Class cls2 = Menu.class;
                    SplashScreen.this.startActivity(new Intent(SplashScreen.this, cls));
                }
            }
        }
    }

    /* renamed from: FHNav.gui.SplashScreen.3 */
    class C00463 extends Thread {
        C00463(String $anonymous0) {
            super($anonymous0);
        }

        public void run() {
            while (true) {
                try {
                    MainApplicationManager.refreshData(SplashScreen.this.getApplicationContext());
                    for (int waited = 0; waited < SplashScreen.this.datarefresh; waited++) {
                        C00463.sleep(DateUtils.MILLIS_PER_HOUR);
                    }
                } catch (InterruptedException e) {
                }
            }
        }
    }

    public SplashScreen() {
        this._splashTime = DateUtils.MILLIS_IN_SECOND;
        this.datarefresh = 12;
        this.handler = new C00441();
    }

    public void onStart() {
        super.onStart();
        Log.e(getClass().toString(), "Start");
        if (MainApplicationManager.isFinish()) {
            finish();
            return;
        }
        FlurryAgent.onStartSession(this, "I7RRJ22MKL64Q9JLNZW8");
        SettingsManager.loadSettings(getApplicationContext());
    }

    public void onStop() {
        super.onStop();
        FlurryAgent.onEndSession(this);
        Log.e(getClass().toString(), "Stop");
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e(getClass().toString(), "Create");
        MainApplicationManager.setFinish(false);
        setContentView(C0026R.layout.splashscreen);
        this.t1 = (TextView) findViewById(C0026R.id.textView1);
        this.startTime = new Date().getTime();
        new C00452().start();
        Thread splashTread2 = new C00463("Mensa Downloader Thread");
    }
}
