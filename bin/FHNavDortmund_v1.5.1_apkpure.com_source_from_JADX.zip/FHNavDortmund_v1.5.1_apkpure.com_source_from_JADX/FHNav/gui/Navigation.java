package FHNav.gui;

import FHNav.controller.BreadthFirstSearchTest;
import FHNav.controller.BreadthFirstSearchTest.Node;
import FHNav.controller.MainApplicationManager;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import com.flurry.android.FlurryAgent;

public class Navigation extends Activity {
    BreadthFirstSearchTest bfst;
    CView cv;

    /* renamed from: FHNav.gui.Navigation.1 */
    class C00241 implements OnItemSelectedListener {
        C00241() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View arg1, int arg2, long arg3) {
            Navigation.this.bfst.setFrom((Node) Navigation.this.bfst.getNodes().get(arg2));
            Navigation.this.bfst.setPath(Navigation.this.bfst.search(Navigation.this.bfst.getFrom(), Navigation.this.bfst.getTo()));
            Navigation.this.cv.invalidate();
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    /* renamed from: FHNav.gui.Navigation.2 */
    class C00252 implements OnItemSelectedListener {
        C00252() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View arg1, int arg2, long arg3) {
            Navigation.this.bfst.setTo((Node) Navigation.this.bfst.getNodes().get(arg2));
            Navigation.this.bfst.setPath(Navigation.this.bfst.search(Navigation.this.bfst.getFrom(), Navigation.this.bfst.getTo()));
            Navigation.this.cv.invalidate();
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    public void onStart() {
        super.onStart();
        Log.e(getClass().toString(), "Start");
        if (MainApplicationManager.isFinish()) {
            finish();
        }
        FlurryAgent.onStartSession(this, "I7RRJ22MKL64Q9JLNZW8");
    }

    public void onStop() {
        super.onStop();
        FlurryAgent.onEndSession(this);
        Log.e(getClass().toString(), "Stop");
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0026R.layout.navigation);
        this.bfst = MainApplicationManager.getBfst();
        this.bfst.search(this.bfst.getFrom(), this.bfst.getTo());
        LinearLayout ll = (LinearLayout) findViewById(C0026R.id.linearLayout1);
        this.cv = new CView(getApplicationContext());
        ll.addView(this.cv, new LayoutParams(-1, -1));
        this.cv.init();
        Spinner sp_from = (Spinner) findViewById(C0026R.id.spinnerFromRoom);
        Spinner sp_to = (Spinner) findViewById(C0026R.id.spinnerToRoom);
        ArrayAdapter<String> aa = new ArrayAdapter(this, 17367050);
        int fr = 0;
        int to2 = 0;
        int count = 0;
        for (Node n : this.bfst.getNodes()) {
            aa.add(n.getName());
            if (n.equals(this.bfst.getFrom())) {
                fr = count;
            }
            if (n.equals(this.bfst.getTo())) {
                to2 = count;
            }
            count++;
        }
        sp_from.setAdapter(aa);
        sp_from.setSelection(fr);
        sp_from.setOnItemSelectedListener(new C00241());
        sp_to.setAdapter(aa);
        sp_to.setSelection(to2);
        sp_to.setOnItemSelectedListener(new C00252());
        this.cv.invalidate();
    }
}
