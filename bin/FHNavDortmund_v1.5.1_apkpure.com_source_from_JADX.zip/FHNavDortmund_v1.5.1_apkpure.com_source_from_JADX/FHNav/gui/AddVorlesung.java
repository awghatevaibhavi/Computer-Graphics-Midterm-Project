package FHNav.gui;

import FHNav.controller.IOManager;
import FHNav.controller.MainApplicationManager;
import FHNav.controller.Tools;
import FHNav.gui.helper.ExtendedListAdapter;
import FHNav.gui.helper.SeparatedListAdapter;
import FHNav.model.Stundenplan;
import FHNav.model.Veranstaltung;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import com.flurry.android.FlurryAgent;
import java.util.ArrayList;
import java.util.Iterator;
import org.apache.commons.lang.StringUtils;

public class AddVorlesung extends Activity implements Runnable {
    Button btn_add;
    Button btn_back;
    Button btn_select_all;
    boolean click;
    ProgressDialog dialog;
    public ExtendedListAdapter extendedListAdapter;
    final Handler handler;
    boolean loadSpinner;
    ListView lv1;
    boolean select;
    public SeparatedListAdapter separatedListAdapter;
    Spinner spinner1;
    ArrayList<String> spinnerContent;
    private ArrayList<Veranstaltung> veranstaltungen;

    /* renamed from: FHNav.gui.AddVorlesung.1 */
    class C00051 extends Handler {

        /* renamed from: FHNav.gui.AddVorlesung.1.1 */
        class C00031 implements OnClickListener {
            private final /* synthetic */ Dialog val$error_dialog;

            C00031(Dialog dialog) {
                this.val$error_dialog = dialog;
            }

            public void onClick(View v) {
                this.val$error_dialog.dismiss();
                AddVorlesung.this.loadSpinner = true;
                AddVorlesung.this.dialog = ProgressDialog.show(AddVorlesung.this, StringUtils.EMPTY, "Download...", true);
                new Thread(AddVorlesung.this).start();
            }
        }

        /* renamed from: FHNav.gui.AddVorlesung.1.2 */
        class C00042 implements OnClickListener {
            private final /* synthetic */ Dialog val$error_dialog;

            C00042(Dialog dialog) {
                this.val$error_dialog = dialog;
            }

            public void onClick(View v) {
                this.val$error_dialog.dismiss();
                AddVorlesung.this.onBackPressed();
            }
        }

        C00051() {
        }

        public void handleMessage(Message msg) {
            if (AddVorlesung.this.loadSpinner) {
                ArrayAdapter<String> adapter1 = new ArrayAdapter(AddVorlesung.this, 17367050, AddVorlesung.this.spinnerContent);
                adapter1.setDropDownViewResource(17367049);
                AddVorlesung.this.spinner1.setAdapter(adapter1);
                AddVorlesung.this.dialog.dismiss();
                if (AddVorlesung.this.spinnerContent.size() < 1) {
                    Dialog error_dialog = new Dialog(AddVorlesung.this);
                    error_dialog.setContentView(C0026R.layout.alert_dialog_connection_problem);
                    error_dialog.setTitle(C0026R.string.alert_dialog_connection_problem_title);
                    ((Button) error_dialog.findViewById(C0026R.id.alert_dialog_connection_problem_button)).setOnClickListener(new C00031(error_dialog));
                    Button btn2 = (Button) error_dialog.findViewById(C0026R.id.alert_dialog_connection_problem_buttonNext);
                    btn2.setText(AddVorlesung.this.getString(C0026R.string.alert_dialog_connection_problem_next_button2));
                    btn2.setOnClickListener(new C00042(error_dialog));
                    error_dialog.show();
                    return;
                }
                return;
            }
            AddVorlesung.this.build_list();
        }
    }

    /* renamed from: FHNav.gui.AddVorlesung.2 */
    class C00062 implements OnClickListener {
        C00062() {
        }

        public void onClick(View v) {
            if (AddVorlesung.this.select) {
                AddVorlesung.this.select_all();
            } else {
                AddVorlesung.this.deselect_all();
            }
        }
    }

    /* renamed from: FHNav.gui.AddVorlesung.3 */
    class C00073 implements OnClickListener {
        C00073() {
        }

        public void onClick(View v) {
            AddVorlesung.this.onBackPressed();
        }
    }

    /* renamed from: FHNav.gui.AddVorlesung.4 */
    class C00084 implements OnClickListener {
        C00084() {
        }

        public void onClick(View v) {
            ArrayList<Veranstaltung> tmpArr = new ArrayList();
            Stundenplan s = MainApplicationManager.getStundenplan();
            int sizebefore = s.getVeranstaltungen().size();
            for (int i = 0; i < AddVorlesung.this.separatedListAdapter.sections.size(); i++) {
                ExtendedListAdapter el = AddVorlesung.this.separatedListAdapter.sections.values().toArray()[i];
                for (int j = 0; j < el.getChecked().size(); j++) {
                    if (((Boolean) el.getChecked().get(j)).booleanValue()) {
                        tmpArr.add((Veranstaltung) el.getItems().get(j));
                    }
                }
            }
            if (tmpArr.size() == 0) {
                Toast.makeText(AddVorlesung.this.getApplicationContext(), AddVorlesung.this.getString(C0026R.string.addveranstaltung_toast_text_0b), 0).show();
                return;
            }
            Iterator it = tmpArr.iterator();
            while (it.hasNext()) {
                s.addVeranstaltung((Veranstaltung) it.next());
            }
            AddVorlesung.this.deselect_all();
            int count = s.getVeranstaltungen().size() - sizebefore;
            if (count > 0) {
                MainApplicationManager.setStundenplan(s);
                IOManager.saveStundenplan(MainApplicationManager.getStundenplan(), AddVorlesung.this.getApplicationContext());
                Toast.makeText(AddVorlesung.this.getApplicationContext(), new StringBuilder(String.valueOf(AddVorlesung.this.getString(C0026R.string.addveranstaltung_toast_text_1a))).append(" ").append(count).append(" ").append(AddVorlesung.this.getString(C0026R.string.addveranstaltung_toast_text_1b)).toString(), 0).show();
                return;
            }
            Toast.makeText(AddVorlesung.this.getApplicationContext(), AddVorlesung.this.getString(C0026R.string.addveranstaltung_toast_text_0), 0).show();
        }
    }

    /* renamed from: FHNav.gui.AddVorlesung.5 */
    class C00095 implements OnItemSelectedListener {
        C00095() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View arg1, int arg2, long arg3) {
            System.out.println("ITEM SELECTED");
            String selectedBranch = (String) AddVorlesung.this.spinner1.getSelectedItem();
            if (AddVorlesung.this.spinnerContent.size() >= 1 && !selectedBranch.equals(AddVorlesung.this.getString(C0026R.string.addvorlesung_spinner_text))) {
                if (((String) AddVorlesung.this.spinnerContent.get(0)).equals(AddVorlesung.this.getString(C0026R.string.addvorlesung_spinner_text))) {
                    AddVorlesung.this.spinnerContent.remove(0);
                    AddVorlesung.this.spinner1.setSelection(AddVorlesung.this.spinner1.getSelectedItemPosition() - 1);
                    return;
                }
                Log.e("inhalt", selectedBranch);
                if (selectedBranch != AddVorlesung.this.getString(C0026R.string.addvorlesung_spinner_text)) {
                    AddVorlesung.this.loadSpinner = false;
                    AddVorlesung.this.dialog = ProgressDialog.show(AddVorlesung.this, StringUtils.EMPTY, "Download...", true);
                    new Thread(AddVorlesung.this).start();
                }
            }
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    public AddVorlesung() {
        this.loadSpinner = true;
        this.select = false;
        this.click = false;
        this.handler = new C00051();
    }

    public void onStart() {
        super.onStart();
        Log.e(getClass().toString(), "Start");
        if (MainApplicationManager.isFinish()) {
            finish();
        }
        FlurryAgent.onStartSession(this, "I7RRJ22MKL64Q9JLNZW8");
    }

    public void onStop() {
        super.onStop();
        FlurryAgent.onEndSession(this);
        Log.e(getClass().toString(), "Stop");
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0026R.layout.addvorlesung);
        this.separatedListAdapter = new SeparatedListAdapter(this);
        this.dialog = ProgressDialog.show(this, StringUtils.EMPTY, "Download...", true);
        this.loadSpinner = true;
        new Thread(this).start();
        this.btn_select_all = (Button) findViewById(C0026R.id.addveranstaltung_select_all);
        this.btn_select_all.setOnClickListener(new C00062());
        this.btn_back = (Button) findViewById(C0026R.id.addveranstaltung_back);
        this.btn_back.setOnClickListener(new C00073());
        this.btn_add = (Button) findViewById(C0026R.id.addveranstaltung_add);
        this.btn_add.setOnClickListener(new C00084());
        this.click = false;
        this.spinner1 = (Spinner) findViewById(C0026R.id.Spinner01);
        this.spinner1.setOnItemSelectedListener(new C00095());
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void run() {
        /*
        r4 = this;
        r2 = r4.loadSpinner;	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        if (r2 != 0) goto L_0x003f;
    L_0x0004:
        r2 = r4.spinner1;	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r2 = r2.getSelectedItem();	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r2 = (java.lang.String) r2;	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r3 = r4.getApplicationContext();	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r1 = FHNav.controller.PHPConnector.getStundenplanFromMysql(r2, r3);	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r2 = r1.getVeranstaltungen();	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r2 = r2.size();	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        if (r2 <= 0) goto L_0x0034;
    L_0x001e:
        r2 = r1.getVeranstaltungen();	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r4.veranstaltungen = r2;	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r2 = r4.veranstaltungen;	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        java.util.Collections.sort(r2);	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r2 = r4.handler;	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r0 = r2.obtainMessage();	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r2 = r4.handler;	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r2.sendMessage(r0);	 Catch:{ Exception -> 0x0066, all -> 0x006d }
    L_0x0034:
        r2 = r4.dialog;	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r2.dismiss();	 Catch:{ Exception -> 0x0066, all -> 0x006d }
    L_0x0039:
        r2 = r4.dialog;
        r2.dismiss();
    L_0x003e:
        return;
    L_0x003f:
        r2 = new java.util.ArrayList;	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r2.<init>();	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r4.spinnerContent = r2;	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r2 = r4.spinnerContent;	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r3 = "Studiengang w\u00e4hlen";
        r2.add(r3);	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r2 = r4.spinnerContent;	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r3 = r4.getApplicationContext();	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r3 = FHNav.controller.PHPConnector.getAllBranches(r3);	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r2.addAll(r3);	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r2 = r4.handler;	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r0 = r2.obtainMessage();	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r2 = r4.handler;	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        r2.sendMessage(r0);	 Catch:{ Exception -> 0x0066, all -> 0x006d }
        goto L_0x0039;
    L_0x0066:
        r2 = move-exception;
        r2 = r4.dialog;
        r2.dismiss();
        goto L_0x003e;
    L_0x006d:
        r2 = move-exception;
        r3 = r4.dialog;
        r3.dismiss();
        throw r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: FHNav.gui.AddVorlesung.run():void");
    }

    public void select_all() {
        for (int i = 0; i < this.separatedListAdapter.sections.size(); i++) {
            this.separatedListAdapter.sections.values().toArray()[i].selectAll();
            this.separatedListAdapter.notifyDataSetChanged();
            this.select = false;
            this.btn_select_all.setText(C0026R.string.button_deselect_all_label);
        }
    }

    public void deselect_all() {
        for (int i = 0; i < this.separatedListAdapter.sections.size(); i++) {
            this.separatedListAdapter.sections.values().toArray()[i].deselectAll();
        }
        this.separatedListAdapter.notifyDataSetChanged();
        this.select = true;
        this.btn_select_all.setText(C0026R.string.button_select_all_label);
    }

    private void build_list() {
        int i;
        this.separatedListAdapter = new SeparatedListAdapter(this);
        ExtendedListAdapter[] els = new ExtendedListAdapter[7];
        for (i = 0; i < els.length; i++) {
            els[i] = new ExtendedListAdapter(this, new ArrayList());
        }
        Iterator it = this.veranstaltungen.iterator();
        while (it.hasNext()) {
            Veranstaltung ver = (Veranstaltung) it.next();
            els[ver.getWochentag() - 1].getItems().add(ver);
        }
        for (i = 0; i < els.length; i++) {
            if (els[i].getItems().size() > 0) {
                els[i].refresh();
                this.separatedListAdapter.addSection(getString(Tools.getWeekday(i + 1)), els[i]);
            }
        }
        this.lv1 = (ListView) findViewById(C0026R.id.addvorlesung_list);
        this.lv1.setAdapter(this.separatedListAdapter);
    }
}
