package FHNav.gui;

import FHNav.controller.IOManager;
import FHNav.controller.MainApplicationManager;
import FHNav.controller.SettingsManager;
import FHNav.model.Stundenplan;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.Spinner;
import com.flurry.android.FlurryAgent;

public class Settings extends Activity {
    CheckBox groupletterCheckbox;
    CheckBox lecturerCheckbox;
    Button restartWizardButton;
    Spinner textSizeSpinner;
    CheckBox typeCheckbox;
    Intent wizard;

    /* renamed from: FHNav.gui.Settings.1 */
    class C00291 implements OnClickListener {

        /* renamed from: FHNav.gui.Settings.1.1 */
        class C00271 implements DialogInterface.OnClickListener {
            C00271() {
            }

            public void onClick(DialogInterface dialog2, int which) {
                SettingsManager.setWizardDone(false, Settings.this.getApplicationContext());
                MainApplicationManager.setStundenplan(new Stundenplan());
                IOManager.saveStundenplan(MainApplicationManager.getStundenplan(), Settings.this.getApplicationContext());
                Settings.this.startActivity(Settings.this.wizard);
            }
        }

        /* renamed from: FHNav.gui.Settings.1.2 */
        class C00282 implements DialogInterface.OnClickListener {
            C00282() {
            }

            public void onClick(DialogInterface dialog2, int which) {
            }
        }

        C00291() {
        }

        public void onClick(View v) {
            Builder adb = new Builder(Settings.this);
            adb.setTitle(C0026R.string.settings_alert_title);
            adb.setMessage(C0026R.string.settings_alert_message);
            adb.setPositiveButton(C0026R.string.settings_alert_positiveButton, new C00271());
            adb.setNegativeButton(C0026R.string.settings_alert_negativeButton, new C00282());
            adb.show();
        }
    }

    /* renamed from: FHNav.gui.Settings.2 */
    class C00302 implements OnItemSelectedListener {
        C00302() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View arg1, int arg2, long arg3) {
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    /* renamed from: FHNav.gui.Settings.3 */
    class C00313 implements OnCheckedChangeListener {
        C00313() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        }
    }

    /* renamed from: FHNav.gui.Settings.4 */
    class C00324 implements OnCheckedChangeListener {
        C00324() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        }
    }

    /* renamed from: FHNav.gui.Settings.5 */
    class C00335 implements OnCheckedChangeListener {
        C00335() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        }
    }

    /* renamed from: FHNav.gui.Settings.6 */
    class C00346 implements OnClickListener {
        C00346() {
        }

        public void onClick(View v) {
            Settings.this.save();
            Settings.this.startActivity(new Intent(Settings.this, Menu.class));
        }
    }

    /* renamed from: FHNav.gui.Settings.7 */
    class C00357 implements OnClickListener {
        C00357() {
        }

        public void onClick(View v) {
            Settings.this.restore();
        }
    }

    /* renamed from: FHNav.gui.Settings.8 */
    class C00368 implements OnClickListener {
        C00368() {
        }

        public void onClick(View v) {
            Settings.this.onBackPressed();
        }
    }

    public void onStart() {
        super.onStart();
        Log.e(getClass().toString(), "Start");
        if (MainApplicationManager.isFinish()) {
            finish();
        }
        FlurryAgent.onStartSession(this, "I7RRJ22MKL64Q9JLNZW8");
    }

    public void onStop() {
        super.onStop();
        FlurryAgent.onEndSession(this);
        Log.e(getClass().toString(), "Stop");
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0026R.layout.settings);
        this.wizard = new Intent(this, Wizard.class);
        this.restartWizardButton = (Button) findViewById(C0026R.id.settings_restart_wizard_button);
        this.restartWizardButton.setOnClickListener(new C00291());
        this.textSizeSpinner = (Spinner) findViewById(C0026R.id.settings_text_size_spinner);
        ArrayAdapter<String> adapter2 = new ArrayAdapter(this, 17367050, new String[]{getString(C0026R.string.settings_test_size_0), getString(C0026R.string.settings_test_size_1), getString(C0026R.string.settings_test_size_2)});
        this.textSizeSpinner.setPromptId(C0026R.string.settings_text_size);
        this.textSizeSpinner.setAdapter(adapter2);
        this.textSizeSpinner.setSelection(SettingsManager.getText_size(getApplicationContext()));
        this.textSizeSpinner.setOnItemSelectedListener(new C00302());
        this.groupletterCheckbox = (CheckBox) findViewById(C0026R.id.settings_lecture_details_groupletter_checkbox);
        this.groupletterCheckbox.setChecked(SettingsManager.isLecture_details_groupletter(getApplicationContext()));
        this.groupletterCheckbox.setOnCheckedChangeListener(new C00313());
        this.lecturerCheckbox = (CheckBox) findViewById(C0026R.id.settings_lecture_details_lecturer_checkbox);
        this.lecturerCheckbox.setChecked(SettingsManager.isLecture_details_lecturer(getApplicationContext()));
        this.lecturerCheckbox.setOnCheckedChangeListener(new C00324());
        this.typeCheckbox = (CheckBox) findViewById(C0026R.id.settings_lecture_details_type_checkbox);
        this.typeCheckbox.setChecked(SettingsManager.isLecture_details_type(getApplicationContext()));
        this.typeCheckbox.setOnCheckedChangeListener(new C00335());
        ((Button) findViewById(C0026R.id.Button01)).setOnClickListener(new C00346());
        ((Button) findViewById(C0026R.id.Button02)).setOnClickListener(new C00357());
        ((Button) findViewById(C0026R.id.Button03)).setOnClickListener(new C00368());
    }

    public void save() {
        SettingsManager.setText_size(this.textSizeSpinner.getSelectedItemPosition(), getApplicationContext());
        SettingsManager.setLecture_details_groupletter(this.groupletterCheckbox.isChecked(), getApplicationContext());
        SettingsManager.setLecture_details_lecturer(this.lecturerCheckbox.isChecked(), getApplicationContext());
        SettingsManager.setLecture_details_type(this.typeCheckbox.isChecked(), getApplicationContext());
    }

    public void restore() {
        this.textSizeSpinner.setSelection(1);
        this.groupletterCheckbox.setChecked(true);
        this.lecturerCheckbox.setChecked(true);
        this.typeCheckbox.setChecked(true);
        save();
    }
}
