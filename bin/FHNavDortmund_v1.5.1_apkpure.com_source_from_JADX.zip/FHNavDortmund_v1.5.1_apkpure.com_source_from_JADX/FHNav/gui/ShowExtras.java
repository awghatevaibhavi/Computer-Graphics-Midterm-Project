package FHNav.gui;

import FHNav.controller.CanteenBeanTest;
import FHNav.controller.I_Mensa_Downloader;
import FHNav.controller.MainApplicationManager;
import FHNav.controller.Tools;
import FHNav.gui.helper.NormalListAdapterForMenu;
import FHNav.gui.helper.SeparatedListAdapter;
import FHNav.model.CanteenMenu;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import com.flurry.android.FlurryAgent;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import org.apache.commons.lang.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.select.Elements;

public class ShowExtras extends Activity implements Runnable, I_Mensa_Downloader {
    Button btn1;
    Button btn2;
    Button btn3;
    int choose2;
    String chooseMensa;
    String choosePage;
    String dataAktuellesW;
    ProgressDialog dialog;
    final Handler handler;
    ArrayList<CanteenMenu> lastMenuKostbar;
    ArrayList<CanteenMenu> lastMenuMensa;
    BaseAdapter listAdapter;
    BaseAdapter listAdapterMensa;
    boolean load;
    private boolean loaded;
    boolean loadfailed;
    ListView lv1;
    WebView mWebView;
    boolean mensa;
    Spinner sp;
    ArrayList<String> spinnerContent;
    Thread t1;

    /* renamed from: FHNav.gui.ShowExtras.1 */
    class C00371 extends Handler {
        C00371() {
        }

        public void handleMessage(Message msg) {
            if (ShowExtras.this.loaded) {
                ShowExtras.this.refresh();
                ShowExtras.this.loaded = false;
            } else if (ShowExtras.this.mensa) {
                ShowExtras.this.lv1.setAdapter(ShowExtras.this.listAdapterMensa);
                if (ShowExtras.this.listAdapterMensa.getCount() == 0) {
                    if (MainApplicationManager.isDownloading() || ShowExtras.this.load) {
                        ((TextView) ShowExtras.this.lv1.getEmptyView()).setText(C0026R.string.empty_list_downloading);
                    } else if (ShowExtras.this.loadfailed) {
                        ((TextView) ShowExtras.this.lv1.getEmptyView()).setText(C0026R.string.alert_dialog_connection_problem_msg);
                    } else {
                        ((TextView) ShowExtras.this.lv1.getEmptyView()).setText(C0026R.string.empty_list_downloading_no);
                    }
                }
                if (ShowExtras.this.dialog != null) {
                    ShowExtras.this.dialog.dismiss();
                }
            } else {
                ShowExtras.this.setWebViewContent();
            }
        }
    }

    /* renamed from: FHNav.gui.ShowExtras.2 */
    class C00382 implements OnItemSelectedListener {
        C00382() {
        }

        public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
            ShowExtras.this.chooseMensa = (String) arg0.getItemAtPosition(arg2);
            ShowExtras.this.load = true;
            if (ShowExtras.this.dialog != null) {
                ShowExtras.this.dialog.dismiss();
            }
            new Thread(ShowExtras.this).start();
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    /* renamed from: FHNav.gui.ShowExtras.3 */
    class C00393 implements OnClickListener {
        C00393() {
        }

        public void onClick(View v) {
            ShowExtras.this.load = true;
            if (ShowExtras.this.dialog != null) {
                ShowExtras.this.dialog.dismiss();
            }
            new Thread(ShowExtras.this).start();
        }
    }

    /* renamed from: FHNav.gui.ShowExtras.4 */
    class C00404 implements OnItemSelectedListener {
        C00404() {
        }

        public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
            ShowExtras.this.choosePage = (String) arg0.getItemAtPosition(arg2);
            new Thread(ShowExtras.this).start();
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    /* renamed from: FHNav.gui.ShowExtras.5 */
    class C00415 implements OnClickListener {
        C00415() {
        }

        public void onClick(View v) {
            if (ShowExtras.this.dialog != null) {
                ShowExtras.this.dialog.dismiss();
            }
            ShowExtras.this.mensa = !ShowExtras.this.mensa;
            ShowExtras.this.refresh();
        }
    }

    /* renamed from: FHNav.gui.ShowExtras.6 */
    class C00426 implements OnClickListener {
        C00426() {
        }

        public void onClick(View v) {
            if (ShowExtras.this.dialog != null) {
                ShowExtras.this.dialog.dismiss();
            }
            ShowExtras.this.startActivity(new Intent(ShowExtras.this, Navigation.class));
        }
    }

    /* renamed from: FHNav.gui.ShowExtras.7 */
    class C00437 implements OnClickListener {
        C00437() {
        }

        public void onClick(View v) {
            if (ShowExtras.this.dialog != null) {
                ShowExtras.this.dialog.dismiss();
            }
            ShowExtras.this.onBackPressed();
        }
    }

    private class HelloWebViewClient extends WebViewClient {
        private HelloWebViewClient() {
        }

        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }

    public ShowExtras() {
        this.mensa = false;
        this.load = false;
        this.loadfailed = false;
        this.handler = new C00371();
        this.loaded = false;
    }

    private BaseAdapter build_normal() {
        int i;
        SeparatedListAdapter separatedListAdapter = new SeparatedListAdapter(this);
        ArrayList<CanteenMenu> menus = CanteenBeanTest.getCanteenMenu(this.chooseMensa, getApplicationContext());
        this.load = false;
        if (menus == null) {
            menus = new ArrayList();
            this.loadfailed = true;
        } else {
            this.loadfailed = false;
        }
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        NormalListAdapterForMenu[] els = new NormalListAdapterForMenu[8];
        for (i = 0; i < els.length; i++) {
            els[i] = new NormalListAdapterForMenu(this, new ArrayList());
        }
        Iterator it = menus.iterator();
        while (it.hasNext()) {
            CanteenMenu cm = (CanteenMenu) it.next();
            if (cm.getDate() == null) {
                els[7].getItems().add(cm);
            } else {
                els[cm.getDate().getDay()].getItems().add(cm);
            }
        }
        for (i = 0; i < els.length; i++) {
            if (els[i].getItems().size() > 0) {
                String header;
                if (i != 7) {
                    header = getString(Tools.getWeekday(((CanteenMenu) els[i].getItems().get(0)).getDate().getDay())) + ", " + getString(C0026R.string.the) + " " + sdf.format(((CanteenMenu) els[i].getItems().get(0)).getDate());
                } else {
                    header = getString(C0026R.string.canteenSpezialHeader);
                }
                separatedListAdapter.addSection(header, els[i]);
            }
        }
        return separatedListAdapter;
    }

    public void initWebViewContent() {
        if (this.choosePage.equals(getString(C0026R.string.page_name_news_W)) && this.dataAktuellesW == null) {
            this.dataAktuellesW = parseNewsW();
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.chooseMensa = getString(C0026R.string.page_name_mensa);
        this.choosePage = getString(C0026R.string.page_name_news);
        this.mensa = false;
        this.listAdapterMensa = new SeparatedListAdapter(this);
        refresh();
    }

    public void onStart() {
        super.onStart();
        Log.e("Extras", "Start");
        MainApplicationManager.addListener(this);
        if (MainApplicationManager.isFinish()) {
            finish();
        }
        FlurryAgent.onStartSession(this, "I7RRJ22MKL64Q9JLNZW8");
    }

    public void onStop() {
        super.onStop();
        FlurryAgent.onEndSession(this);
        MainApplicationManager.removeListener(this);
        Log.e("Extras", "Stop");
    }

    private void refresh() {
        if (this.mensa) {
            setContentView(C0026R.layout.extras);
            refreshButtons();
            this.lv1 = (ListView) findViewById(C0026R.id.listView1);
            this.lv1.setEmptyView(findViewById(C0026R.id.empty));
            if (MainApplicationManager.isDownloading()) {
                ((TextView) this.lv1.getEmptyView()).setText(C0026R.string.empty_list_downloading);
            }
            this.btn1.setText(C0026R.string.extras_button1a);
            this.sp = (Spinner) findViewById(C0026R.id.spinner1);
            this.spinnerContent = CanteenBeanTest.getAllCanteens(getApplicationContext());
            ArrayAdapter<String> adapter2 = new ArrayAdapter(this, 17367050, this.spinnerContent);
            this.sp.setPromptId(C0026R.string.page_select_header);
            this.sp.setAdapter(adapter2);
            this.sp.setOnItemSelectedListener(new C00382());
            ((ImageButton) findViewById(C0026R.id.mensa_refresh)).setOnClickListener(new C00393());
            return;
        }
        setContentView(C0026R.layout.extras2);
        refreshButtons();
        this.btn1.setText(C0026R.string.extras_button1b);
        this.mWebView = (WebView) findViewById(C0026R.id.webView1);
        this.mWebView.setWebViewClient(new HelloWebViewClient());
        this.mWebView.getSettings().setJavaScriptEnabled(true);
        this.mWebView.setBackgroundColor(0);
        this.sp = (Spinner) findViewById(C0026R.id.spinner1);
        adapter2 = new ArrayAdapter(this, 17367050, new String[]{getString(C0026R.string.page_name_news), getString(C0026R.string.page_name_news_W), getString(C0026R.string.page_name_pplan), getString(C0026R.string.page_name_lplan), getString(C0026R.string.page_name_lplan2), getString(C0026R.string.page_name_splan), getString(C0026R.string.page_name_bplan)});
        this.sp.setPromptId(C0026R.string.page_select_header);
        this.sp.setAdapter(adapter2);
        this.sp.setOnItemSelectedListener(new C00404());
    }

    private void refreshButtons() {
        this.btn1 = (Button) findViewById(C0026R.id.Button01);
        this.btn1.setOnClickListener(new C00415());
        this.btn2 = (Button) findViewById(C0026R.id.Button02);
        this.btn2.setOnClickListener(new C00426());
        ((Button) findViewById(C0026R.id.Button03)).setOnClickListener(new C00437());
    }

    public void run() {
        if (this.mensa) {
            try {
                this.listAdapterMensa = new SeparatedListAdapter(this);
                this.handler.sendMessage(this.handler.obtainMessage());
                this.listAdapterMensa = build_normal();
                this.handler.sendMessage(this.handler.obtainMessage());
                if (this.dialog != null) {
                    this.dialog.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
                if (this.dialog != null) {
                    this.dialog.dismiss();
                }
            } catch (Throwable th) {
                if (this.dialog != null) {
                    this.dialog.dismiss();
                }
            }
        } else {
            try {
                initWebViewContent();
                this.handler.sendMessage(this.handler.obtainMessage());
            } catch (Exception e2) {
            }
        }
    }

    protected void setWebViewContent() {
        if (this.choosePage.equals(getString(C0026R.string.page_name_news_W))) {
            this.mWebView.loadDataWithBaseURL("http://www.fh-dortmund.de/de/studi/fb/9/studieng/400/aktuelles_stud.php", this.dataAktuellesW, "text/html", "utf-8", null);
        } else if (this.choosePage.equals(getString(C0026R.string.page_name_news))) {
            this.mWebView.loadUrl("http://www.fh-dortmund.de/de/fb/4/isc/aktuelles/index.php");
        } else if (this.choosePage.equals(getString(C0026R.string.page_name_pplan))) {
            this.mWebView.loadUrl("http://docs.google.com/gview?embedded=true&url=http://www.inf.fh-dortmund.de/~pa_data/pplan.pdf");
        } else if (this.choosePage.equals(getString(C0026R.string.page_name_lplan))) {
            this.mWebView.loadUrl("http://docs.google.com/gview?embedded=true&url=http://www.gemorra.de/lplan.pdf");
        } else if (this.choosePage.equals(getString(C0026R.string.page_name_lplan2))) {
            this.mWebView.loadUrl("http://maps.google.de/maps?hl=de&ll=51.4926,7.415965&spn=0.005965,0.016512&sll=51.491311,7.409399&sspn=0.011931,0.033023&t=h&z=17");
        } else if (this.choosePage.equals(getString(C0026R.string.page_name_splan))) {
            this.mWebView.loadUrl("http://docs.google.com/gview?embedded=true&url=http://www.gemorra.de/s1.pdf");
        } else if (this.choosePage.equals(getString(C0026R.string.page_name_bplan))) {
            this.mWebView.loadUrl("http://docs.google.com/gview?embedded=false&url=http://www.gemorra.de/bus.pdf");
            System.out.println("bus.pdf");
        }
    }

    public static String parseNewsW() {
        String ret = StringUtils.EMPTY;
        try {
            Elements tds = Jsoup.connect("http://www.fh-dortmund.de/de/studi/fb/9/studieng/400/aktuelles_stud.php").get().select("td.g10");
            ret = "<html><head></head><body margin=\"0\" padding=\"0\">" + " <style type=\"text/css\">hr{border-top:1px solid #F60;  height:1px;} .g10 { font-size:0.8em; padding:5px 5px 3px 0px; } html,body{margin:0px; padding:0px;}</style>";
            for (int i = 0; i < tds.size(); i++) {
                ret = new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(ret)).append("<div class=\"g10\">").toString())).append(tds.get(i).html()).toString())).append("</div>").toString())).append("<hr size=\"1\" noshade>").toString();
            }
            ret = new StringBuilder(String.valueOf(ret)).append("</body></html>").toString();
            System.out.println(ret);
            return ret;
        } catch (IOException e) {
            e.printStackTrace();
            return ret;
        }
    }

    public void downloadDone() {
        this.loaded = true;
        this.handler.sendMessage(this.handler.obtainMessage());
    }
}
