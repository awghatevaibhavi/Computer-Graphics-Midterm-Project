package FHNav.gui;

import FHNav.controller.IOManager;
import FHNav.controller.MainApplicationManager;
import FHNav.controller.PHPConnector;
import FHNav.controller.SettingsManager;
import FHNav.model.Stundenplan;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;
import com.flurry.android.FlurryAgent;
import java.util.ArrayList;
import org.apache.commons.lang.StringUtils;

public class Wizard extends Activity implements Runnable {
    public static final String PREFS_NAME = "settings";
    ProgressDialog dialog;
    boolean handle1;
    final Handler handler;
    boolean loadSpinner;
    Spinner spinner1;
    ArrayList<String> spinnerContent;

    /* renamed from: FHNav.gui.Wizard.1 */
    class C00511 extends Handler {

        /* renamed from: FHNav.gui.Wizard.1.1 */
        class C00471 implements OnClickListener {
            private final /* synthetic */ Dialog val$error_dialog;

            C00471(Dialog dialog) {
                this.val$error_dialog = dialog;
            }

            public void onClick(View v) {
                this.val$error_dialog.dismiss();
                Wizard.this.loadSpinner = true;
                Wizard.this.dialog = ProgressDialog.show(Wizard.this, StringUtils.EMPTY, "Download...", true);
                new Thread(Wizard.this).start();
            }
        }

        /* renamed from: FHNav.gui.Wizard.1.2 */
        class C00482 implements OnClickListener {
            C00482() {
            }

            public void onClick(View v) {
                Wizard.this.new_blank_plan();
            }
        }

        /* renamed from: FHNav.gui.Wizard.1.3 */
        class C00493 implements OnClickListener {
            private final /* synthetic */ Dialog val$error_dialog;

            C00493(Dialog dialog) {
                this.val$error_dialog = dialog;
            }

            public void onClick(View v) {
                this.val$error_dialog.dismiss();
                Wizard.this.loadSpinner = false;
                Wizard.this.dialog = ProgressDialog.show(Wizard.this, StringUtils.EMPTY, "Download...", true);
                new Thread(Wizard.this).start();
            }
        }

        /* renamed from: FHNav.gui.Wizard.1.4 */
        class C00504 implements OnClickListener {
            C00504() {
            }

            public void onClick(View v) {
                Wizard.this.new_blank_plan();
            }
        }

        C00511() {
        }

        public void handleMessage(Message msg) {
            Dialog error_dialog;
            if (!Wizard.this.handle1) {
                error_dialog = new Dialog(Wizard.this);
                error_dialog.setContentView(C0026R.layout.alert_dialog_connection_problem);
                error_dialog.setTitle(C0026R.string.alert_dialog_connection_problem_title);
                ((Button) error_dialog.findViewById(C0026R.id.alert_dialog_connection_problem_button)).setOnClickListener(new C00493(error_dialog));
                ((Button) error_dialog.findViewById(C0026R.id.alert_dialog_connection_problem_buttonNext)).setOnClickListener(new C00504());
                Wizard.this.dialog.dismiss();
                error_dialog.show();
            } else if (Wizard.this.spinnerContent.size() < 1) {
                error_dialog = new Dialog(Wizard.this);
                error_dialog.setContentView(C0026R.layout.alert_dialog_connection_problem);
                error_dialog.setTitle(C0026R.string.alert_dialog_connection_problem_title);
                ((Button) error_dialog.findViewById(C0026R.id.alert_dialog_connection_problem_button)).setOnClickListener(new C00471(error_dialog));
                ((Button) error_dialog.findViewById(C0026R.id.alert_dialog_connection_problem_buttonNext)).setOnClickListener(new C00482());
                Wizard.this.dialog.dismiss();
                error_dialog.show();
            } else {
                Wizard.this.spinner1 = (Spinner) Wizard.this.findViewById(C0026R.id.Spinner01);
                ArrayAdapter<String> adapter1 = new ArrayAdapter(Wizard.this, 17367050, Wizard.this.spinnerContent);
                adapter1.setDropDownViewResource(17367049);
                Wizard.this.spinner1.setAdapter(adapter1);
                Wizard.this.dialog.dismiss();
            }
        }
    }

    /* renamed from: FHNav.gui.Wizard.2 */
    class C00522 implements DialogInterface.OnClickListener {
        C00522() {
        }

        public void onClick(DialogInterface dialog2, int which) {
            Wizard.this.loadSpinner = true;
            Wizard.this.dialog = ProgressDialog.show(Wizard.this, StringUtils.EMPTY, "Download...", true);
            new Thread(Wizard.this).start();
        }
    }

    /* renamed from: FHNav.gui.Wizard.3 */
    class C00533 implements DialogInterface.OnClickListener {
        C00533() {
        }

        public void onClick(DialogInterface dialog, int which) {
            Wizard.this.new_blank_plan();
        }
    }

    /* renamed from: FHNav.gui.Wizard.4 */
    class C00544 implements OnClickListener {
        C00544() {
        }

        public void onClick(View v) {
            if (Wizard.this.spinnerContent.size() >= 1) {
                Wizard.this.loadSpinner = false;
                Wizard.this.dialog = ProgressDialog.show(Wizard.this, StringUtils.EMPTY, "Download...", true);
                new Thread(Wizard.this).start();
            }
        }
    }

    /* renamed from: FHNav.gui.Wizard.5 */
    class C00555 implements OnClickListener {
        C00555() {
        }

        public void onClick(View v) {
            Wizard.this.loadSpinner = true;
            Wizard.this.dialog = ProgressDialog.show(Wizard.this, StringUtils.EMPTY, "Download...", true);
            new Thread(Wizard.this).start();
        }
    }

    public Wizard() {
        this.loadSpinner = true;
        this.handle1 = true;
        this.handler = new C00511();
    }

    public void onStart() {
        super.onStart();
        Log.e(getClass().toString(), "Start");
        if (MainApplicationManager.isFinish()) {
            finish();
        }
        FlurryAgent.onStartSession(this, "I7RRJ22MKL64Q9JLNZW8");
    }

    public void onStop() {
        super.onStop();
        FlurryAgent.onEndSession(this);
        Log.e(getClass().toString(), "Stop");
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e("Wizard", "Create");
        setContentView(C0026R.layout.wizard);
        getWindow().setBackgroundDrawableResource(C0026R.drawable.bgunten);
        Builder adb = new Builder(this);
        adb.setTitle(C0026R.string.wizard_alert_title);
        adb.setMessage(C0026R.string.wizard_alert_message);
        adb.setPositiveButton(C0026R.string.wizard_alert_positiveButton, new C00522());
        adb.setNegativeButton(C0026R.string.wizard_skip_button, new C00533());
        adb.show();
        ((Button) findViewById(C0026R.id.WizardOK)).setOnClickListener(new C00544());
        ((ImageButton) findViewById(C0026R.id.wizard_refresh)).setOnClickListener(new C00555());
    }

    public void run() {
        Message msg;
        if (this.loadSpinner) {
            try {
                this.spinnerContent = PHPConnector.getAllBranches(getApplicationContext());
                msg = this.handler.obtainMessage();
                this.handle1 = true;
                this.handler.sendMessage(msg);
            } catch (Exception e) {
            } finally {
                this.dialog.dismiss();
            }
        } else {
            try {
                String selectedBranch = (String) this.spinner1.getSelectedItem();
                MainApplicationManager.setStundenplan(PHPConnector.getStundenplanFromMysql((String) this.spinner1.getSelectedItem(), getApplicationContext()));
                if (MainApplicationManager.getStundenplan().getVeranstaltungen().size() > 0) {
                    IOManager.saveStundenplan(MainApplicationManager.getStundenplan(), getApplicationContext());
                    SettingsManager.setWizardDone(true, getApplicationContext());
                    MainApplicationManager.setSelectedBranch(selectedBranch);
                    startActivity(new Intent(this, Menu.class));
                    return;
                }
                msg = this.handler.obtainMessage();
                this.handle1 = false;
                this.handler.sendMessage(msg);
            } catch (Exception e2) {
            }
        }
    }

    public void new_blank_plan() {
        SettingsManager.setWizardDone(true, getApplicationContext());
        MainApplicationManager.setStundenplan(new Stundenplan());
        IOManager.saveStundenplan(MainApplicationManager.getStundenplan(), getApplicationContext());
        MainApplicationManager.setSelectedBranch(StringUtils.EMPTY);
        startActivity(new Intent(this, Menu.class));
    }

    public void onBackPressed() {
        Log.e("Wizard", "Back");
    }
}
