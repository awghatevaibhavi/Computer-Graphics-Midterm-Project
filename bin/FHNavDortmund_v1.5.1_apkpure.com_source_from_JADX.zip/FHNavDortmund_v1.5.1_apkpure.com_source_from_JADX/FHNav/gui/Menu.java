package FHNav.gui;

import FHNav.controller.BreadthFirstSearchTest;
import FHNav.controller.BreadthFirstSearchTest.Node;
import FHNav.controller.CalendarAdapter;
import FHNav.controller.IOManager;
import FHNav.controller.MainApplicationManager;
import FHNav.controller.SettingsManager;
import FHNav.controller.Tools;
import FHNav.gui.helper.NormalListAdapter;
import FHNav.gui.helper.SeparatedListAdapter;
import FHNav.model.Veranstaltung;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import com.flurry.android.FlurryAgent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;

public class Menu extends Activity {
    Intent adaptstundenplan;
    Intent addVorlesung;
    boolean agenda;
    TextView header;
    SeparatedListAdapter listAdapter;
    ListView lv1;
    Intent settings;
    int topy;
    private ArrayList<Veranstaltung> veranstaltungen;
    int visibleFirst;
    Intent wizard;

    class 10 implements OnClickListener {
        private final /* synthetic */ TimePickerDialog val$tpdt;

        10(TimePickerDialog timePickerDialog) {
            this.val$tpdt = timePickerDialog;
        }

        public void onClick(View v) {
            this.val$tpdt.show();
        }
    }

    class 11 implements DialogInterface.OnClickListener {
        11() {
        }

        public void onClick(DialogInterface dialog, int which) {
        }
    }

    class 12 implements OnClickListener {
        private final /* synthetic */ AlertDialog val$alertDialog;
        private final /* synthetic */ View val$layout;
        private final /* synthetic */ Button val$timeFrom;
        private final /* synthetic */ Button val$timeTo;
        private final /* synthetic */ Spinner val$weekday;

        12(View view, Spinner spinner, Button button, Button button2, AlertDialog alertDialog) {
            this.val$layout = view;
            this.val$weekday = spinner;
            this.val$timeFrom = button;
            this.val$timeTo = button2;
            this.val$alertDialog = alertDialog;
        }

        public void onClick(View vie) {
            EditText coursename = (EditText) this.val$layout.findViewById(C0026R.id.own_entry_dialog_courseName_te);
            EditText room = (EditText) this.val$layout.findViewById(C0026R.id.own_entry_dialog_room_te);
            EditText prof = (EditText) this.val$layout.findViewById(C0026R.id.own_entry_dialog_prof_te);
            if (coursename.getText().length() > 0) {
                String dozent = prof.getText().toString();
                String name = coursename.getText().toString();
                String raum = room.getText().toString();
                int wochentag = this.val$weekday.getSelectedItemPosition();
                Veranstaltung v = new Veranstaltung();
                v.setName(name);
                v.setDozent(dozent);
                v.setRaum(raum);
                v.setWochentag(wochentag + 1);
                Date dtStart = new Date();
                int shour2 = Integer.parseInt(this.val$timeFrom.getText().toString().substring(0, this.val$timeFrom.getText().toString().indexOf(":")));
                int smin2 = Integer.parseInt(this.val$timeFrom.getText().toString().substring(this.val$timeFrom.getText().toString().indexOf(":") + 1));
                dtStart.setHours(shour2);
                dtStart.setMinutes(smin2);
                v.setStartTime(dtStart);
                int thour2 = Integer.parseInt(this.val$timeTo.getText().toString().substring(0, this.val$timeTo.getText().toString().indexOf(":")));
                int tmin2 = Integer.parseInt(this.val$timeTo.getText().toString().substring(this.val$timeTo.getText().toString().indexOf(":") + 1));
                Date dtTo = new Date();
                dtTo.setHours(thour2);
                dtTo.setMinutes(tmin2);
                v.setEndTime(dtTo);
                MainApplicationManager.getStundenplan().addVeranstaltung(v);
                IOManager.saveStundenplan(MainApplicationManager.getStundenplan(), Menu.this.getApplicationContext());
                Menu.this.refresListView(false);
                this.val$alertDialog.dismiss();
                return;
            }
            Toast.makeText(Menu.this.getApplicationContext(), Menu.this.getString(C0026R.string.own_entry_dialog_failure), 500).show();
        }
    }

    class 13 implements OnDateSetListener {
        private final /* synthetic */ TextView val$textFrom;

        13(TextView textView) {
            this.val$textFrom = textView;
        }

        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            String str = ".";
            String str2 = ".";
            str2 = ".";
            this.val$textFrom.setText(new StringBuilder(String.valueOf(dayOfMonth)).append(str).append(monthOfYear + 1).append(str).append(year).toString());
        }
    }

    class 14 implements OnDateSetListener {
        private final /* synthetic */ TextView val$textTo;

        14(TextView textView) {
            this.val$textTo = textView;
        }

        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            String str = ".";
            String str2 = ".";
            str2 = ".";
            this.val$textTo.setText(new StringBuilder(String.valueOf(dayOfMonth)).append(str).append(monthOfYear + 1).append(str).append(year).toString());
        }
    }

    class 15 implements OnClickListener {
        private final /* synthetic */ DatePickerDialog val$dpdf;

        15(DatePickerDialog datePickerDialog) {
            this.val$dpdf = datePickerDialog;
        }

        public void onClick(View v) {
            this.val$dpdf.show();
        }
    }

    class 16 implements OnClickListener {
        private final /* synthetic */ DatePickerDialog val$dpdt;

        16(DatePickerDialog datePickerDialog) {
            this.val$dpdt = datePickerDialog;
        }

        public void onClick(View v) {
            this.val$dpdt.show();
        }
    }

    class 17 implements OnItemSelectedListener {
        private final /* synthetic */ CalendarAdapter val$ca;

        17(CalendarAdapter calendarAdapter) {
            this.val$ca = calendarAdapter;
        }

        public void onItemSelected(AdapterView<?> adapterView, View arg1, int arg2, long arg3) {
            this.val$ca.setSelectedid(arg2);
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    class 18 implements DialogInterface.OnClickListener {
        private final /* synthetic */ CalendarAdapter val$ca;
        private final /* synthetic */ TextView val$textFrom;
        private final /* synthetic */ TextView val$textTo;

        18(TextView textView, TextView textView2, CalendarAdapter calendarAdapter) {
            this.val$textFrom = textView;
            this.val$textTo = textView2;
            this.val$ca = calendarAdapter;
        }

        public void onClick(DialogInterface dialog, int which) {
            String str = " ";
            SimpleDateFormat sdfToDate = new SimpleDateFormat("dd.MM.yyyy");
            try {
                Date from = sdfToDate.parse((String) this.val$textFrom.getText());
                Date to = sdfToDate.parse((String) this.val$textTo.getText());
                to.setHours(23);
                to.setMinutes(59);
                int count = 0;
                Iterator it = MainApplicationManager.getStundenplan().getVeranstaltungen().iterator();
                while (it.hasNext()) {
                    this.val$ca.addRecEventToCalendar((Veranstaltung) it.next(), from, to);
                    count++;
                }
                Toast.makeText(Menu.this.getApplicationContext(), new StringBuilder(String.valueOf(Menu.this.getString(C0026R.string.addveranstaltung_toast_text_1a))).append(" ").append(count).append(" ").append(Menu.this.getString(C0026R.string.calendar_transfer_toast_text_1b)).toString(), 0).show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /* renamed from: FHNav.gui.Menu.1 */
    class C00121 implements OnClickListener {

        /* renamed from: FHNav.gui.Menu.1.1 */
        class C00111 implements DialogInterface.OnClickListener {
            C00111() {
            }

            public void onClick(DialogInterface dialog, int item) {
                if (item == 0) {
                    Menu.this.agenda = !Menu.this.agenda;
                    if (Menu.this.agenda) {
                        Menu.this.header.setText(Menu.this.getString(C0026R.string.agenda_view));
                    } else {
                        Menu.this.header.setText(Menu.this.getString(C0026R.string.normal_view));
                    }
                    Menu.this.refresListView(true);
                }
                if (item == 3) {
                    Menu.this.startActivity(Menu.this.adaptstundenplan);
                }
                if (item == 1) {
                    Menu.this.startActivity(Menu.this.addVorlesung);
                }
                if (item == 2) {
                    Menu.this.build_add_own_entry_dialog();
                }
                if (item == 4) {
                    try {
                        Menu.this.build_calendar_dialog();
                    } catch (Exception e) {
                        Builder adb = new Builder(Menu.this);
                        adb.setTitle(C0026R.string.error);
                        adb.setMessage(C0026R.string.error_calendar);
                        adb.setPositiveButton("  OK  ", null);
                        adb.show();
                    }
                }
            }
        }

        C00121() {
        }

        public void onClick(View v) {
            CharSequence[] items = new CharSequence[]{Menu.this.getString(C0026R.string.editmenu_change_view), Menu.this.getString(C0026R.string.editmenu_add), Menu.this.getString(C0026R.string.editmenu_add_own), Menu.this.getString(C0026R.string.editmenu_delete), Menu.this.getString(C0026R.string.editmenu_commit)};
            Builder builder = new Builder(Menu.this);
            builder.setTitle(Menu.this.getString(C0026R.string.timetable_menu));
            builder.setItems(items, new C00111());
            builder.create().show();
        }
    }

    /* renamed from: FHNav.gui.Menu.2 */
    class C00132 implements OnClickListener {
        C00132() {
        }

        public void onClick(View v) {
            Menu.this.startActivity(new Intent(Menu.this, ShowExtras.class));
        }
    }

    /* renamed from: FHNav.gui.Menu.3 */
    class C00143 implements OnClickListener {
        C00143() {
        }

        public void onClick(View v) {
            Menu.this.startActivity(Menu.this.settings);
        }
    }

    /* renamed from: FHNav.gui.Menu.4 */
    class C00154 implements OnClickListener {
        C00154() {
        }

        public void onClick(View v) {
            MainApplicationManager.setFinish(true);
            Menu.this.finish();
        }
    }

    /* renamed from: FHNav.gui.Menu.5 */
    class C00175 implements OnClickListener {

        /* renamed from: FHNav.gui.Menu.5.1 */
        class C00161 implements DialogInterface.OnClickListener {
            C00161() {
            }

            public void onClick(DialogInterface dialog2, int which) {
            }
        }

        C00175() {
        }

        public void onClick(View v) {
            Builder adb = new Builder(Menu.this);
            adb.setTitle("About");
            adb.setMessage("FH Nav Dortmund \nMade by Moritz Wiechers\nmoritz.wiechers@googlemail.com");
            adb.setPositiveButton("Close", new C00161());
            adb.show();
        }
    }

    /* renamed from: FHNav.gui.Menu.6 */
    class C00206 implements OnItemClickListener {

        /* renamed from: FHNav.gui.Menu.6.1 */
        class C00191 implements DialogInterface.OnClickListener {
            private final /* synthetic */ BreadthFirstSearchTest val$bfst;
            private final /* synthetic */ Veranstaltung val$ver;

            /* renamed from: FHNav.gui.Menu.6.1.1 */
            class C00181 implements DialogInterface.OnClickListener {
                C00181() {
                }

                public void onClick(DialogInterface dialog2, int which) {
                }
            }

            C00191(Veranstaltung veranstaltung, BreadthFirstSearchTest breadthFirstSearchTest) {
                this.val$ver = veranstaltung;
                this.val$bfst = breadthFirstSearchTest;
            }

            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    MainApplicationManager.getStundenplan().removeVeranstaltung(this.val$ver);
                    IOManager.saveStundenplan(MainApplicationManager.getStundenplan(), Menu.this.getApplicationContext());
                    Menu.this.visibleFirst = Menu.this.lv1.getFirstVisiblePosition();
                    View v = Menu.this.lv1.getChildAt(0);
                    Menu.this.topy = v == null ? 0 : v.getTop();
                    Menu.this.refresListView(false);
                    return;
                }
                Node n = this.val$bfst.getNodeFromListByString(this.val$ver.getRaum());
                if (n != null) {
                    this.val$bfst.setFrom((Node) this.val$bfst.getNodes().get(0));
                    this.val$bfst.setTo(n);
                    Menu.this.startActivity(new Intent(Menu.this, Navigation.class));
                    return;
                }
                Builder adb = new Builder(Menu.this);
                adb.setTitle("Navigation");
                adb.setMessage("Comming soon...");
                adb.setPositiveButton("  OK  ", new C00181());
                adb.show();
            }
        }

        C00206() {
        }

        public void onItemClick(AdapterView<?> adapterView, View arg1, int arg2, long arg3) {
            Builder builder = new Builder(Menu.this);
            SeparatedListAdapter sla = (SeparatedListAdapter) Menu.this.lv1.getAdapter();
            if (sla.getItem(arg2) instanceof Veranstaltung) {
                Veranstaltung ver = (Veranstaltung) sla.getItem(arg2);
                builder.setTitle(ver.getName());
                CharSequence[] items = new CharSequence[]{Menu.this.getString(C0026R.string.editmenu_delete), Menu.this.getString(C0026R.string.extras_button2)};
                builder.setItems(items, new C00191(ver, MainApplicationManager.getBfst()));
                builder.create().show();
            }
        }
    }

    /* renamed from: FHNav.gui.Menu.7 */
    class C00217 implements OnTimeSetListener {
        private final /* synthetic */ Button val$timeFrom;

        C00217(Button button) {
            this.val$timeFrom = button;
        }

        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            if (minute >= 10) {
                this.val$timeFrom.setText(new StringBuilder(String.valueOf(hourOfDay)).append(":").append(minute).toString());
            } else {
                this.val$timeFrom.setText(new StringBuilder(String.valueOf(hourOfDay)).append(":0").append(minute).toString());
            }
        }
    }

    /* renamed from: FHNav.gui.Menu.8 */
    class C00228 implements OnTimeSetListener {
        private final /* synthetic */ Button val$timeTo;

        C00228(Button button) {
            this.val$timeTo = button;
        }

        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            if (minute >= 10) {
                this.val$timeTo.setText(new StringBuilder(String.valueOf(hourOfDay)).append(":").append(minute).toString());
            } else {
                this.val$timeTo.setText(new StringBuilder(String.valueOf(hourOfDay)).append(":0").append(minute).toString());
            }
        }
    }

    /* renamed from: FHNav.gui.Menu.9 */
    class C00239 implements OnClickListener {
        private final /* synthetic */ TimePickerDialog val$tpdf;

        C00239(TimePickerDialog timePickerDialog) {
            this.val$tpdf = timePickerDialog;
        }

        public void onClick(View v) {
            this.val$tpdf.show();
        }
    }

    public Menu() {
        this.agenda = false;
        this.visibleFirst = 0;
        this.topy = 0;
    }

    public void onResume() {
        super.onResume();
        Log.e(getClass().toString(), "Resume");
        refresListView(true);
    }

    public void onStart() {
        super.onStart();
        Log.e(getClass().toString(), "Start");
        if (MainApplicationManager.isFinish()) {
            finish();
        } else {
            refresListView(true);
            MainApplicationManager.setDensity(getResources().getDisplayMetrics().density);
        }
        FlurryAgent.onStartSession(this, "I7RRJ22MKL64Q9JLNZW8");
    }

    public void onStop() {
        super.onStop();
        FlurryAgent.onEndSession(this);
        Log.e(getClass().toString(), "Stop");
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e(getClass().toString(), "Create");
        this.addVorlesung = new Intent(this, AddVorlesung.class);
        this.adaptstundenplan = new Intent(this, AdaptStundenplan.class);
        this.settings = new Intent(this, Settings.class);
        this.wizard = new Intent(this, Wizard.class);
        if (SettingsManager.isWizardDone(getApplicationContext())) {
            setContentView(C0026R.layout.menu);
            MainApplicationManager.setStundenplan(IOManager.loadStundenplan(getApplicationContext()));
            this.header = (TextView) findViewById(C0026R.id.menu_header);
            this.header.setText(getString(C0026R.string.normal_view));
            this.veranstaltungen = MainApplicationManager.getVeranstaltungen();
            refresListView(true);
            ((Button) findViewById(C0026R.id.Button01)).setOnClickListener(new C00121());
            ((Button) findViewById(C0026R.id.Button02)).setOnClickListener(new C00132());
            ((Button) findViewById(C0026R.id.Button03)).setOnClickListener(new C00143());
            ((Button) findViewById(C0026R.id.exit_application)).setOnClickListener(new C00154());
            ((Button) findViewById(C0026R.id.info_application)).setOnClickListener(new C00175());
            return;
        }
        startActivity(this.wizard);
    }

    private SeparatedListAdapter build_normal(ArrayList<Veranstaltung> arrayList) {
        int i;
        SeparatedListAdapter separatedListAdapter = new SeparatedListAdapter(this);
        NormalListAdapter[] els = new NormalListAdapter[8];
        for (i = 0; i < els.length; i++) {
            els[i] = new NormalListAdapter(this, new ArrayList());
        }
        Iterator it = this.veranstaltungen.iterator();
        while (it.hasNext()) {
            Veranstaltung ver = (Veranstaltung) it.next();
            els[ver.getWochentag()].getItems().add(ver);
        }
        for (i = 0; i < els.length; i++) {
            if (els[i].getItems().size() > 0) {
                separatedListAdapter.addSection(getString(Tools.getWeekday(((Veranstaltung) els[i].getItems().get(0)).getWochentag())), els[i]);
            }
        }
        return separatedListAdapter;
    }

    private SeparatedListAdapter build_agenda(ArrayList<Veranstaltung> veranstaltungen) {
        int i;
        SeparatedListAdapter separatedListAdapter = new SeparatedListAdapter(this);
        NormalListAdapter[] els = new NormalListAdapter[8];
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        Calendar c1 = Calendar.getInstance();
        Date dt = new Date();
        c1.set(dt.getYear() + 1900, dt.getMonth(), dt.getDate());
        c1.setFirstDayOfWeek(2);
        int currentday = c1.getTime().getDay();
        for (i = 0; i < els.length; i++) {
            els[i] = new NormalListAdapter(this, new ArrayList());
        }
        Iterator it = veranstaltungen.iterator();
        while (it.hasNext()) {
            Veranstaltung ver = (Veranstaltung) it.next();
            if (ver.getWochentag() < currentday) {
                els[(ver.getWochentag() + 7) - currentday].getItems().add(ver);
            } else if (ver.getWochentag() == currentday) {
                Date dt2 = new Date();
                dt2.setDate(dt.getDate());
                dt2.setHours(ver.getEndTime().getHours());
                dt2.setMinutes(ver.getEndTime().getMinutes());
                if (dt2.after(dt)) {
                    els[ver.getWochentag() - currentday].getItems().add(ver);
                } else {
                    els[7].getItems().add(ver);
                }
            } else {
                els[ver.getWochentag() - currentday].getItems().add(ver);
            }
        }
        for (i = 0; i < els.length; i++) {
            if (els[i].getItems().size() > 0) {
                String header;
                if (i == 0) {
                    header = "Heute (" + getString(Tools.getWeekday(((Veranstaltung) els[i].getItems().get(0)).getWochentag())) + "," + sdf.format(c1.getTime()) + ")";
                } else if (i == 1) {
                    header = getString(C0026R.string.tomorrow) + " (" + getString(Tools.getWeekday(((Veranstaltung) els[i].getItems().get(0)).getWochentag())) + "," + sdf.format(c1.getTime()) + ")";
                } else {
                    header = getString(Tools.getWeekday(((Veranstaltung) els[i].getItems().get(0)).getWochentag())) + "," + sdf.format(c1.getTime());
                }
                separatedListAdapter.addSection(header, els[i]);
            }
            c1.add(5, 1);
        }
        return separatedListAdapter;
    }

    public void refresListView(boolean startAtBeginning) {
        if (this.veranstaltungen != null) {
            Collections.sort(this.veranstaltungen);
            if (this.agenda) {
                this.listAdapter = build_agenda(this.veranstaltungen);
            } else {
                this.listAdapter = build_normal(this.veranstaltungen);
            }
            this.lv1 = (ListView) findViewById(C0026R.id.listView1);
            this.lv1.setAdapter(this.listAdapter);
            this.lv1.setEmptyView(findViewById(C0026R.id.empty));
            this.lv1.setOnItemClickListener(new C00206());
            if (!startAtBeginning) {
                if (this.visibleFirst >= this.listAdapter.getCount()) {
                    this.visibleFirst = this.listAdapter.getCount() - 1;
                    this.topy = 0;
                }
                if (this.visibleFirst < 0) {
                    this.visibleFirst = 0;
                    this.topy = 0;
                }
                this.lv1.setSelectionFromTop(this.visibleFirst, this.topy);
            }
        }
    }

    public void build_add_own_entry_dialog() {
        View layout = ((LayoutInflater) getSystemService("layout_inflater")).inflate(C0026R.layout.ownentrydialog, (ViewGroup) findViewById(C0026R.id.layout_root));
        Spinner weekday = (Spinner) layout.findViewById(C0026R.id.own_entry_dialog_weekDay_Spinner);
        weekday.setAdapter(new ArrayAdapter(this, C0026R.layout.spinnerlayout, new String[]{getString(C0026R.string.monday), getString(C0026R.string.tuesday), getString(C0026R.string.wednesday), getString(C0026R.string.thursday), getString(C0026R.string.friday), getString(C0026R.string.saturday), getString(C0026R.string.sunday)}));
        Button timeFrom = (Button) layout.findViewById(C0026R.id.pickTimeFrom);
        Button timeTo = (Button) layout.findViewById(C0026R.id.pickTimeTo);
        OnTimeSetListener c00217 = new C00217(timeFrom);
        c00217 = new C00228(timeTo);
        timeFrom.setText(new StringBuilder(String.valueOf(8)).append(":").append(30).toString());
        timeTo.setText(new StringBuilder(String.valueOf(10)).append(":0").append(5).toString());
        TimePickerDialog tpdf = new TimePickerDialog(this, c00217, 8, 30, true);
        TimePickerDialog tpdt = new TimePickerDialog(this, c00217, 10, 5, true);
        ((Button) layout.findViewById(C0026R.id.pickTimeFrom)).setOnClickListener(new C00239(tpdf));
        ((Button) layout.findViewById(C0026R.id.pickTimeTo)).setOnClickListener(new 10(tpdt));
        Builder builder = new Builder(this);
        builder.setView(layout);
        String str = "Ok";
        builder.setPositiveButton(r5, new 11());
        builder.setNegativeButton("Cancel", null);
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
        alertDialog.getButton(-1).setOnClickListener(new 12(layout, weekday, timeFrom, timeTo, alertDialog));
    }

    public void build_calendar_dialog() {
        int fYear;
        int fMonth;
        int fDay;
        int tYear;
        int tMonth;
        int tDay;
        TextView textFrom;
        TextView textTo;
        OnDateSetListener 13;
        DatePickerDialog dpdf;
        DatePickerDialog dpdt;
        Spinner spin1;
        ArrayAdapter<String> arrayAdapter;
        Builder builder;
        String str;
        AlertDialog alertDialog;
        CalendarAdapter calendarAdapter = new CalendarAdapter(getApplicationContext());
        calendarAdapter.setSelectedid(0);
        View layout = ((LayoutInflater) getSystemService("layout_inflater")).inflate(C0026R.layout.calendardialog, (ViewGroup) findViewById(C0026R.id.layout_root));
        Calendar c = Calendar.getInstance();
        Date date = new Date(c.getTime().getYear(), 2, 15);
        date = new Date(c.getTime().getYear(), 9, 1);
        if (c.getTime().after(date)) {
            if (c.getTime().before(date)) {
                fYear = c.getTime().getYear() + 1900;
                fMonth = 3;
                fDay = 1;
                tYear = c.getTime().getYear() + 1900;
                tMonth = 7;
                tDay = 15;
                textFrom = (TextView) layout.findViewById(C0026R.id.dateDisplayFrom);
                textFrom.setText(new StringBuilder(String.valueOf(fDay)).append(".").append(fMonth).append(".").append(fYear).toString());
                textTo = (TextView) layout.findViewById(C0026R.id.dateDisplayTo);
                textTo.setText(new StringBuilder(String.valueOf(tDay)).append(".").append(tMonth).append(".").append(tYear).toString());
                13 = new 13(textFrom);
                13 = new 14(textTo);
                dpdf = new DatePickerDialog(this, 13, fYear, fMonth - 1, fDay);
                dpdt = new DatePickerDialog(this, 13, tYear, tMonth - 1, tDay);
                ((Button) layout.findViewById(C0026R.id.pickDateFrom)).setOnClickListener(new 15(dpdf));
                ((Button) layout.findViewById(C0026R.id.pickDateTo)).setOnClickListener(new 16(dpdt));
                spin1 = (Spinner) layout.findViewById(C0026R.id.calendarSpinner);
                arrayAdapter = new ArrayAdapter(this, 17367050, calendarAdapter.getCalendarNames());
                arrayAdapter.setDropDownViewResource(17367049);
                spin1.setAdapter(arrayAdapter);
                spin1.setOnItemSelectedListener(new 17(calendarAdapter));
                builder = new Builder(this);
                builder.setView(layout);
                str = "\u00dcbertragen";
                builder.setPositiveButton(r6, new 18(textFrom, textTo, calendarAdapter));
                builder.setNegativeButton("Cancel", null);
                alertDialog = builder.create();
                builder.show();
            }
        }
        fYear = c.getTime().getYear() + 1900;
        fMonth = 9;
        fDay = 15;
        tYear = fYear + 1;
        tMonth = 2;
        tDay = 10;
        textFrom = (TextView) layout.findViewById(C0026R.id.dateDisplayFrom);
        textFrom.setText(new StringBuilder(String.valueOf(fDay)).append(".").append(fMonth).append(".").append(fYear).toString());
        textTo = (TextView) layout.findViewById(C0026R.id.dateDisplayTo);
        textTo.setText(new StringBuilder(String.valueOf(tDay)).append(".").append(tMonth).append(".").append(tYear).toString());
        13 = new 13(textFrom);
        13 = new 14(textTo);
        dpdf = new DatePickerDialog(this, 13, fYear, fMonth - 1, fDay);
        dpdt = new DatePickerDialog(this, 13, tYear, tMonth - 1, tDay);
        ((Button) layout.findViewById(C0026R.id.pickDateFrom)).setOnClickListener(new 15(dpdf));
        ((Button) layout.findViewById(C0026R.id.pickDateTo)).setOnClickListener(new 16(dpdt));
        spin1 = (Spinner) layout.findViewById(C0026R.id.calendarSpinner);
        arrayAdapter = new ArrayAdapter(this, 17367050, calendarAdapter.getCalendarNames());
        arrayAdapter.setDropDownViewResource(17367049);
        spin1.setAdapter(arrayAdapter);
        spin1.setOnItemSelectedListener(new 17(calendarAdapter));
        builder = new Builder(this);
        builder.setView(layout);
        str = "\u00dcbertragen";
        builder.setPositiveButton(r6, new 18(textFrom, textTo, calendarAdapter));
        builder.setNegativeButton("Cancel", null);
        alertDialog = builder.create();
        builder.show();
    }

    public void onBackPressed() {
        Log.e("Menu", "Back");
    }
}
