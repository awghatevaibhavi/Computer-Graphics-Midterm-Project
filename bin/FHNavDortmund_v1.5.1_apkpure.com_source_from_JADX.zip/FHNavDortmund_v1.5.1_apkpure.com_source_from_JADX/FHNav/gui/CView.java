package FHNav.gui;

import FHNav.controller.BreadthFirstSearchTest;
import FHNav.controller.MainApplicationManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import org.kxml2.kdom.Node;
import org.kxml2.wap.Wbxml;

public class CView extends View {
    public static final int DURATION = 150;
    public static final int GROW = 0;
    public static final float MAX_SCALE = 4.5f;
    public static final float MIN_SCALE = 1.0f;
    public static final int SHRINK = 1;
    public static final float SPEED = 3.0f;
    public static final float ZOOM = 0.4f;
    private View _view;
    Bitmap bmp;
    Context ctx;
    protected float dist_curr;
    protected float dist_delta;
    protected float dist_pre;
    Rect dst;
    private long mLastGestureTime;
    Paint mpaint;
    boolean shrink;
    Rect src;
    Bitmap start;
    private long switch_time;
    protected OnTouchListener touchListener;
    protected float x1;
    protected float x1_pre;
    protected float x1_pre2;
    protected float x2;
    float x_moved;
    float x_old;
    float x_scale_mapping;
    float x_scale_zoom;
    float x_start;
    protected float y1;
    protected float y1_pre;
    protected float y1_pre2;
    protected float y2;
    float y_moved;
    float y_old;
    float y_scale_mapping;
    float y_scale_zoom;
    float y_start;
    Bitmap ziel;

    /* renamed from: FHNav.gui.CView.1 */
    class C00101 implements OnTouchListener {
        C00101() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            CView.this._view.onTouchEvent(event);
            int action = event.getAction() & 255;
            int p_count = event.getPointerCount();
            long now = SystemClock.uptimeMillis();
            switch (action) {
                case CView.GROW /*0*/:
                    CView.this.x1_pre2 = event.getX();
                    CView.this.y1_pre2 = event.getY();
                    break;
                case Wbxml.ENTITY /*2*/:
                    CView.this.x1 = event.getX(CView.GROW);
                    CView.this.y1 = event.getY(CView.GROW);
                    CView cView;
                    if (p_count <= CView.SHRINK) {
                        if (now - CView.this.switch_time > 500) {
                            CView.this.mLastGestureTime = 0;
                            CView.this.x_moved = CView.this.x1 - CView.this.x1_pre2;
                            CView.this.y_moved = CView.this.y1 - CView.this.y1_pre2;
                            cView = CView.this;
                            cView.x_moved *= CView.SPEED;
                            cView = CView.this;
                            cView.y_moved *= CView.SPEED;
                            System.out.println("xm: " + CView.this.x_moved + "ym: " + CView.this.y_moved);
                            System.out.println("Before:  xs: " + CView.this.x_start + "ys: " + CView.this.y_start);
                            if (CView.this.x_start - CView.this.x_moved < 0.0f) {
                                CView.this.x_start = 0.0f;
                            } else if (CView.this.x_start - CView.this.x_moved > ((float) CView.this.bmp.getWidth())) {
                                CView.this.x_start = (float) CView.this.bmp.getWidth();
                            } else {
                                cView = CView.this;
                                cView.x_start -= CView.this.x_moved;
                            }
                            if (CView.this.y_start - CView.this.y_moved < 0.0f) {
                                CView.this.y_start = 0.0f;
                            } else if (CView.this.y_start - CView.this.y_moved > ((float) CView.this.bmp.getHeight())) {
                                CView.this.y_start = (float) CView.this.bmp.getHeight();
                            } else {
                                cView = CView.this;
                                cView.y_start -= CView.this.y_moved;
                            }
                            System.out.println("After: xs: " + CView.this.x_start + "ys: " + CView.this.y_start);
                            CView.this._view.invalidate();
                            CView.this.x1_pre2 = CView.this.x1;
                            CView.this.y1_pre2 = CView.this.y1;
                            break;
                        }
                    }
                    CView.this.x2 = event.getX(CView.SHRINK);
                    CView.this.y2 = event.getY(CView.SHRINK);
                    CView.this.dist_curr = (float) Math.sqrt(Math.pow((double) (CView.this.x2 - CView.this.x1), 2.0d) + Math.pow((double) (CView.this.y2 - CView.this.y1), 2.0d));
                    CView.this.dist_delta = CView.this.dist_curr - CView.this.dist_pre;
                    if (now - CView.this.mLastGestureTime > 100) {
                        CView.this.mLastGestureTime = 0;
                        System.out.println(((float) (CView.this._view.getWidth() / 2)) / CView.this.x_scale_zoom);
                        int mode = CView.this.dist_delta > 0.0f ? CView.GROW : CView.this.dist_curr == CView.this.dist_pre ? 2 : CView.SHRINK;
                        switch (mode) {
                            case CView.GROW /*0*/:
                                if (CView.this.x_scale_zoom + CView.ZOOM >= CView.MAX_SCALE) {
                                    CView.this.x_scale_zoom = CView.MAX_SCALE;
                                    CView.this.y_scale_zoom = CView.MAX_SCALE;
                                    break;
                                }
                                cView = CView.this;
                                cView.x_scale_zoom += CView.ZOOM;
                                cView = CView.this;
                                cView.y_scale_zoom += CView.ZOOM;
                                CView.this.shrink = false;
                                break;
                            case CView.SHRINK /*1*/:
                                if (CView.this.x_scale_zoom - CView.ZOOM <= CView.MIN_SCALE) {
                                    CView.this.x_scale_zoom = CView.MIN_SCALE;
                                    CView.this.y_scale_zoom = CView.MIN_SCALE;
                                    break;
                                }
                                cView = CView.this;
                                cView.x_scale_zoom -= CView.ZOOM;
                                cView = CView.this;
                                cView.y_scale_zoom -= CView.ZOOM;
                                CView.this.shrink = true;
                                break;
                        }
                        CView.this.switch_time = now;
                        CView.this.mLastGestureTime = now;
                    }
                    CView.this._view.invalidate();
                    CView.this.x1_pre = CView.this.x1;
                    CView.this.y1_pre = CView.this.y1;
                    CView.this.dist_pre = CView.this.dist_curr;
                    break;
                    break;
                case Node.CDSECT /*5*/:
                    CView.this.x2 = event.getX(CView.SHRINK);
                    CView.this.y2 = event.getY(CView.SHRINK);
                    CView.this.x1_pre = event.getX(CView.GROW);
                    CView.this.y1_pre = event.getY(CView.GROW);
                    CView.this.x_moved = 0.0f;
                    CView.this.y_moved = 0.0f;
                    CView.this.mLastGestureTime = SystemClock.uptimeMillis();
                    break;
            }
            return true;
        }
    }

    public CView(Context context) {
        super(context);
        this.mpaint = new Paint();
        this.x_scale_zoom = MIN_SCALE;
        this.y_scale_zoom = MIN_SCALE;
        this.x_start = 0.0f;
        this.y_start = 0.0f;
        this.shrink = false;
        this.x_moved = 0.0f;
        this.y_moved = 0.0f;
        this.src = null;
        this.dist_curr = -1.0f;
        this.dist_pre = -1.0f;
        this.touchListener = new C00101();
        this.ctx = context;
        Options opt = new Options();
        opt.inScaled = false;
        this.bmp = MainApplicationManager.getBfst().getBMP();
        if (this.bmp == null) {
            this.bmp = BitmapFactory.decodeResource(this.ctx.getResources(), C0026R.drawable.ergeschoss, opt);
            MainApplicationManager.getBfst().setBMP(this.bmp);
        }
        this.x_start = (float) (this.bmp.getWidth() / 2);
        this.y_start = (float) (this.bmp.getHeight() / 2);
        this.ziel = BitmapFactory.decodeResource(this.ctx.getResources(), C0026R.drawable.ziel, opt);
        this.start = BitmapFactory.decodeResource(this.ctx.getResources(), C0026R.drawable.nadel, opt);
        this._view = this;
        setOnTouchListener(this.touchListener);
    }

    public void init() {
    }

    public void onDraw(Canvas canvas) {
        this.dst = new Rect(GROW, GROW, getWidth(), getHeight());
        RectF rectF = new RectF(0.0f, 0.0f, (float) this.bmp.getWidth(), (float) this.bmp.getHeight());
        Matrix matrix = new Matrix();
        if (this.x_scale_zoom == MIN_SCALE) {
            this.x_start = (float) (this.bmp.getWidth() / 2);
            this.y_start = (float) (this.bmp.getHeight() / 2);
        }
        matrix.postScale(MIN_SCALE / this.x_scale_zoom, MIN_SCALE / this.y_scale_zoom, this.x_start, this.y_start);
        matrix.mapRect(rectF);
        this.src = new Rect((int) rectF.left, (int) rectF.top, (int) rectF.right, (int) rectF.bottom);
        canvas.drawBitmap(this.bmp, this.src, this.dst, this.mpaint);
        this.x_scale_mapping = ((float) getWidth()) / ((float) this.bmp.getWidth());
        this.y_scale_mapping = ((float) getHeight()) / ((float) this.bmp.getHeight());
        BreadthFirstSearchTest bfst = MainApplicationManager.getBfst();
        this.mpaint.setColor(-16711936);
        this.mpaint.setStrokeWidth(4.0f * this.x_scale_zoom);
        int i = GROW;
        while (i < bfst.getPath().size()) {
            try {
                BreadthFirstSearchTest.Node n = (BreadthFirstSearchTest.Node) bfst.getPath().get(i);
                if (i != 0) {
                    BreadthFirstSearchTest.Node n_1 = (BreadthFirstSearchTest.Node) bfst.getPath().get(i - SHRINK);
                    n = (BreadthFirstSearchTest.Node) bfst.getPath().get(i);
                    float n_x = n.getX();
                    float n_y = n.getY();
                    float n1_x = n_1.getX();
                    float[] pn = new float[]{n_x, n_y};
                    float[] pn1 = new float[]{n1_x, n_1.getY()};
                    Matrix matrix2 = new Matrix();
                    matrix2.postScale(this.x_scale_zoom, this.y_scale_zoom, this.x_start, this.y_start);
                    matrix2.mapPoints(pn);
                    matrix2.mapPoints(pn1);
                    float f = pn1[GROW];
                    float f2 = this.x_scale_mapping * f;
                    f = pn1[SHRINK];
                    float f3 = this.y_scale_mapping * f;
                    f = pn[GROW];
                    float f4 = this.x_scale_mapping * f;
                    f = pn[SHRINK];
                    float f5 = this.y_scale_mapping;
                    Canvas canvas2 = canvas;
                    canvas2.drawLine(f2, f3, f4, r0 * f, this.mpaint);
                    Bitmap bitmap;
                    float side_x;
                    float side_y;
                    float[] pn11;
                    Rect rect;
                    if (i == bfst.getPath().size() - SHRINK) {
                        bitmap = this.ziel;
                        side_x = ((float) ((r0.getWidth() / 2) / 5)) * this.x_scale_zoom;
                        bitmap = this.ziel;
                        side_y = ((float) ((r0.getHeight() / 2) / 5)) * this.y_scale_zoom;
                        n_y += 11.0f;
                        pn11 = new float[]{n_x - 40.0f, n_y};
                        matrix2.mapPoints(pn11);
                        rect = new Rect((int) (pn11[GROW] * this.x_scale_mapping), (int) ((pn11[SHRINK] * this.y_scale_mapping) - (2.0f * side_y)), (int) ((pn11[GROW] * this.x_scale_mapping) + (2.0f * side_x)), (int) (pn11[SHRINK] * this.y_scale_mapping));
                        canvas.drawBitmap(this.ziel, null, rect, this.mpaint);
                    } else if (i == SHRINK) {
                        bitmap = this.start;
                        side_x = ((float) ((r0.getWidth() / 2) / 3)) * this.x_scale_zoom;
                        bitmap = this.start;
                        side_y = ((float) ((r0.getHeight() / 2) / 3)) * this.y_scale_zoom;
                        float n1_y += 29.0f;
                        pn11 = new float[]{n1_x - 2.0f, n1_y};
                        matrix2.mapPoints(pn11);
                        rect = new Rect((int) (pn11[GROW] * this.x_scale_mapping), (int) ((pn11[SHRINK] * this.y_scale_mapping) - (2.0f * side_y)), (int) ((pn11[GROW] * this.x_scale_mapping) + (2.0f * side_x)), (int) (pn11[SHRINK] * this.y_scale_mapping));
                        canvas.drawBitmap(this.start, null, rect, this.mpaint);
                    }
                }
                i += SHRINK;
            } catch (Exception e) {
                return;
            }
        }
    }
}
