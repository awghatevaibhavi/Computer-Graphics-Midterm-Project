package FHNav.gui.helper;

import FHNav.controller.MainApplicationManager;
import FHNav.controller.SettingsManager;
import FHNav.gui.C0026R;
import FHNav.model.Veranstaltung;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class NormalListAdapter extends BaseAdapter {
    private static final int big = 20;
    private static final int normal = 15;
    private static final int small = 10;
    Context ctx;
    private ArrayList<Veranstaltung> items;
    private LayoutInflater mInflater;
    String pattern;
    float res;
    SimpleDateFormat sdf;

    static class ViewHolder {
        TextView bottomtext;
        TextView toptext;

        ViewHolder() {
        }
    }

    public NormalListAdapter(Context ctx, ArrayList<Veranstaltung> items) {
        this.pattern = "HH:mm";
        this.sdf = new SimpleDateFormat();
        this.res = MainApplicationManager.getDensity();
        this.mInflater = LayoutInflater.from(ctx);
        this.ctx = ctx;
        this.items = items;
        this.sdf.applyPattern(this.pattern);
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = this.mInflater.inflate(C0026R.layout.row, null);
            holder = new ViewHolder();
            holder.bottomtext = (TextView) convertView.findViewById(C0026R.id.normal_row_bottomtext);
            holder.toptext = (TextView) convertView.findViewById(C0026R.id.normal_row_toptext);
            if (SettingsManager.getText_size(this.ctx) == 1) {
                holder.bottomtext.setTextSize(15.0f);
                holder.toptext.setTextSize(15.0f);
            } else if (SettingsManager.getText_size(this.ctx) == 2) {
                holder.bottomtext.setTextSize(20.0f);
                holder.toptext.setTextSize(20.0f);
            } else if (SettingsManager.getText_size(this.ctx) == 0) {
                holder.bottomtext.setTextSize(10.0f);
                holder.toptext.setTextSize(10.0f);
            }
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        Veranstaltung ve = (Veranstaltung) this.items.get(position);
        String topText = ve.getName();
        if (SettingsManager.isLecture_details_type(this.ctx) && ve.getType().length() > 0) {
            topText = new StringBuilder(String.valueOf(topText)).append(" [").append(ve.getType()).append("]").toString();
        }
        String bottomText = new StringBuilder(String.valueOf(this.sdf.format(ve.getStartTime()))).append("-").append(this.sdf.format(ve.getEndTime())).append(" ").append(ve.getRaum()).toString();
        if (SettingsManager.isLecture_details_groupletter(this.ctx) && ve.getStudentSet().length() > 0) {
            bottomText = new StringBuilder(String.valueOf(bottomText)).append(" (").append(ve.getStudentSet()).append(")").toString();
        }
        if (SettingsManager.isLecture_details_lecturer(this.ctx)) {
            bottomText = new StringBuilder(String.valueOf(bottomText)).append(" ").append(ve.getDozent()).toString();
        }
        holder.bottomtext.setText(bottomText);
        holder.toptext.setText(topText);
        LayoutParams paramsTop = holder.toptext.getLayoutParams();
        paramsTop.height = 0;
        LayoutParams paramsBottom = holder.bottomtext.getLayoutParams();
        paramsBottom.height = 0;
        holder.toptext.setLayoutParams(paramsTop);
        holder.bottomtext.setLayoutParams(paramsBottom);
        return convertView;
    }

    public int getCount() {
        return this.items.size();
    }

    public Object getItem(int position) {
        return this.items.get(position);
    }

    public long getItemId(int position) {
        return (long) position;
    }

    public ArrayList<Veranstaltung> getItems() {
        return this.items;
    }

    public void setItems(ArrayList<Veranstaltung> items) {
        this.items = items;
    }
}
