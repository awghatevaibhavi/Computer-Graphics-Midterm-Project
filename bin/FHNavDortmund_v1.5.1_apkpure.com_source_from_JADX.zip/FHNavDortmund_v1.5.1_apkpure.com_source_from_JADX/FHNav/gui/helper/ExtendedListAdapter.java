package FHNav.gui.helper;

import FHNav.controller.SettingsManager;
import FHNav.gui.C0026R;
import FHNav.model.Veranstaltung;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import org.apache.commons.lang.StringUtils;

public class ExtendedListAdapter extends BaseAdapter {
    ArrayList<Boolean> checked;
    Context ctx;
    ArrayList<Veranstaltung> items;
    ArrayList<Veranstaltung> itemsToManipulate;
    private LayoutInflater mInflater;
    String pattern;
    SimpleDateFormat sdf;

    /* renamed from: FHNav.gui.helper.ExtendedListAdapter.1 */
    class C00561 implements OnClickListener {
        private final /* synthetic */ ViewHolder val$holder;
        private final /* synthetic */ int val$pos;

        C00561(int i, ViewHolder viewHolder) {
            this.val$pos = i;
            this.val$holder = viewHolder;
        }

        public void onClick(View v) {
            boolean z;
            boolean z2;
            Log.e(StringUtils.EMPTY, "klickBox");
            boolean tmp = ((Boolean) ExtendedListAdapter.this.checked.get(this.val$pos)).booleanValue();
            ArrayList arrayList = ExtendedListAdapter.this.checked;
            int i = this.val$pos;
            if (tmp) {
                z = false;
            } else {
                z = true;
            }
            arrayList.set(i, Boolean.valueOf(z));
            CheckBox checkBox = this.val$holder.checkbox;
            if (tmp) {
                z2 = false;
            } else {
                z2 = true;
            }
            checkBox.setChecked(z2);
        }
    }

    /* renamed from: FHNav.gui.helper.ExtendedListAdapter.2 */
    class C00572 implements OnClickListener {
        private final /* synthetic */ ViewHolder val$holder;
        private final /* synthetic */ int val$pos;

        C00572(int i, ViewHolder viewHolder) {
            this.val$pos = i;
            this.val$holder = viewHolder;
        }

        public void onClick(View v) {
            boolean z;
            boolean z2;
            Log.e(StringUtils.EMPTY, "klick");
            boolean tmp = ((Boolean) ExtendedListAdapter.this.checked.get(this.val$pos)).booleanValue();
            ArrayList arrayList = ExtendedListAdapter.this.checked;
            int i = this.val$pos;
            if (tmp) {
                z = false;
            } else {
                z = true;
            }
            arrayList.set(i, Boolean.valueOf(z));
            CheckBox checkBox = this.val$holder.checkbox;
            if (tmp) {
                z2 = false;
            } else {
                z2 = true;
            }
            checkBox.setChecked(z2);
        }
    }

    static class ViewHolder {
        TextView bottomtext;
        CheckBox checkbox;
        TextView toptext;

        ViewHolder() {
        }
    }

    public ExtendedListAdapter(Context context, ArrayList<Veranstaltung> items) {
        this.pattern = "HH:mm";
        this.sdf = new SimpleDateFormat();
        this.itemsToManipulate = new ArrayList();
        this.mInflater = LayoutInflater.from(context);
        this.ctx = context;
        this.items = items;
        this.sdf.applyPattern(this.pattern);
    }

    public void deselectAll() {
        this.checked.clear();
        Iterator it = this.items.iterator();
        while (it.hasNext()) {
            Veranstaltung v = (Veranstaltung) it.next();
            this.checked.add(Boolean.valueOf(false));
        }
        notifyDataSetChanged();
    }

    public void selectAll() {
        this.checked.clear();
        Iterator it = this.items.iterator();
        while (it.hasNext()) {
            Veranstaltung v = (Veranstaltung) it.next();
            this.checked.add(Boolean.valueOf(true));
        }
        notifyDataSetChanged();
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = this.mInflater.inflate(C0026R.layout.editagendarow, null);
            holder = new ViewHolder();
            holder.bottomtext = (TextView) convertView.findViewById(C0026R.id.extenden_row_bottomtext);
            holder.toptext = (TextView) convertView.findViewById(C0026R.id.extenden_row_toptext);
            holder.checkbox = (CheckBox) convertView.findViewById(C0026R.id.extenden_row_checkbox);
            if (SettingsManager.getText_size(this.ctx) == 1) {
                Log.e("asd", "1");
                holder.bottomtext.setTextSize(15.0f);
                holder.toptext.setTextSize(15.0f);
            } else if (SettingsManager.getText_size(this.ctx) == 2) {
                Log.e("asd", "2");
                holder.bottomtext.setTextSize(20.0f);
                holder.toptext.setTextSize(20.0f);
            } else if (SettingsManager.getText_size(this.ctx) == 0) {
                holder.bottomtext.setTextSize(10.0f);
                holder.toptext.setTextSize(10.0f);
            }
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        int pos = position;
        Veranstaltung ve = (Veranstaltung) this.items.get(position);
        String topText = ve.getName();
        if (SettingsManager.isLecture_details_type(this.ctx) && ve.getType().length() > 0) {
            topText = new StringBuilder(String.valueOf(topText)).append(" [").append(ve.getType()).append("]").toString();
        }
        String bottomText = new StringBuilder(String.valueOf(this.sdf.format(ve.getStartTime()))).append("-").append(this.sdf.format(ve.getEndTime())).append(" ").append(ve.getRaum()).toString();
        if (SettingsManager.isLecture_details_groupletter(this.ctx)) {
            bottomText = new StringBuilder(String.valueOf(bottomText)).append(" (").append(ve.getStudentSet()).append(")").toString();
        }
        if (SettingsManager.isLecture_details_lecturer(this.ctx)) {
            bottomText = new StringBuilder(String.valueOf(bottomText)).append(" ").append(ve.getDozent()).toString();
        }
        holder.bottomtext.setText(bottomText);
        holder.toptext.setText(topText);
        holder.checkbox.setChecked(((Boolean) this.checked.get(position)).booleanValue());
        holder.checkbox.setOnClickListener(new C00561(pos, holder));
        convertView.setOnClickListener(new C00572(pos, holder));
        LayoutParams paramsTop = holder.toptext.getLayoutParams();
        paramsTop.height = 0;
        LayoutParams paramsBottom = holder.bottomtext.getLayoutParams();
        paramsBottom.height = 0;
        holder.toptext.setLayoutParams(paramsTop);
        holder.bottomtext.setLayoutParams(paramsBottom);
        LayoutParams paramsCheckbox = holder.checkbox.getLayoutParams();
        paramsCheckbox.height = -1;
        holder.checkbox.setLayoutParams(paramsCheckbox);
        return convertView;
    }

    public int getCount() {
        return this.items.size();
    }

    public Object getItem(int position) {
        return Integer.valueOf(position);
    }

    public long getItemId(int position) {
        return (long) position;
    }

    public ArrayList<Veranstaltung> getItems() {
        return this.items;
    }

    public void setItems(ArrayList<Veranstaltung> items) {
        this.items = items;
    }

    public ArrayList<Boolean> getChecked() {
        return this.checked;
    }

    public void setChecked(ArrayList<Boolean> checked) {
        this.checked = checked;
    }

    public void refresh() {
        this.checked = new ArrayList();
        Iterator it = this.items.iterator();
        while (it.hasNext()) {
            Veranstaltung v = (Veranstaltung) it.next();
            this.checked.add(Boolean.valueOf(false));
        }
    }
}
