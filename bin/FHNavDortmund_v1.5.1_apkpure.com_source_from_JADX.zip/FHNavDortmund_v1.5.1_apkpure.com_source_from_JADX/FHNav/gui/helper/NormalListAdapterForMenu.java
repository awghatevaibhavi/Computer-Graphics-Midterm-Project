package FHNav.gui.helper;

import FHNav.controller.SettingsManager;
import FHNav.gui.C0026R;
import FHNav.model.CanteenMenu;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class NormalListAdapterForMenu extends BaseAdapter {
    Context ctx;
    private ArrayList<CanteenMenu> items;
    private LayoutInflater mInflater;
    String pattern;
    SimpleDateFormat sdf;

    static class ViewHolder {
        TextView toptext;

        ViewHolder() {
        }
    }

    public NormalListAdapterForMenu(Context ctx, ArrayList<CanteenMenu> items) {
        this.pattern = "HH:mm";
        this.sdf = new SimpleDateFormat();
        this.ctx = ctx;
        this.mInflater = LayoutInflater.from(ctx);
        this.items = items;
        this.sdf.applyPattern(this.pattern);
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = this.mInflater.inflate(C0026R.layout.row2, null);
            holder = new ViewHolder();
            holder.toptext = (TextView) convertView.findViewById(C0026R.id.normal_row_toptext);
            if (SettingsManager.getText_size(this.ctx) == 1) {
                holder.toptext.setTextSize(15.0f);
            } else if (SettingsManager.getText_size(this.ctx) == 2) {
                holder.toptext.setTextSize(20.0f);
            } else if (SettingsManager.getText_size(this.ctx) == 0) {
                holder.toptext.setTextSize(10.0f);
            }
            LayoutParams paramsTop = holder.toptext.getLayoutParams();
            paramsTop.height = 0;
            holder.toptext.setLayoutParams(paramsTop);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.toptext.setText(((CanteenMenu) this.items.get(position)).getDesc());
        return convertView;
    }

    public int getCount() {
        return this.items.size();
    }

    public Object getItem(int position) {
        return this.items.get(position);
    }

    public long getItemId(int position) {
        return (long) position;
    }

    public ArrayList<CanteenMenu> getItems() {
        return this.items;
    }

    public void setItems(ArrayList<CanteenMenu> items) {
        this.items = items;
    }
}
