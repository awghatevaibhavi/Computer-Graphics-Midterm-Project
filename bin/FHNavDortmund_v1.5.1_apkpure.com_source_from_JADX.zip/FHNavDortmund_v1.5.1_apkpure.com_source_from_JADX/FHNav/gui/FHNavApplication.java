package FHNav.gui;

import android.app.Application;
import org.acra.ACRA;
import org.acra.ReportingInteractionMode;
import org.acra.annotation.ReportsCrashes;

@ReportsCrashes(forceCloseDialogAfterToast = false, formKey = "dFRmZUJYTUF0ZXZSaTJ4cFNOR1h6UWc6MQ", mode = ReportingInteractionMode.TOAST, resToastText = 2130968678)
public class FHNavApplication extends Application {
    public void onCreate() {
        ACRA.init(this);
        super.onCreate();
    }
}
