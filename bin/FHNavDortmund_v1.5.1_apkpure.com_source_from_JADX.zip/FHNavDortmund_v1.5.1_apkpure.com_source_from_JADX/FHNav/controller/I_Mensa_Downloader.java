package FHNav.controller;

public interface I_Mensa_Downloader {
    void downloadDone();
}
