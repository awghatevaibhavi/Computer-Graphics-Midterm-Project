package FHNav.controller;

import FHNav.gui.C0026R;
import org.apache.commons.lang.StringUtils;
import org.kxml2.kdom.Node;
import org.kxml2.wap.Wbxml;

public class Tools {
    public static int getWeekday(int day) {
        switch (day) {
            case Wbxml.END /*1*/:
                return C0026R.string.monday;
            case Wbxml.ENTITY /*2*/:
                return C0026R.string.tuesday;
            case Wbxml.STR_I /*3*/:
                return C0026R.string.wednesday;
            case Wbxml.LITERAL /*4*/:
                return C0026R.string.thursday;
            case Node.CDSECT /*5*/:
                return C0026R.string.friday;
            case Node.ENTITY_REF /*6*/:
                return C0026R.string.saturday;
            case Node.IGNORABLE_WHITESPACE /*7*/:
                return C0026R.string.sunday;
            default:
                return 0;
        }
    }

    public static String getShortWeekday(int day) {
        String ret = StringUtils.EMPTY;
        switch (day) {
            case Wbxml.END /*1*/:
                return "MO";
            case Wbxml.ENTITY /*2*/:
                return "TU";
            case Wbxml.STR_I /*3*/:
                return "WE";
            case Wbxml.LITERAL /*4*/:
                return "TH";
            case Node.CDSECT /*5*/:
                return "FR";
            case Node.ENTITY_REF /*6*/:
                return "SA";
            case Node.IGNORABLE_WHITESPACE /*7*/:
                return "SU";
            default:
                return ret;
        }
    }
}
