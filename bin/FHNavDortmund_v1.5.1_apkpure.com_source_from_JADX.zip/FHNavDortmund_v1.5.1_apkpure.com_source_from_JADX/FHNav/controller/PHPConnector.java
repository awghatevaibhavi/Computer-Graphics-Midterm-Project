package FHNav.controller;

import FHNav.model.Stundenplan;
import FHNav.model.Veranstaltung;
import android.content.Context;
import android.util.Log;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import org.apache.commons.lang.CharEncoding;
import org.apache.commons.lang.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class PHPConnector {
    public static JSONArray getJSONArray(ArrayList<NameValuePair> nvp, Context ctx) {
        String str = "log_tag";
        String result = StringUtils.EMPTY;
        try {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(SettingsManager.getPathToFile(ctx));
            httppost.setEntity(new UrlEncodedFormEntity(nvp));
            InputStream is = httpclient.execute(httppost).getEntity().getContent();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, CharEncoding.UTF_8), 8);
            StringBuilder sb = new StringBuilder();
            while (true) {
                String line = reader.readLine();
                if (line == null) {
                    break;
                }
                sb.append(new StringBuilder(String.valueOf(line)).append("n").toString());
            }
            is.close();
            result = sb.toString();
        } catch (Exception e) {
            Exception e2 = e;
            String str2 = "log_tag";
            Log.e(str, "Error converting result " + e2.toString());
        }
        try {
            return new JSONArray(result);
        } catch (JSONException e3) {
            JSONException e4 = e3;
            str2 = "log_tag";
            Log.e(str, "Error parsing data " + e4.toString());
            return null;
        }
    }

    public static ArrayList<String> getAllBranches(Context ctx) {
        ArrayList<NameValuePair> nameValuePairs = new ArrayList();
        nameValuePairs.add(new BasicNameValuePair("type", "getAllBranches"));
        ArrayList<String> ret = new ArrayList();
        JSONArray jArray = getJSONArray(nameValuePairs, ctx);
        int i = 0;
        while (i < jArray.length()) {
            try {
                ret.add(jArray.getJSONObject(i).getString("pos"));
                i++;
            } catch (Exception e) {
                Log.e("error", "Error while Parsing JSON");
            }
        }
        return ret;
    }

    public static Stundenplan getStundenplanFromMysql(String s, Context ctx) {
        ArrayList<NameValuePair> nameValuePairs = new ArrayList();
        nameValuePairs.add(new BasicNameValuePair("type", "getDetailOfBranch"));
        nameValuePairs.add(new BasicNameValuePair("pos", s));
        Stundenplan stundenplan = new Stundenplan();
        JSONArray jArray = getJSONArray(nameValuePairs, ctx);
        int i = 0;
        while (i < jArray.length()) {
            try {
                JSONObject json_data = jArray.getJSONObject(i);
                Veranstaltung veranstaltung = new Veranstaltung(json_data.getString("staff"), json_data.getString("name"), json_data.getInt("dayOfWeek"), json_data.getInt("start"), json_data.getInt("duration"), json_data.getString("location"), json_data.getString("pos"), json_data.getString("semester"), json_data.getString("type"), json_data.getString("studentSet"));
                if (stundenplan.getVeranstaltungen().contains(veranstaltung)) {
                    int index = stundenplan.getVeranstaltungen().indexOf(veranstaltung);
                    Veranstaltung dozent = (Veranstaltung) stundenplan.getVeranstaltungen().get(index);
                    dozent.setDauer(((Veranstaltung) stundenplan.getVeranstaltungen().get(index)).getDauer() + 1);
                    if (dozent.getStart() > veranstaltung.getStart()) {
                        dozent.setStart(veranstaltung.getStart());
                    }
                } else {
                    stundenplan.addVeranstaltung(veranstaltung);
                }
                i++;
            } catch (Exception e) {
            }
        }
        stundenplan.refresh();
        return stundenplan;
    }
}
