package FHNav.controller;

import FHNav.model.Veranstaltung;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Build.VERSION;
import android.util.Log;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CalendarAdapter {
    int[] calendarId;
    String[] calendarNames;
    Context ctx;
    int selectedId;

    public CalendarAdapter(Context ctx) {
        Cursor cursor;
        String str = "_id";
        this.selectedId = 0;
        this.ctx = ctx;
        ContentResolver contentResolver;
        Uri parse;
        String[] strArr;
        String str2;
        if (VERSION.SDK_INT > 14) {
            contentResolver = this.ctx.getContentResolver();
            parse = Uri.parse("content://com.android.calendar/calendars");
            strArr = new String[2];
            str2 = "_id";
            strArr[0] = str;
            strArr[1] = "calendar_displayName";
            cursor = contentResolver.query(parse, strArr, null, null, null);
        } else {
            contentResolver = this.ctx.getContentResolver();
            parse = Uri.parse("content://com.android.calendar/calendars");
            strArr = new String[2];
            str2 = "_id";
            strArr[0] = str;
            strArr[1] = "displayName";
            cursor = contentResolver.query(parse, strArr, null, null, null);
        }
        cursor.moveToFirst();
        this.calendarNames = new String[cursor.getCount()];
        this.calendarId = new int[cursor.getCount()];
        for (int i = 0; i < this.calendarNames.length; i++) {
            this.calendarId[i] = cursor.getInt(0);
            this.calendarNames[i] = cursor.getString(1);
            cursor.moveToNext();
        }
    }

    public void addRecEventToCalendar(Veranstaltung ver, Date start, Date end) {
        if (ver.getName().equals("abc")) {
            System.out.println("abc");
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        ContentValues contentEvent = new ContentValues();
        contentEvent.put("calendar_id", Integer.valueOf(this.calendarId[this.selectedId]));
        if (ver.getName() != null && ver.getName().length() > 0) {
            contentEvent.put("title", ver.getName());
        }
        if (ver.getDozent() == null || ver.getDozent().length() <= 0) {
            contentEvent.put("description", " (FHNAV12345)");
        } else {
            contentEvent.put("description", "bei " + ver.getDozent() + " (FHNAV12345)");
        }
        if (ver.getRaum() != null && ver.getRaum().length() > 0) {
            contentEvent.put("eventLocation", ver.getRaum());
        }
        contentEvent.put("eventTimezone", "Europe/Berlin");
        Calendar c1 = Calendar.getInstance();
        c1.set(start.getYear() + 1900, start.getMonth(), start.getDate(), ver.getStartTime().getHours(), ver.getStartTime().getMinutes());
        c1.setFirstDayOfWeek(2);
        while (c1.getTime().getDay() != ver.getWochentag() - 1) {
            c1.add(5, 1);
        }
        contentEvent.put("dtstart", Long.valueOf(c1.getTime().getTime()));
        contentEvent.put("duration", "P" + (((long) ((ver.getEndTime().getHours() - ver.getStartTime().getHours()) * 3600)) + ((long) ((ver.getEndTime().getMinutes() - ver.getStartTime().getMinutes()) * 60))) + "S");
        contentEvent.put("rrule", "FREQ=WEEKLY;BYDAY=" + Tools.getShortWeekday(c1.getTime().getDay() + 1) + ";UNTIL=" + sdf.format(end) + "T130000Z");
        contentEvent.put("allDay", Integer.valueOf(0));
        contentEvent.put("hasAlarm", Integer.valueOf(0));
        this.ctx.getContentResolver().insert(Uri.parse("content://com.android.calendar/events"), contentEvent);
    }

    public String[] getCalendarNames() {
        return this.calendarNames;
    }

    public void setCalendarNames(String[] calendarNames) {
        this.calendarNames = calendarNames;
    }

    public int[] getCalendarId() {
        return this.calendarId;
    }

    public void setCalendarId(int[] calendarId) {
        this.calendarId = calendarId;
    }

    public int getSelectedId() {
        return this.selectedId;
    }

    public void setSelectedid(int selectedId) {
        this.selectedId = selectedId;
    }

    public void clearAllFHNAVEntries() {
    }

    public void getEvent(Context ctx) {
        Builder builder = Uri.parse("content://com.android.calendar/instances/when").buildUpon();
        long now = new Date().getTime();
        ContentUris.appendId(builder, now - 604800000);
        ContentUris.appendId(builder, 604800000 + now);
        Cursor eventCursor = ctx.getContentResolver().query(builder.build(), new String[]{"title", "begin", "end", "allDay", "rrule", "description"}, "calendar_id=" + this.calendarId[this.selectedId] + " AND description LIKE '%FHNAV12345%'", null, "startDay ASC, startMinute ASC");
        while (eventCursor.moveToNext()) {
            String title = eventCursor.getString(0);
            Date begin = new Date(eventCursor.getLong(1));
            Date end = new Date(eventCursor.getLong(2));
            Boolean allDay = Boolean.valueOf(!eventCursor.getString(3).equals("0"));
            Log.e("asd: ", "Title: " + title + " RRule:" + eventCursor.getString(4) + " Dur:" + eventCursor.getString(5));
        }
        ctx.getContentResolver().delete(Uri.parse("content://com.android.calendar/calendars/events"), "calendar_id=" + this.calendarId[this.selectedId] + " AND description LIKE '%FHNAV12345%'", null);
    }
}
