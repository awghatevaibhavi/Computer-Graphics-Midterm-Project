package FHNav.controller;

import FHNav.model.CanteenMenu;
import FHNav.model.Stundenplan;
import FHNav.model.Veranstaltung;
import android.app.Activity;
import android.content.Context;
import java.util.ArrayList;
import java.util.Iterator;
import org.apache.commons.lang.StringUtils;

public class MainApplicationManager {
    private static BreadthFirstSearchTest bfst;
    private static Activity currentAcctivity;
    private static ArrayList<CanteenMenu> dataKostBar;
    private static ArrayList<CanteenMenu> dataMensa;
    private static float density;
    private static boolean downloading;
    private static boolean finish;
    private static ArrayList<I_Mensa_Downloader> listener;
    private static String selectedBranch;
    private static Stundenplan stundenplan;

    public static void refreshData(Context ctx) {
        downloading = true;
        dataKostBar = CanteenBeanTest.getMenuKostbar2(ctx);
        dataMensa = CanteenBeanTest.getMenuMensa();
        downloading = false;
        fireDownloader();
    }

    public static float getDensity() {
        return density;
    }

    public static void setDensity(float density) {
        density = density;
    }

    static {
        listener = new ArrayList();
        finish = false;
        selectedBranch = StringUtils.EMPTY;
        downloading = false;
    }

    private static void fireDownloader() {
        Iterator it = listener.iterator();
        while (it.hasNext()) {
            ((I_Mensa_Downloader) it.next()).downloadDone();
        }
    }

    public static void addListener(I_Mensa_Downloader i) {
        listener.add(i);
    }

    public static void removeListener(I_Mensa_Downloader i) {
        listener.remove(i);
    }

    public static boolean isFinish() {
        return finish;
    }

    public static void setFinish(boolean finish) {
        finish = finish;
    }

    public static String getSelectedBranch() {
        return selectedBranch;
    }

    public static void setSelectedBranch(String selectedBranch) {
        selectedBranch = selectedBranch;
    }

    public static boolean isDownloading() {
        return downloading;
    }

    public static void setDownloading(boolean downloading) {
        downloading = downloading;
    }

    public static ArrayList<CanteenMenu> getDataKostBar() {
        return dataKostBar;
    }

    public static void setDataKostBar(ArrayList<CanteenMenu> dataKostBar) {
        dataKostBar = dataKostBar;
    }

    public static ArrayList<CanteenMenu> getDataMensa() {
        return dataMensa;
    }

    public static void setDataMensa(ArrayList<CanteenMenu> dataMensa) {
        dataMensa = dataMensa;
    }

    public static BreadthFirstSearchTest getBfst() {
        if (bfst != null) {
            return bfst;
        }
        BreadthFirstSearchTest bfstt = new BreadthFirstSearchTest();
        bfstt.initGraph();
        setBfst(bfstt);
        return bfstt;
    }

    public static void setBfst(BreadthFirstSearchTest bfst) {
        bfst = bfst;
    }

    public static Activity getCurrentAcctivity() {
        return currentAcctivity;
    }

    public static void setCurrentAcctivity(Activity currentAcctivity) {
        currentAcctivity = currentAcctivity;
    }

    public static Stundenplan getStundenplan() {
        if (stundenplan == null) {
            return new Stundenplan();
        }
        return stundenplan;
    }

    public static void setStundenplan(Stundenplan stundenplan) {
        stundenplan = stundenplan;
    }

    public static ArrayList<Veranstaltung> getVeranstaltungen() {
        return getStundenplan().getVeranstaltungen();
    }
}
