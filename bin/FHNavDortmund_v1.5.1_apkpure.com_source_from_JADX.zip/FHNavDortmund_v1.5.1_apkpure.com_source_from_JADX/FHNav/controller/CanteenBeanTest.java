package FHNav.controller;

import FHNav.model.CanteenMenu;
import android.content.Context;
import android.util.Log;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import org.apache.commons.lang.CharEncoding;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class CanteenBeanTest {
    public static HashMap<String, Integer> canteenMapping;

    static {
        canteenMapping = new HashMap();
    }

    public static ArrayList<String> getAllCanteens(Context ctx) {
        ArrayList<NameValuePair> nameValuePairs = new ArrayList();
        nameValuePairs.add(new BasicNameValuePair("type", "getAllCanteens"));
        ArrayList<String> ret = new ArrayList();
        try {
            JSONArray jArray = new JSONArray(getJSONString(nameValuePairs, ctx));
            canteenMapping.clear();
            int i = 0;
            while (i < jArray.length()) {
                try {
                    JSONObject json_data = jArray.getJSONObject(i);
                    String name = json_data.getString("name");
                    int id = json_data.getInt("id");
                    ret.add(name);
                    canteenMapping.put(name, Integer.valueOf(id));
                    i++;
                } catch (Exception e) {
                    Log.e("error", "Error while Parsing JSON");
                }
            }
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
        return ret;
    }

    public static ArrayList<CanteenMenu> getCanteenMenu(String canteenString, Context ctx) {
        ArrayList<CanteenMenu> menus = new ArrayList();
        SimpleDateFormat sdfToDate = new SimpleDateFormat("dd.MM.yyyy");
        ArrayList<NameValuePair> nameValuePairs = new ArrayList();
        int id = ((Integer) canteenMapping.get(canteenString)).intValue();
        nameValuePairs.add(new BasicNameValuePair("type", "getCanteenMenu"));
        nameValuePairs.add(new BasicNameValuePair("id", id));
        JSONObject jObject = new JSONObject(getJSONString(nameValuePairs, ctx));
        JSONArray jArray = jObject.getJSONArray("daylies");
        JSONArray weeklies = 0;
        while (weeklies < jArray.length()) {
            int i;
            try {
                JSONObject json_data = jArray.getJSONObject(weeklies);
                canteenString = json_data.getString("caption");
                i = sdfToDate.parse(canteenString.substring(canteenString.indexOf("r den ") + 6));
                JSONArray menues = json_data.getJSONArray("menues");
                for (int j = 0; j < menues.length(); j++) {
                    menus.add(new CanteenMenu(StringUtils.EMPTY, menues.getString(j), i));
                }
                weeklies++;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try {
            weeklies = jObject.getJSONArray("weeklies");
            for (i = 0; i < weeklies.length(); i++) {
                menus.add(new CanteenMenu(StringUtils.EMPTY, weeklies.getString(i), null));
            }
        } catch (JSONException e1) {
            e1.printStackTrace();
        }
        return menus;
    }

    public static ArrayList<CanteenMenu> getMenuKostbar2(Context ctx) {
        ArrayList<CanteenMenu> menus = new ArrayList();
        SimpleDateFormat sdfToDate = new SimpleDateFormat("dd.MM.yyyy");
        ArrayList<NameValuePair> nameValuePairs = new ArrayList();
        nameValuePairs.add(new BasicNameValuePair("type", "getCanteenMenu"));
        nameValuePairs.add(new BasicNameValuePair("id", "132"));
        try {
            JSONArray jArray = new JSONObject(getJSONString(nameValuePairs, ctx)).getJSONArray("daylies");
            int i = 0;
            while (i < jArray.length()) {
                try {
                    JSONObject json_data = jArray.getJSONObject(i);
                    String dat = json_data.getString("caption");
                    Date dt = sdfToDate.parse(dat.substring(dat.indexOf("r den ") + 6));
                    JSONArray menues = json_data.getJSONArray("menues");
                    for (int j = 0; j < menues.length(); j++) {
                        menus.add(new CanteenMenu(StringUtils.EMPTY, menues.getString(j), dt));
                    }
                    i++;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (JSONException e1) {
            e1.printStackTrace();
        }
        return menus;
    }

    public static ArrayList<CanteenMenu> getMenuKostbar() {
        String str = StringUtils.EMPTY;
        ArrayList<CanteenMenu> menus = new ArrayList();
        SimpleDateFormat sdfToDate = new SimpleDateFormat("dd.MM.yyyy");
        try {
            Iterator it = Jsoup.connect("http://www.stwdo.de/index.php?id=248").get().select("table.SpeiseplanWoche").iterator();
            while (it.hasNext()) {
                Element e = (Element) it.next();
                String dat = e.select("caption").html();
                Date dt = sdfToDate.parse(dat.substring(dat.indexOf("r den ") + 6));
                Iterator it2 = e.select("td.Tabellen-spalte-2").iterator();
                while (it2.hasNext()) {
                    String desc = StringEscapeUtils.unescapeHtml(((Element) it2.next()).select("p").html());
                    desc.replace("*", StringUtils.EMPTY);
                    if (!desc.startsWith("(") || !desc.endsWith(")")) {
                        menus.add(new CanteenMenu(StringUtils.EMPTY, desc, dt));
                    }
                }
            }
            System.out.println("Kostbar parsed");
            menus.size();
            return menus;
        } catch (Exception e2) {
            e2.printStackTrace();
            return null;
        }
    }

    public static ArrayList<CanteenMenu> getMenuMensa() {
        ArrayList<CanteenMenu> menus = new ArrayList();
        SimpleDateFormat sdfToDate = new SimpleDateFormat("dd.MM.yyyy");
        try {
            int i;
            String desc;
            Document doc = Jsoup.connect("http://www.stwdo.de/index.php?id=127").get();
            Iterator it = doc.select("table.SpeiseplanWoche").iterator();
            while (it.hasNext()) {
                Element e = (Element) it.next();
                String dat = e.select("caption").html();
                Date dt = sdfToDate.parse(dat.substring(dat.indexOf("r den ") + 6));
                Elements m = e.select("td.Tabellen-spalte-2");
                for (i = 0; i < m.size(); i++) {
                    desc = StringEscapeUtils.unescapeHtml(m.get(i).select("p").html());
                    desc.replace("*", StringUtils.EMPTY);
                    menus.add(new CanteenMenu(StringUtils.EMPTY, desc, dt));
                }
            }
            i = doc.select("table.WochenSpecials").iterator();
            while (i.hasNext()) {
                Elements ms = ((Element) i.next()).select("td.Tabellen-spalte-2");
                for (int i2 = 0; i2 < ms.size(); i2++) {
                    desc = StringEscapeUtils.unescapeHtml(ms.get(i2).select("p").html());
                    desc.replace("*", StringUtils.EMPTY);
                    menus.add(new CanteenMenu(StringUtils.EMPTY, desc, null));
                }
            }
            System.out.println("Mensa parsed");
            menus.size();
            return menus;
        } catch (Exception e2) {
            e2.printStackTrace();
            return null;
        }
    }

    public static String getJSONString(ArrayList<NameValuePair> nvp, Context ctx) {
        String result = StringUtils.EMPTY;
        try {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(SettingsManager.getPathToFile2(ctx));
            httppost.setEntity(new UrlEncodedFormEntity(nvp));
            InputStream is = httpclient.execute(httppost).getEntity().getContent();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, CharEncoding.UTF_8), 8);
            StringBuilder sb = new StringBuilder();
            while (true) {
                String line = reader.readLine();
                if (line == null) {
                    is.close();
                    return sb.toString();
                }
                sb.append(line);
            }
        } catch (Exception e) {
            Log.e("log_tag", "Error converting result " + e.toString());
            return result;
        }
    }
}
