package FHNav.controller;

import android.graphics.Bitmap;
import java.util.LinkedList;
import java.util.List;

public class BreadthFirstSearchTest {
    private Bitmap bmp;
    Node from;
    List nodes;
    List path;
    Node to;

    public class Node {
        String name;
        List neighbors;
        Node pathParent;
        float f0x;
        float f1y;

        public String getName() {
            return this.name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Node(String name) {
            this.name = name;
            this.neighbors = new LinkedList();
        }

        public Node(String name, float x, float y) {
            this.name = name;
            this.neighbors = new LinkedList();
            this.f0x = x;
            this.f1y = y;
        }

        public Node(String name, float x, float y, List l) {
            this.name = name;
            this.neighbors = new LinkedList();
            this.f0x = x;
            this.f1y = y;
            l.add(this);
        }

        public void addNeighbor(Node n) {
            this.neighbors.add(n);
            n.neighbors.add(this);
        }

        public String toString() {
            return this.name;
        }

        public float getX() {
            return this.f0x;
        }

        public void setX(float x) {
            this.f0x = x;
        }

        public float getY() {
            return this.f1y;
        }

        public void setY(float y) {
            this.f1y = y;
        }
    }

    public Node getFrom() {
        return this.from;
    }

    public void setFrom(Node from) {
        this.from = from;
    }

    public Node getTo() {
        return this.to;
    }

    public void setTo(Node to) {
        this.to = to;
    }

    public List getNodes() {
        return this.nodes;
    }

    public void setNodes(List nodes) {
        this.nodes = nodes;
    }

    public List getPath() {
        return this.path;
    }

    public void setPath(List path) {
        this.path = path;
    }

    public Node getNodeFromListByString(String s) {
        Node n = null;
        for (int i = 0; i < this.nodes.size(); i++) {
            Node ntmp = (Node) this.nodes.get(i);
            if (ntmp.getName().equalsIgnoreCase(s)) {
                n = ntmp;
            }
        }
        return n;
    }

    public void initGraph() {
        this.nodes = new LinkedList();
        Node Eingang = new Node("Eingang", 140.0f, 955.0f, this.nodes);
        Node node = new Node("Eingangshalle", 412.0f, 955.0f);
        node = new Node("FlurSued", 412.0f, 1241.0f);
        Node Nebeneingang = new Node("Nebeneingang", 555.0f, 950.0f, this.nodes);
        node = new Node("NebeneingangFlur", 555.0f, 896.0f);
        Node AE01 = new Node("A.E.01", 218.0f, 1136.0f, this.nodes);
        node = new Node("A.E.01T1", 218.0f, 993.0f);
        node = new Node("A.E.01T1Flur", 218.0f, 955.0f);
        node = new Node("A.E.01T2", 341.0f, 1136.0f);
        node = new Node("A.E.01T2Flur", 412.0f, 1136.0f);
        Node AE02 = new Node("A.E.02", 294.0f, 825.0f, this.nodes);
        node = new Node("A.E.02T1", 294.0f, 910.0f);
        node = new Node("A.E.02T1Flur", 322.0f, 955.0f);
        node = new Node("A.E.02T2", 377.0f, 825.0f);
        node = new Node("A.E.02T2Flur", 412.0f, 854.0f);
        Node AE03 = new Node("A.E.03", 520.0f, 785.0f, this.nodes);
        node = new Node("A.E.03T1", 520.0f, 872.0f);
        node = new Node("A.E.03T1Flur", 520.0f, 896.0f);
        node = new Node("VorTreppenhaus", 520.0f, 955.0f);
        node = new Node("A.E.03T2", 435.0f, 736.0f);
        node = new Node("A.E.03T2Flur", 412.0f, 736.0f);
        float f = 1200.0f;
        Node BE01 = new Node("B.E.01", 475.0f, f, this.nodes);
        node = new Node("B.E.01Flur", 475.0f, 1241.0f);
        float f2 = 1200.0f;
        Node BE02 = new Node("B.E.02", 555.0f, f2, this.nodes);
        node = new Node("B.E.02Flur", 555.0f, 1241.0f);
        float f3 = 1200.0f;
        Node BE03 = new Node("B.E.03", 625.0f, f3, this.nodes);
        node = new Node("B.E.03Flur", 625.0f, 1241.0f);
        float f4 = 1200.0f;
        Node BE04 = new Node("B.E.04", 685.0f, f4, this.nodes);
        node = new Node("B.E.04Flur", 685.0f, 1241.0f);
        float f5 = 1200.0f;
        Node BE06 = new Node("B.E.06", 835.0f, f5, this.nodes);
        node = new Node("B.E.06Flur", 835.0f, 1241.0f);
        float f6 = 1200.0f;
        Node BE07 = new Node("B.E.07", 925.0f, f6, this.nodes);
        node = new Node("B.E.07Flur", 925.0f, 1241.0f);
        float f7 = 1200.0f;
        Node BE08 = new Node("B.E.08", 988.0f, f7, this.nodes);
        node = new Node("B.E.08Flur", 988.0f, 1241.0f);
        float f8 = 1200.0f;
        Node BE09 = new Node("B.E.09", 1070.0f, f8, this.nodes);
        node = new Node("B.E.09Flur", 1070.0f, 1241.0f);
        float f9 = 1200.0f;
        Node BE10 = new Node("B.E.10", 1150.0f, f9, this.nodes);
        node = new Node("B.E.10Flur", 1150.0f, 1241.0f);
        float f10 = 1320.0f;
        Node BE20 = new Node("B.E.20", 585.0f, f10, this.nodes);
        node = new Node("B.E.20Flur", 585.0f, 1241.0f);
        float f11 = 1320.0f;
        Node BE21 = new Node("B.E.21", 700.0f, f11, this.nodes);
        node = new Node("B.E.21Flur", 700.0f, 1241.0f);
        float f12 = 1320.0f;
        Node BE23 = new Node("B.E.23", 1025.0f, f12, this.nodes);
        node = new Node("B.E.23Flur", 1025.0f, 1241.0f);
        float f13 = 1320.0f;
        Node BE24 = new Node("B.E.24", 1105.0f, f13, this.nodes);
        node = new Node("B.E.24Flur", 1105.0f, 1241.0f);
        f13 = 500.0f;
        Node CE31 = new Node("C.E.31", f13, 617.0f, this.nodes);
        node = new Node("C.E.31Flur", 412.0f, 617.0f);
        float f14 = 500.0f;
        Node CE312 = new Node("C.E.31.2", f14, 383.0f, this.nodes);
        node = new Node("C.E.31.2Flur", 412.0f, 383.0f);
        float f15 = 500.0f;
        Node CE32 = new Node("C.E.32", f15, 310.0f, this.nodes);
        node = new Node("C.E.32Flur", 412.0f, 310.0f);
        float f16 = 500.0f;
        Node CE321 = new Node("C.E.32.1", f16, 87.0f, this.nodes);
        node = new Node("C.E.32.1Flur", 412.0f, 87.0f);
        float f17 = 350.0f;
        Node CE40 = new Node("C.E.40", f17, 626.0f, this.nodes);
        node = new Node("C.E.40Flur", 412.0f, 626.0f);
        float f18 = 350.0f;
        Node CE41 = new Node("C.E.41", f18, 492.0f, this.nodes);
        node = new Node("C.E.41Flur", 412.0f, 492.0f);
        float f19 = 350.0f;
        Node CE42 = new Node("C.E.42", f19, 339.0f, this.nodes);
        node = new Node("C.E.42Flur", 412.0f, 339.0f);
        float f20 = 350.0f;
        Node CE43 = new Node("C.E.43", f20, 218.0f, this.nodes);
        node = new Node("C.E.43Flur", 412.0f, 218.0f);
        float f21 = 350.0f;
        Node CE44 = new Node("C.E.44", f21, 165.0f, this.nodes);
        node = new Node("C.E.44Flur", 412.0f, 165.0f);
        float f22 = 350.0f;
        Node CE45 = new Node("C.E.45", f22, 55.0f, this.nodes);
        node = new Node("C.E.45Flur", 412.0f, 55.0f);
        Nebeneingang.addNeighbor(node);
        node.addNeighbor(node);
        Eingang.addNeighbor(node);
        node.addNeighbor(node);
        node.addNeighbor(node);
        node.addNeighbor(AE01);
        AE01.addNeighbor(node);
        node.addNeighbor(node);
        node.addNeighbor(node);
        node.addNeighbor(node);
        node.addNeighbor(AE02);
        AE02.addNeighbor(node);
        node.addNeighbor(node);
        node.addNeighbor(node);
        node.addNeighbor(node);
        node.addNeighbor(node);
        node.addNeighbor(node);
        node.addNeighbor(node);
        node.addNeighbor(node);
        node.addNeighbor(node);
        node.addNeighbor(node);
        node.addNeighbor(AE03);
        AE03.addNeighbor(node);
        node.addNeighbor(node);
        node.addNeighbor(node);
        node.addNeighbor(CE40);
        node.addNeighbor(node);
        node.addNeighbor(CE31);
        node.addNeighbor(node);
        node.addNeighbor(CE41);
        node.addNeighbor(node);
        node.addNeighbor(CE312);
        node.addNeighbor(node);
        node.addNeighbor(CE42);
        node.addNeighbor(node);
        node.addNeighbor(CE32);
        node.addNeighbor(node);
        node.addNeighbor(CE43);
        node.addNeighbor(node);
        node.addNeighbor(CE44);
        node.addNeighbor(node);
        node.addNeighbor(CE321);
        node.addNeighbor(CE45);
        node.addNeighbor(node);
        node.addNeighbor(node);
        node.addNeighbor(BE01);
        node.addNeighbor(node);
        node.addNeighbor(BE02);
        node.addNeighbor(node);
        node.addNeighbor(BE20);
        node.addNeighbor(node);
        node.addNeighbor(BE03);
        node.addNeighbor(node);
        node.addNeighbor(BE04);
        node.addNeighbor(node);
        node.addNeighbor(BE21);
        node.addNeighbor(node);
        node.addNeighbor(BE06);
        node.addNeighbor(node);
        node.addNeighbor(BE07);
        node.addNeighbor(node);
        node.addNeighbor(BE08);
        node.addNeighbor(node);
        node.addNeighbor(BE23);
        node.addNeighbor(node);
        node.addNeighbor(BE09);
        node.addNeighbor(node);
        node.addNeighbor(BE24);
        node.addNeighbor(BE10);
        this.from = Eingang;
        this.to = Eingang;
    }

    protected List constructPath(Node node) {
        LinkedList path = new LinkedList();
        while (node.pathParent != null) {
            path.addFirst(node);
            node = node.pathParent;
        }
        path.addFirst(node);
        return path;
    }

    public List search(Node startNode, Node goalNode) {
        LinkedList closedList = new LinkedList();
        LinkedList openList = new LinkedList();
        openList.add(startNode);
        startNode.pathParent = null;
        while (!openList.isEmpty()) {
            Node node = (Node) openList.removeFirst();
            if (node == goalNode) {
                return constructPath(goalNode);
            }
            closedList.add(node);
            for (Node neighborNode : node.neighbors) {
                if (!(closedList.contains(neighborNode) || openList.contains(neighborNode))) {
                    neighborNode.pathParent = node;
                    openList.add(neighborNode);
                }
            }
        }
        return null;
    }

    public Bitmap getBMP() {
        return this.bmp;
    }

    public void setBMP(Bitmap bmp) {
        this.bmp = bmp;
    }
}
