package FHNav.controller;

import FHNav.model.Stundenplan;
import android.content.Context;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class IOManager {
    private static String save_dir;
    private static String stundenplanDatei;

    static {
        stundenplanDatei = "plan.ser";
        save_dir = "private";
    }

    public static String getStundenplanDatei() {
        return stundenplanDatei;
    }

    public static void setStundenplanDatei(String stundenplanDatei) {
        stundenplanDatei = stundenplanDatei;
    }

    public static void saveStundenplan(Stundenplan stundenplan, Context ctx) {
        try {
            ObjectOutputStream objOut = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(new File(getLocalFileDir(ctx) + File.separator + stundenplanDatei))));
            objOut.writeObject(stundenplan);
            objOut.close();
            System.out.println("Save Success");
            System.out.println("Path: " + getLocalFileDir(ctx));
        } catch (Exception e) {
            System.out.println("Save Error");
        }
    }

    public static Stundenplan loadStundenplan(Context ctx) {
        Stundenplan stundenplan;
        try {
            ObjectInputStream objIn = new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File(getLocalFileDir(ctx) + File.separator + stundenplanDatei))));
            stundenplan = (Stundenplan) objIn.readObject();
            objIn.close();
            System.out.println("Load Success");
            System.out.println("Path: " + getLocalFileDir(ctx));
            return stundenplan;
        } catch (Exception e) {
            stundenplan = new Stundenplan();
            System.out.println("Load Error");
            return stundenplan;
        }
    }

    public static File getLocalFileDir(Context ctx) {
        return ctx.getDir(save_dir, 0);
    }
}
